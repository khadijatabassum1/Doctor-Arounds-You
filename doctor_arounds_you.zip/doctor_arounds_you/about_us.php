<?php
session_start();
include("includes/db.php");


?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Doctor Arounds You</title>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>







 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-T8Gy5hrqNKT+hzMclPo118YTQO6cYprQmhrYwIiQ/3axmI1hQomh7Ud2hPOy8SP1" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">


	
	</head>
<body>

<div class="bgimg">
<div class="header">

<nav class="navbar navbar-expand-md bg-dark navbar-dark fixed-top">
<div class="container">
<a href="home1.php" class="navbar-brand text-danger font-weight-bold"  ><b><h2>Doctor Arounds You</b></h2></a>

<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsenavber">
<span class="navbar-toggler-icon">
</span>
 </button>
 <div class="collapse navbar-collapse text-center " id="collapsenavber">
 <!-- ml-auto means margin left auto-->
 <ul class="navbar-nav ml-auto">
  <li class="nav-item">
 <a href="home1.php" class="nav-link text-white">Home</a>
 </li>
 
   <li class="nav-item ">
 <a href="about_us.php" class="nav-link text-white">About Us</a>
 <ul> <a href="history.php" >History</a>
 </ul>
 </li>
 <li class="nav-item">
 <a href="admin.php" class="nav-link text-white">Admin</a>
 </li>
 <li class="nav-item">
 <a href="doctor.php" class="nav-link text-white">Doctor</a>
 </li>
 <li class="nav-item">
 <a href="contact_us.php" class="nav-link text-white">Contact Us</a>
 </li>
  
 
   <li class="nav-item">
 <a href="user.php" class="nav-link text-white">User</a>
 </li>
  <li class="nav-item">
 <a href="index.php" class="nav-link text-white">Logout</a>
 </li>
 
 </ul>
 </div>
</div>
</div>

</nav>

<!--<script type="text/javascript">

$(document).ready(funcation()
{
$('.navbar-toggler-icon').click(funcation()
{
$('nav').toggleClass('active')
})
$('ul li').click(funcation()
{
$(this).siblings().removeClass('active');
$(this).toggleClass('active');

})
})



</script>

-->



<br>   
<br>   
<br>   
<br>
<br>   
<br> 
<br>

<br>   
<br>   
<br>   


<div class="container">
    <div class="row vertical-offset-100">
	<div class = "col-md-4">
		
	</div>
    	<div class="col-md-4 ">
    		<div class="panel panel-default">
			  	<div class="panel-heading">
			    	<b><h2 class="panel-title text-danger" >About Us</b></h2>
			 	</div>
			  	<div class="panel-body">
			    	<form accept-charset="UTF-8" role="form">
                    <fieldset>
			    	  	<div class="form-group">
			    		  
						  <p>
						  <h4>Now a days it is laborious to find a doctor in a manner corresponding to your requirements.
						  So here it is the solution to your trouble.This system 
						  empowers you to navigate your nearest and expert doctor as you want.The action of being registered is too much sophisticated 
						  and plain. After the fulfilment 
						  of being registered you may get the doctor and also may fix the appointment.
						  This system also allows to find the first aid facility as well.</h4>
						  </p>
						
						</div>

			    	</fieldset>
			      	</form>
			    </div>
			</div>
		</div>
	</div>
</div>

 

<br /><br />
<br /><br />
<br /><br />
<br /><br />
<br /><br />
<br /><br />
<br /><br />



<!--fixed footer-->

<div class="navbar navbar-inverse navbar-fixed-bottom" role="navigation">
<div class="container">
<div class="navbar-text pull-left">


<h6 >&copy; 2019, Design by Khadija Tabassum</h6>
 </div>
 <div class="navbar-text pull-right">
 <a href="https://www.facebook.com/"><i class="fa fa-facebook-square fa-2x"></i></a>
 <a href="https://twitter.com/Twitter"><i class="fa fa-twitter fa-2x"></i></a>
<a href="https://plus.google.com/discover"><i class="fa fa-google-plus fa-2x"></i></a>
</div>
</div>
</div>





</body>
</html>

