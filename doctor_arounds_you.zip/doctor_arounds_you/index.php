<?php
session_start();
include("includes/db.php");


?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Doctor Arounds You</title>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-T8Gy5hrqNKT+hzMclPo118YTQO6cYprQmhrYwIiQ/3axmI1hQomh7Ud2hPOy8SP1" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">


	
	</head>
<body>

<div class="header">

<nav class="navbar navbar-expand-md bg-dark navbar-dark fixed-top">
<div class="container">
<a href="home1.php" class="navbar-brand text-danger font-weight-bold"  ><b><h2>Doctor Arounds You</b></h2></a>

<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsenavber">
<span class="navbar-toggler-icon">
</span>
 </button>
 <div class="collapse navbar-collapse text-center " id="collapsenavber">
 <!-- ml-auto means margin left auto-->
 <ul class="navbar-nav ml-auto">
  <li class="nav-item">
 <a href="home1.php" class="nav-link text-white">Home</a>
 </li>
 
   <li class="nav-item">
 <a href="about_us.php" class="nav-link text-white">About Us</a>
 <ul> <a href="history.php" >History</a>
 </ul>
 </li>
 <li class="nav-item">
 <a href="admin.php" class="nav-link text-white">Admin</a>
 </li>
 <li class="nav-item">
 <a href="doctor.php" class="nav-link text-white">Doctor</a>
 </li>
 <li class="nav-item">
 <a href="contact_us.php" class="nav-link text-white">Contact Us</a>
 </li>
  
 
   <li class="nav-item">
 <a href="user.php" class="nav-link text-white">User</a>
 </li>
  <li class="nav-item">
 <a href="home1.php" class="nav-link text-white">Logout</a>
 </li>
 
 </ul>
 </div>
</div>
</div>

</nav>





<div class="container">
<div class="row">
<div class="header-banner">
<div id="my-slider" class="carousel slide" data-ride="carousel">

<ol class="carousel-indicators" >
<li data-target="#my-slider" data-slid-to="0" class="active"></li>
<li data-target="#my-slider" data-slid-to="1"></li>
<li data-target="#my-slider" data-slid-to="2"></li>
<li data-target="#my-slider" data-slid-to="3"></li>
<li data-target="#my-slider" data-slid-to="4"></li>
<li data-target="#my-slider" data-slid-to="5"></li>

</ol>






<div class="carousel-inner" role="listbox">
<div class="item active image-wid">
<img src="imag/kz001.png"    alt="rode" class="img-responsive">
<div class="carousel-caption" align="center">
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<div class="container ">
<div class="row vertical-offset-100">
	<div class = "col-md-12">
		
	</div>
	<h1>Find Doctor</h1>


  	</div>
		</div>


<h2>Welcome To Our Site!</h2>
<button type="button" class="btn btn-outline-ligt btn-lg"><a href="home1.php">View Demo</a></button>
<button type="button" class="btn btn-primary btn-lg">Get Started</button>



</div>
</div>

<div class="item image-wid">
<img src="imag/kz002.png"  width="400px"  height="400px" alt="rode" class="img-responsive">
<div class="carousel-caption" align="center">
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<h1>Feedback</h1>


</div>
</div>
<div class="item image-wid">
<img src="imag/kz05.png"   alt="rode" class="img-responsive">
<div class="carousel-caption" align="center">
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<h1>Medicine</h1>


</div>
</div>
<div class="item image-wid">
<img src="imag/kz06.png"   alt="rode" class="img-responsive">
<div class="carousel-caption" align="center">
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<h1>Doctor Details</h1>


</div>
</div>

<div class="item image-wid">
<img src="imag/kz08.png"    alt="rode" class="img-responsive">
<div class="carousel-caption" align="center">
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<h1>Select Doctor</h1>



</div>
</div>



<div class="item image-wid">
<img src="imag/kz09.png"  alt="rode">
<div class="carousel-caption "  class="img-responsive">
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<h1>Emergency Care</h1>



</div>
</div>


</div>

<a class="left carousel-control" href="#my-slider" role="button" data-slide="prev">
<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
<span class="sr-only">Previous</span>



</a>

<a class="right carousel-control" href="#my-slider" role="button" data-slide="next">
<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
<span class="sr-only">Next</span>



</a>

</div>
</div>
</div>
</div>









</body>
</html>



