
<?php
class Database
{
	private $host="localhost";
	private  $username="root";
	private   $password="";
	private $db_name="doctor_arounds_you";
	public $con;
	
	//get the database connection
	public function getConnection()
	{
		$this->con==null;
		try{
			
			
			$this->con=new PDO("mysql:host=". $this->host.  ";dbname=" . $this->db_name, $this->username, $this->password);
            $this->con->exec("set names utf8");
}
catch(PDOException $exception)
{
	echo "connection error:" . $exception->getMessage();
}

return $this->con;
    }
}
$con=mysqli_connect("localhost","root","","doctor_arounds_you");



?>







<?php 

class search_doctor{
	//database connection and table name
	private $con;
	private $table_name="doctors";
	// object properties
	
	public $id;
	public $Entre_Name;
	public $Dr_Info;
	public $Get_Map;
	public $Get_Appointment;
	
	// constructor with $db as database connection
    public function __construct($db){
        $this->con = $db;
    }
	
	
}




?>


<?php
//search doctor
	
	//required headers_list
	header("Access-Control-Allow-Origin:*");
	header("Content-Type: application/json; charset=UTF-8");
	/*
	//include database and object files
	
	include_once 'config/core.php';
	include_once  'includes/config/db.php';
	include_once  'objects/doctor.php';
	*/
	
	
// instantiate database and cities object
$database=new Database();
$db=$database->getConnection();
//initializa object

$doctors=new search_doctor($db);

//get keywords

$keywords=isset($_GET["s"])  ? $_GET["s"] :"";

//query search doctors
$stmt= $doctors->search($keywords);
$num=$stmt->rowCount();

//check if more than  0 record found

if($num>0)
{
	
	
	//doctors array
	$doctors_arr=array();
	$doctors_arr['records']=array();
	
	// retrieve our table contents
    // fetch() is faster than fetchAll()
	
	while($row= $stmt->fetch(PDO:: FETCH_ASSOC))
	{
		// extract row
        // this will make $row['name'] to
        // just $name only
		extract($row);
		$doctors_item=array(
		
		"id"=>$id,
		"Entre_Name"=>$Entre_Name,
		"Dr_Info"=>$Dr_Info,
		"Get_Map"=>$Get_Map,
		"Get_Appointment"=>$Get_Appointment
		
		);
		
		array_push($doctors_arr["records"], $doctors_item);
		//set response code  -200 OK
		
		http_response_code(200);
		
		//show  doctors data
		
		echo json_encode($doctors_arr);
	}
}
	else
	{
		//set response code -404 Not found 
		http_response_code(404);
		
		//tell the user no doctor found
		echo json_encode(
		array("message"=>"No doctor found.")
		);

	}

	//create search doctors method
	function search($keywords)
	{
		//select all query
		$query="SELECT * from doctors  WEHRE Entre_Name LIKE ? OR  Dr_Info
		LIKE ? OR Get_Appointment";
		
		//prepared query statement
		$stmt=$this->con->prepare($query);
		//sanitize
		$keywords=htmlspecialchars(strip_tags($keywords));
		$keywords="%{$keywords}%";
		
		
		//bind
		$stmt->bindParam(1,$keywords);
		$stmt->bindParam(2,$keywords);
		$stmt->bindParam(3,$keywords);
		
		//execute query
		$stmt->execute();
		return $stmt;
		
		
		
		
		
	}
	

?>