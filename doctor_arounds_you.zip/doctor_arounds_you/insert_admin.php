<?php
//insert.php  
$con = mysqli_connect("localhost", "root", "", "doctor_arounds_you");
if(!empty($_POST))
{
 $output = '';
    $Enter_Name = mysqli_real_escape_string($con, $_POST["Enter_Name"]);  
    $Email = mysqli_real_escape_string($con, $_POST["Email"]);  
    $Password = mysqli_real_escape_string($con, $_POST["Password"]);  


    $query = "
    INSERT INTO admins (Enter_Name,Email,Password)  
     VALUES('$Enter_Name','$Email', '$Password')
    ";
    if(mysqli_query($con, $query))
    {
     $output .= '<label class="text-success">Data Inserted</label>';
     $select_query = "SELECT * FROM admins ORDER BY id DESC";
     $result = mysqli_query($con, $select_query);
     $output .= '
      <table class="table table-bordered">  
                    <tr>  
                         <th width="70%">Admins Name</th>  
                         <th width="30%">View</th>  
                    </tr>

     ';
     while($row = mysqli_fetch_array($result))
     {
      $output .= '
       <tr>  
                         <td>' . $row["Enter_Name"] . '</td>  
                         <td><input type="button" name="view" value="view" id="' . $row["id"] . '" class="btn btn-info btn-xs view_data" /></td>  
                    </tr>
      ';
     }
     $output .= '</table>';
    }
    echo $output;
}
?>
