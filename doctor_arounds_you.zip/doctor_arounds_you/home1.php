<?php
session_start();
include("includes/db.php");


?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Doctor Arounds You</title>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-T8Gy5hrqNKT+hzMclPo118YTQO6cYprQmhrYwIiQ/3axmI1hQomh7Ud2hPOy8SP1" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">


	
	</head>
<body>
<div class="bgimg">
<div class="header">

<nav class="navbar navbar-expand-md bg-dark navbar-dark fixed-top">
<div class="container">
<a href="index.php" class="navbar-brand text-danger font-weight-bold"  ><b><h2>Doctor Arounds You</b></h2></a>

<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsenavber">
<span class="navbar-toggler-icon">
</span>
 </button>
 <div class="collapse navbar-collapse text-center " id="collapsenavber">
 <!-- ml-auto means margin left auto-->
 <ul class="navbar-nav ml-auto">
  <li class="nav-item">

 <a href="index.php" class="nav-link text-white">Home</a>
 
 
  <ul> <a href="admin.php" >Admin's Home</a>

 
<a href="user.php" >User's Home</a>
 </ul>
 </li>
 
   <li class="nav-item">
 <a href="about_us.php" class="nav-link text-white">About Us</a>
 <ul> <a href="history.php" >History</a>
 </ul>
 </li>
 <li class="nav-item">
 <a href="admin.php" class="nav-link text-white">Admin</a>
 </li>
 <li class="nav-item">
 <a href="doctor.php" class="nav-link text-white">Doctor</a>
 </li>
 <li class="nav-item">
 <a href="contact_us.php" class="nav-link text-white">Contact Us</a>
 </li>
  
 
   <li class="nav-item">
 <a href="user.php" class="nav-link text-white">User</a>
 </li>
  <li class="nav-item">
 <a href="index.php" class="nav-link text-white">Logout</a>
 </li>
 
 </ul>
 </div>
</div>
</div>



</nav>


<div class="container text-center text-white hearderset">
<h2>Welcome To Our Site!</h2>
<h1>IT'S NICE TO MEET YOU</h1>

<button class="btn btn-warning text-white btn-lg">Details</button>

</div>

<section class="container ourservices text-center">
<h1>SERVICES
</h1>
<p>Our Services Is Avaliable In Lahore</p>
<div class="row rowsetting">
<!--  d-block display block and m-auto margin auto-->
<div class="col-lg-4 col-md-4 col-sm-4 col-10 d-block m-auto">
<div class="imgsetting d-block m-auto bg-warning"><i class="fa fa-shopping-cart fa-3x text-white"></i>
</div>
<h2>Services</h2>
<p>
</p>


</div>
<div class="col-lg-4 col-md-4 col-sm-4 col-10 d-block m-auto">
<div class="imgsetting d-block m-auto bg-warning"><i class="fa fa-desktop fa-3x text-white"></i>
</div>
<h2>Facilitite</h2>
<p>
</p>


</div>
<div class="col-lg-4 col-md-4 col-sm-4 col-10 d-block m-auto">
<div class="imgsetting d-block m-auto bg-warning"><i class="fa fa-lock fa-3x text-white"></i>
</div>
<h2>Security</h2>
<p>
</p>


</div>

</div>


</section>

<!--//////////////////info section///////////////-->
<section class="info bg-light">
<div class="container text-center">
<h1>FACILITIES<h1>
<p>
</p>
<div class="row">
<div class="col-lg-4 col-md-4 col-sm-12 col-10  d-block m-auto">
<div class="card card-thumb">
<img src="imag/kz001.png" class="card-img img-fluid">
<div class="card-body">
<h2 class="card-title">Feedback</h2>
<p class="card-text" Give Feedback></p>
</div>
</div>
</div>
<div class="col-lg-4 col-md-4 col-sm-12 col-10  d-block m-auto">
<div class="card  card-thumb">
<img src="imag/kz002.png" class="card-img img-fluid">
<div class="card-body">
<h2 class="card-title">Check Up</h2>
<p class="card-text" Check Up></p>
</div>
</div>
</div>
<div class="col-lg-4 col-md-4 col-sm-12 col-10  d-block m-auto">
<div class="card card-thumb">
<img src="imag/kz05.png" class="card-img img-fluid">
<div class="card-body">
<h2 class="card-title">Medicine</h2>
<p class="card-text" Medicine></p>
</div>
</div>
</div>
</div>


<div class="row">
<div class="col-lg-4 col-md-4 col-sm-12 col-10  d-block m-auto">
<div class="card card-thumb">
<img src="imag/kz06.png" class="card-img img-fluid">
<div class="card-body">
<h2 class="card-title">Doctor Details</h2>
<p class="card-text" Doctor Details></p>
</div>
</div>
</div>
<div class="col-lg-4 col-md-4 col-sm-12 col-10  d-block m-auto">
<div class="card card-thumb">
<img src="imag/kz08.png" class="card-img img-fluid">
<div class="card-body">
<h2 class="card-title">Select Doctor</h2>
<p class="card-text" Select Doctor></p>
</div>
</div>
</div>
<div class="col-lg-4 col-md-4 col-sm-12 col-10  d-block m-auto">
<div class="card card-thumb">
<img src="imag/kz202.png" class="card-img img-fluid">
<div class="card-body">
<h2 class="card-title">Emergency Care<h2>
<p class="card-text"Emergency Care></p>
</div>
</div>
</div>
</div>
</div>

</section>
<!--team-->
<section class="ourteam">
<div class="container text-center">
<h1>OUR AMZING TEAM</h1>
<p></p>
<div class="row teamsetting">
<div class="col-lg-4 col-md-4 col-sm-10 col-12d-block m-auto">

<figure class="figure">
<img src="imag/kz04.png" class="figure-img img-fluid rounded-circle"
height="300px" width="300px">
<figcaption>
<h4>Khadija Tabassum</h4>
<p class="figure-caption">Web Developer</p>
</figcaption>

</figure>
</div>



<div class="col-lg-4 col-md-4 col-sm-10 col-12d-block m-auto">

<figure class="figure">
<img src="imag/kz02.png" class="figure-img img-fluid rounded-circle"
height="300px" width="300px">
<figcaption>
<h4>Rahat Fitama</h4>
<p class="figure-caption">Web Designer</p>
</figcaption>

</figure>
</div>
</div>

</div>


</section>

<!--fixed footer-->
<div class="navbar navbar-inverse navbar-fixed-bottom" role="navigation">
<div class="container">
<div class="navbar-text pull-left">


<h6 class="text-center">&copy; 2019, Design by Khadija Tabassum</h6>
 </div>
 <div class="navbar-text pull-right">
 <a href="https://www.facebook.com/"><i class="fa fa-facebook-square fa-2x"></i></a>
 <a href="https://twitter.com/Twitter"><i class="fa fa-twitter fa-2x"></i></a>
<a href="https://plus.google.com/discover"><i class="fa fa-google-plus fa-2x"></i></a>
</div>
</div>
</div>
 

</body>
</html>

