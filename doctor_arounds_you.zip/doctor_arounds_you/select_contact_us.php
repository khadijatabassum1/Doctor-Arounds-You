<?php  
//select.php  
if(isset($_POST["user_id"]))
{
 $output = '';
 $con = mysqli_connect("localhost", "root", "", "doctor_arounds_you");
 $query = "SELECT * FROM contact_us WHERE id = '".$_POST["user_id"]."'";
 $result = mysqli_query($con, $query);
 $output .= '  
      <div class="table-responsive">  
           <table class="table table-bordered">';
    while($row = mysqli_fetch_array($result))
    {
     $output .= '
     <tr>  
            <td width="30%"><label>Enter_Name</label></td>  
            <td width="70%">'.$row["Enter_Name"].'</td>  
        </tr>
        <tr>  
            <td width="30%"><label>Enter_Email</label></td>  
            <td width="70%">'.$row["Enter_Email"].'</td>  
        </tr>
        <tr>  
            <td width="30%"><label>Enter_Phone_No</label></td>  
            <td width="70%">'.$row["Enter_Phone_No"].'</td>  
        </tr>
        <tr>  
            <td width="30%"><label>Enter_Message</label></td>  
            <td width="70%">'.$row["Enter_Message"].'</td>  
        </tr>
        
     ';
    }
    $output .= '</table></div>';
    echo $output;
}
?>