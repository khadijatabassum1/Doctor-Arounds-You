<?php  
//select.php  
if(isset($_POST["user_id"]))
{
 $output = '';
 $con = mysqli_connect("localhost", "root", "", "doctor_arounds_you");
 $query = "SELECT * FROM doctors WHERE id = '".$_POST["user_id"]."'";
 $result = mysqli_query($con, $query);
 $output .= '  
      <div class="table-responsive">  
           <table class="table table-bordered">';
    while($row = mysqli_fetch_array($result))
    {
     $output .= '
     <tr>  
            <td width="30%"><label>Enter_Name</label></td>  
            <td width="70%">'.$row["Enter_Name"].'</td>  
        </tr>
        <tr>  
            <td width="30%"><label>Dr_Info</label></td>  
            <td width="70%">'.$row["Dr_Info"].'</td>  
        </tr>
        
        <tr>  
            <td width="30%"><label>Get_Appointment</label></td>  
            <td width="70%">'.$row["Get_Appointment"].'</td>  
        </tr>
        
     ';
    }
    $output .= '</table></div>';
    echo $output;
}
?>