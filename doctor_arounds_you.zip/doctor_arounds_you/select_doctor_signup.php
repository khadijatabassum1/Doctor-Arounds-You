<?php  
//select.php  
if(isset($_POST["user_id"]))
{
 $output = '';
 $con = mysqli_connect("localhost", "root", "", "doctor_arounds_you");
 $query = "SELECT * FROM doctor_signup WHERE id = '".$_POST["user_id"]."'";
 $result = mysqli_query($con, $query);
 $output .= '  
      <div class="table-responsive">  
           <table class="table table-bordered">';
    while($row = mysqli_fetch_array($result))
    {
     $output .= '
     <tr>  
            <td width="30%"><label>Enter_Name</label></td>  
            <td width="70%">'.$row["Enter_Name"].'</td>  
        </tr>
        <tr>  
            <td width="30%"><label>E_mail</label></td>  
            <td width="70%">'.$row["E_mail"].'</td>  
        </tr>
        <tr>  
            <td width="30%"><label>CNIC_NO</label></td>  
            <td width="70%">'.$row["CNIC_NO"].'</td>  
        </tr>
        <tr>  
            <td width="30%"><label>Password</label></td>  
            <td width="70%">'.$row["Password"].'</td>  
        </tr>
		
		 <tr>  
            <td width="30%"><label>City</label></td>  
            <td width="70%">'.$row["City"].'</td>  
        </tr>
		
		 <tr>  
            <td width="30%"><label>Location</label></td>  
            <td width="70%">'.$row["Location"].'</td>  
        </tr>
		
		 <tr>  
            <td width="30%"><label>Specilization</label></td>  
            <td width="70%">'.$row["Specilization"].'</td>  
        </tr>
		 <tr>  
            <td width="30%"><label>Fee</label></td>  
            <td width="70%">'.$row["Fee"].'</td>  
        </tr>
        
     ';
    }
    $output .= '</table></div>';
    echo $output;
}
?>