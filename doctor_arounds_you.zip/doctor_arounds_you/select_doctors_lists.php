<?php  
//select.php  
if(isset($_POST["user_id"]))
{
 $output = '';
 $con = mysqli_connect("localhost", "root", "", "doctor_arounds_you");
 $query = "SELECT * FROM doctors_lists WHERE id = '".$_POST["user_id"]."'";
 $result = mysqli_query($con, $query);
 $output .= '  
      <div class="table-responsive">  
           <table class="table table-bordered">';
    while($row = mysqli_fetch_array($result))
    {
     $output .= '
     <tr>  
            <td width="30%"><label>Enter_Name</label></td>  
            <td width="70%">'.$row["Enter_Name"].'</td>  
        </tr>
        <tr>  
            <td width="30%"><label>Contact</label></td>  
            <td width="70%">'.$row["Contact"].'</td>  
        </tr>
        <tr>  
            <td width="30%"><label>Availability</label></td>  
            <td width="70%">'.$row["Availability"].'</td>  
        </tr>
        <tr>  
            <td width="30%"><label>Fee</label></td>  
            <td width="70%">'.$row["Fee"].'</td>  
        </tr>
        
     ';
    }
    $output .= '</table></div>';
    echo $output;
}
?>