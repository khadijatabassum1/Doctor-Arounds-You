
<?php

session_start();
include("includes/db.php");

	$query = "SELECT * FROM admins ORDER BY id DESC";
$result = mysqli_query($con, $query);





?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Doctor Arounds You</title>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
	<link href="css/bootstrap-theme.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-T8Gy5hrqNKT+hzMclPo118YTQO6cYprQmhrYwIiQ/3axmI1hQomh7Ud2hPOy8SP1" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">


	
	</head>
<body>
<div class="bgimg">
<div class="header">
<nav class="navbar navbar-expand-md bg-dark navbar-dark fixed-top">
<div class="container">
<a href="home1.php" class="navbar-brand text-danger font-weight-bold"  ><b><h2>Doctor Arounds You</b></h2></a>

<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsenavber">
<span class="navbar-toggler-icon">
</span>
 </button>
 <div class="collapse navbar-collapse text-center " id="collapsenavber">
 <!-- ml-auto means margin left auto-->
 <ul class="navbar-nav ml-auto">
  <li class="nav-item">
 <a href="home1.php" class="nav-link text-white">Home</a>
 </li>
 
   <li class="nav-item">
 <a href="about_us.php" class="nav-link text-white">About Us</a>
 </li>
 <li class="nav-item">
 <a href="admin.php" class="nav-link text-white">Admin</a>

 <ul><a href="doctor_signup.php">Doctor Sign Up</a></ul>
 </li>
 <li class="nav-item">
 <a href="doctor.php" class="nav-link text-white">Doctor</a>
 </li>
 <li class="nav-item">
 <a href="contact_us.php" class="nav-link text-white">Contact Us</a>
 </li>
  
 
   <li class="nav-item">
 <a href="user.php" class="nav-link text-white">User</a>
 </li>
  <li class="nav-item">
 <a href="logout.php" class="nav-link text-white">Logout</a>
 </li>
 
 </ul>
 </div>
</div>

</div>

</nav>



<br /><br />
  
  <div class="container" style="width:700px;">  
   <br>
   <br /> 
 <br>
   <br /> 
 <br>
   <br />    
   <div class="table-responsive" >
    <div align="right">
     <button type="button" name="age" id="age" data-toggle="modal" data-target="#add_data_Modal" class="btn btn-warning">Add</button>
    </div>
    <br />
    <div id="admins_table">
     <table class="table table-bordered">
      <tr>
       <th width="70%">Admin Name</th>  
       <th width="30%">View</th>
      </tr>
      <?php
	
      while($row = mysqli_fetch_array($result))
      {
      ?>
      <tr>
       <td><?php echo $row["Enter_Name"]; ?></td>
       <td><input type="button" name="view" value="view" id="<?php echo $row["id"]; ?>" class="btn btn-info btn-xs view_data" /></td>
      </tr>
      <?php
      }
      ?>
     </table>
    </div>
   </div>  
  </div>


<br /><br /> 
<br /><br />
<br /><br />
<br /><br />
<br /><br />
<br /><br /> 
<br /><br />
<br /><br />
<br /><br />
<br /><br />
<br /><br />
<br /><br />
<br /><br />
<br /><br />
<br /><br />


<!--fixed footer-->
<div class="navbar navbar-inverse navbar-fixed-bottom" role="navigation">
<div class="container">
<div class="navbar-text pull-left">


<h6 class="text-center">&copy; 2019, Design by Khadija Tabassum</h6>
 </div>
 <div class="navbar-text pull-right">
 <a href="https://www.facebook.com/"><i class="fa fa-facebook-square fa-2x"></i></a>
 <a href="https://twitter.com/Twitter"><i class="fa fa-twitter fa-2x"></i></a>
<a href="https://plus.google.com/discover"><i class="fa fa-google-plus fa-2x"></i></a>
</div>
</div>
</div>




</body>
</html>


<div id="add_data_Modal" class="modal fade">
 <div class="modal-dialog" >
  <div class="modal-content">
   <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">&times;</button>
	<br>
	<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

   
   </div>

   
<div class="container">
    <div class="row vertical-offset-100" >
	<div class = "col-md-4 col-ml-12" >
		
	</div>


<div class="col-md-4 ">
    		<div class="panel panel-default" >
			  	<div class="panel-heading">
			    	<b><h2 class="panel-title " style="color:pink;">Admin's Menu</b></h2>
			 	</div>
				
   <div class="modal-body">
    <form method="post" id="insert_form" >
	
     
     
	 <div class="row">
	 <label>Enter Admin Name</label>
	 <div class="input-group col-ml-12">
	   <span class="input-group-addon" id="inputGroupPrepend"><i class="glyphicon glyphicon-user"></i></span>
      
     <input type="text" name="Enter_Name" id="Enter_Name" class="form-control" />
     </div>
   </div>
	 <br />
    
	 <div class="row">
     <label>Enter Email </label>
	 <div class="input-group">
	   <span class="input-group-addon" id="inputGroupPrepend"><i class="glyphicon glyphicon-envelope"></i></span>
        
     <input type="text" name="Email" id="Email" class="form-control" />
     </div>
	 </div>

	 <br />  
	 <div class="row">
	
	 <label>Enter Password</label>
	 <div class="input-group">
	   <span class="input-group-addon" id="inputGroupPrepend"><i class="glyphicon glyphicon-lock"></i></span>
      
     <input type="text" name="Password" id="Password" class="form-control" />
     </div>
  </div>
	 <br />
	 
     <input type="submit" name="insert" id="insert" value="Insert" class="btn btn-success" />

    </form>
   </div>
   <div class="modal-footer">
    <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
   </div>
  </div>
 </div>
</div>

 

<div id="dataModal" class="modal fade">
 <div class="modal-dialog">
  <div class="modal-content">
   <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">&times;</button>
    <h4 class="modal-title">Admin's Details</h4>
   </div>
   <div class="modal-body" id="admins_detail">
    
   </div>
   <div class="modal-footer">
    <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
   </div>
  </div>
 </div>
</div>


<script>  
$(document).ready(function(){
 $('#insert_form').on("submit", function(event){  
  event.preventDefault(); 
if($('#Enter_Name').val() == "")  
  {  
   alert("Name is required");  
  }  
 else  if($('#Email').val() == "")  
  {  
   alert("Email Address is required");  
  }  
  else if($('#Password').val() == '')  
  {  
   alert("Password is required");  
  }  
  
   
  else  
  {  
   $.ajax({  
    url:"insert_admin.php",  
    method:"POST",  
    data:$('#insert_form').serialize(),  
    beforeSend:function(){  
     $('#insert').val("Inserting");  
    },  
    success:function(data){  
     $('#insert_form')[0].reset();  
     $('#add_data_Modal').modal('hide');  
     $('#admins_table').html(data);  
    }  
   });  
  }  
 });




 $(document).on('click', '.view_data', function(){
  //$('#dataModal').modal();
  var user_id = $(this).attr("id");
  $.ajax({
   url:"select_admins.php",
   method:"POST",
   data:{user_id:user_id},
   success:function(data){
    $('#admins_detail').html(data);
    $('#dataModal').modal('show');
   }
  });
 });
});  
 </script>

