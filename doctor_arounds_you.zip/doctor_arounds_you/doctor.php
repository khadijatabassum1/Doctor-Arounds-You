<?php
include("includes/db.php");
$query = "SELECT * FROM doctors ORDER BY id DESC";
$result = mysqli_query($con, $query);


?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Doctor Arounds You</title>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-T8Gy5hrqNKT+hzMclPo118YTQO6cYprQmhrYwIiQ/3axmI1hQomh7Ud2hPOy8SP1" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">


	
	</head>
<body>
<div class="bgimg">
<div class="header">
<nav class="navbar navbar-expand-md bg-dark navbar-dark fixed-top">
<div class="container">
<a href="home1.php" class="navbar-brand text-danger font-weight-bold"  ><h2><b>Doctor Arounds You</h2></b></a>

<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsenavber">
<span class="navbar-toggler-icon">
</span>
 </button>
 <div class="collapse navbar-collapse text-center " id="collapsenavber">
 <!-- ml-auto means margin left auto-->
 <ul class="navbar-nav ml-auto">
  <li class="nav-item">
 <a href="home1.php" class="nav-link text-white">Home</a>
 </li>
 
  
 
   <li class="nav-item">
  
 <a href="about_us.php" class="nav-link text-white">About Us</a>

 
 </li>
 <li class="nav-item">
 <a href="admin.php" class="nav-link text-white">Admin</a>
 </li>
 <li class="nav-item">

 <a href="doctor.php" class="nav-link text-white">Doctor</a>
  <ul> <a href="doctors_lists.php" >Doctor List</a>
  <a href="doctor_specility.php">DOCTORS BY SPECIALITY</a>
 </ul>
 </li>
 <li class="nav-item">
 <a href="contact_us.php" class="nav-link text-white">Contact Us</a>
 </li>
  
 
   <li class="nav-item">
 <a href="user.php" class="nav-link text-white">User</a>
 </li>
  <li class="nav-item">
 <a href="index.php" class="nav-link text-white">Logout</a>
 </li>
 
 </ul>
 </div>
</div>
</div>
</nav>





<br /><br />  
  <div class="container" style="width:700px;">  
   <br>
   <br /> 
 <br>
   <br /> 
 <br>
   <br />    
   <div class="table-responsive">
    <div align="right">
     <button type="button" name="age" id="age" data-toggle="modal" data-target="#add_data_Modal" class="btn btn-warning">Add</button>
    </div>
    <br />
    <div id="doctors_table">
     <table class="table table-bordered">
      <tr>
       <th width="70%">Doctor Name</th>  
       <th width="30%">View</th>
      </tr>
      <?php
	
      while($row = mysqli_fetch_array($result))
      {
      ?>
      <tr>
       <td><?php echo $row["Enter_Name"]; ?></td>
       <td><input type="button" name="view" value="view" id="<?php echo $row["id"]; ?>" class="btn btn-info btn-xs view_data" /></td>
      </tr>
      <?php
      }
      ?>
     </table>
    </div>
   </div>  
  </div>








<div class="container ">
<div class="row vertical-offset-100">
	<div class = "col-md-6">
		
	</div>
 <a href="doctor.php"><button class="btn btn-danger text-white btn-lg"><i class="fa fa-map-marker"></i> Get Map</button></a>
  	</div>
		</div>
  
  <br>
  
<!--Google map-->
<div id="map-container" class="z-depth-1-half map-container mb-5" style="height: 400px"></div>
<!-- SCRIPTS -->
<!-- JQuery -->
<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="js/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="js/mdb.min.js"></script>

<!--Google Maps-->
<script src="https://maps.google.com/maps/api/js"></script>
<!-- Google Maps settings -->
<script>
  // Regular map
function regular_map() {
    var var_location = new google.maps.LatLng(40.725118, -73.997699);

    var var_mapoptions = {
      center: var_location,
      zoom: 14
    };

    var var_map = new google.maps.Map(document.getElementById("map-container"),
      var_mapoptions);

    var var_marker = new google.maps.Marker({
      position: var_location,
      map: var_map,
      title: "Lahore"
    });
  }

  // Initialize maps
  google.maps.event.addDomListener(window, 'load', regular_map);
</script>
<!--Grid row-->
<div class="row text-center">

  <!--Grid column-->
  <div class="col-lg-4 col-md-12 mb-3">

      <p><i class="fa fa-map fa-1x mr-2 grey-text"></i>Pakistan, PK Lahore</p>

  </div>
  <!--Grid column-->

  <!--Grid column-->
  <div class="col-lg-4 col-md-6 mb-3">

      <p><i class="fa fa-building fa-1x mr-2 grey-text"></i>Mon - Fri, 8:00-22:00</p>

  </div>
  <!--Grid column-->

  <!--Grid column-->
  <div class="col-lg-4 col-md-6 mb-3">

      <p><i class="fa fa-phone fa-1x mr-2 grey-text"></i>+ 92 3007 567 89</p>

  </div>
  <!--Grid column-->

</div>
<!--Grid row-->



<!--fixed footer-->
<div class="navbar navbar-inverse navbar-fixed-bottom" role="navigation">
<div class="container">
<div class="navbar-text pull-left">


<h6 class="text-center">&copy; 2019, Design by Khadija Tabassum</h6>
 </div>
 <div class="navbar-text pull-right">
 <a href="https://www.facebook.com/"><i class="fa fa-facebook-square fa-2x"></i></a>
 <a href="https://twitter.com/Twitter"><i class="fa fa-twitter fa-2x"></i></a>
<a href="https://plus.google.com/discover"><i class="fa fa-google-plus fa-2x"></i></a>
</div>
</div>
</div>



</body>
</html>





<div id="add_data_Modal" class="modal fade">
 <div class="modal-dialog" >
  <div class="modal-content">
   <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">&times;</button>
	<br>
<br>
<br>
<br>
<br>
<br>
<br>

   
   </div>
   <br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
   
<div class="container">
    <div class="row vertical-offset-100">
	<div class = "col-md-4 col-ml-auto" >
		
	</div>

<div class="col-md-4 ">
    		<div class="panel panel-default" >
			  	<div class="panel-heading">
			    	<b><h2 class="panel-title " style="color:pink;">Doctor</b></h2>
			 	</div>
				
   <div class="modal-body">
    <form method="post" id="insert_form" width="100%">
	
<div class="row">
	<label>Search Doctor</label>
	<select name="Enter_Name" id="Enter_Name" class="form-control">
	
      <option value="">Search Here</option>
	  <b><option value="Acupuncturist">Acupuncturist</option></b>

	   <option value="Dr.Mohammed Mohsin
Acupuncturist
M.B.B.S, M.D(U.S.A..">Dr.Mohammed Mohsin
Acupuncturist
M.B.B.S, M.D(U.S.A..</option>
	  <option value="Dr. Saima Naeem
Acupuncturist
Acupuncturist Cons..">Dr. Saima Naeem
Acupuncturist
Acupuncturist Cons..</option>
	  <option value="Prof. Dr. Rifat Hashmi
Acupuncturist
M.D(M.A); M.D(Hom)..">Prof. Dr. Rifat Hashmi
Acupuncturist
M.D(M.A); M.D(Hom)..</option>
	  <option value="Abul Samad Khan Kakar
Acupuncturist">Abul Samad Khan Kakar
Acupuncturist</option>
	  <option value="Dr. Jaffry Zameer Hussain
Acupuncturist">Dr. Jaffry Zameer Hussain
Acupuncturist</option>
	   <option value="Dr. Nighat Tahira
Acupuncturist">Dr. Nighat Tahira
Acupuncturist</option>
	  <option value="Dr. Rehana Usman Khan
Acupuncturist">Dr. Rehana Usman Khan
Acupuncturist</option>
	  <option value="Dr. Muhammad Shafique
Acupuncturist">Dr. Muhammad Shafique
Acupuncturist</option>
	  <option value="Dr. S. Kaniz Abidi
Acupuncturist">Dr. S. Kaniz Abidi
Acupuncturist</option>
	  <option value="Dr Khalil
Acupuncturist
consultant acupunc">Dr Khalil
Acupuncturist
consultant acupunc</option>
	   <option value="Sulman Ali
Acupuncturist">Sulman Ali
Acupuncturist</option>
	  <option value="Allergist"><b>Allergist</b></option>

	  <option value="Dr. Asif Ali Imam
Allergist
M.B.B.S.">Dr. Asif Ali Imam
Allergist
M.B.B.S.</option>
	  <option value="Andrologist"><b>Andrologist</b></option>
	   <option value="Dr. Tanveer Ahmad
Breast Surgeon
MBBS">Dr. Tanveer Ahmad
Breast Surgeon
MBBS</option>
	   <option value="Dr. Andleeb Khanam
Breast Surgeon
MBBS,FCPS">Dr. Andleeb Khanam
Breast Surgeon
MBBS,FCPS</option>
	  <option value="Cardiac Surgeon"><b>Cardiac Surgeon</b></option>
	  <option value="Saeed Afridi
Cardiac Surgeon
MBBS, MD, MS, FACS">Saeed Afridi
Cardiac Surgeon
MBBS, MD, MS, FACS</option>
	  <option value="Dr. Imran Khan
Cardiac Surgeon
MBBS, FCPS (cardia..">Dr. Imran Khan
Cardiac Surgeon
MBBS, FCPS (cardia..</option>
	  <option value="Dr. Nadeem Hayat Malik
Cardiac Surgeon
MBBS, MRCP. (UK) D..">Dr. Nadeem Hayat Malik
Cardiac Surgeon
MBBS, MRCP. (UK) D..</option>
	   <option value="Dr. Naeem Shah
Cardiac Surgeon
MBBS, MD (Rom) - C..">Dr. Naeem Shah
Cardiac Surgeon
MBBS, MD (Rom) - C..</option>
	  <option value="Dr. Fayyaz Haidar Hashmi
Cardiac Surgeon
MD, FACS - Cardiac..">Dr. Fayyaz Haidar Hashmi
Cardiac Surgeon
MD, FACS - Cardiac..</option>
	  <option value="Dr. Khalid Hameed
Cardiac Surgeon
MBBS, FRCS - Cardi..">Dr. Khalid Hameed
Cardiac Surgeon
MBBS, FRCS - Cardi..</option>
	  <option value="Dr. Mohammad Abdullah Jan
Cardiac Surgeon
MD , DAB - Cardiac..">Dr. Mohammad Abdullah Jan
Cardiac Surgeon
MD , DAB - Cardiac..</option>
	  <option value="Dr. Mohammad Sarwar
Cardiac Surgeon
MBBS, M ACP. FACC ..">Dr. Mohammad Sarwar
Cardiac Surgeon
MBBS, M ACP. FACC ..</option>
	   <option value="Dr. Mubashar A.Chaudhry
Cardiac Surgeon
MD, FACC , DAB(Car..">Dr. Mubashar A.Chaudhry
Cardiac Surgeon
MD, FACC , DAB(Car..</option>
	  <option value="Dr. Rehan Mehmood
Cardiac Surgeon
MBBS, MD DAB - Car..">Dr. Rehan Mehmood
Cardiac Surgeon
MBBS, MD DAB - Car..</option>
	  <option value="Prof. Ashraf A.Khan
Cardiac Surgeon
MD, FACC , DAB - C..">Prof. Ashraf A.Khan
Cardiac Surgeon
MD, FACC , DAB - C..</option>
	  <option value="Dr. Nasir Iqbal Butt
Cardiac Surgeon
MB, Dip Card , MAS..">Dr. Nasir Iqbal Butt
Cardiac Surgeon
MB, Dip Card , MAS..</option>
	  <option value="Dr. Mohsin Nazir
Cardiac Surgeon
MBBS, FCPS, (Card)..">Dr. Mohsin Nazir
Cardiac Surgeon
MBBS, FCPS, (Card)..</option>
	   <option value="Dr. Irshad Hussain
Cardiac Surgeon
MBBS, FCPS - Cardi..">Dr. Irshad Hussain
Cardiac Surgeon
MBBS, FCPS - Cardi..</option>
	  <option value="Dr. Shahid Malik
Cardiac Surgeon
MBBS, FRCS - Cardi..">Dr. Shahid Malik
Cardiac Surgeon
MBBS, FRCS - Cardi..</option>
	  <option value="Dr. Bilal Zakariah Khan
Cardiac Surgeon
MBBS, MRCP(UK) - C..">Dr. Bilal Zakariah Khan
Cardiac Surgeon
MBBS, MRCP(UK) - C..</option>
	  <option value="Dr. M. Ashraf
Cardiac Surgeon
MBBS, MCPS, M.Sc -..">Dr. M. Ashraf
Cardiac Surgeon
MBBS, MCPS, M.Sc -..</option>
	  <option value="Dr. Mukhtar Ahmad
Cardiac Surgeon
MBBS, FRCS - Cardi..">Dr. Mukhtar Ahmad
Cardiac Surgeon
MBBS, FRCS - Cardi..</option>
	   <option value="Dr. Saulat Siddique
Cardiac Surgeon
MBBS, MRCP. (UK) -..">Dr. Saulat Siddique
Cardiac Surgeon
MBBS, MRCP. (UK) -..</option>
	  <option value="Dr. Najam Ayub Minhas
Cardiac Surgeon
MBBS, Dip, Card FI..">Dr. Najam Ayub Minhas
Cardiac Surgeon
MBBS, Dip, Card FI..</option>
	  <option value="Dr. Ismat Khan
Cardiac Surgeon
MBBS, D.Card , DTM..">Dr. Ismat Khan
Cardiac Surgeon
MBBS, D.Card , DTM..</option>
	  <option value="Dr. Zarar Hussain Shah
Cardiac Surgeon
MBBS, Dip Card , M..">Dr. Zarar Hussain Shah
Cardiac Surgeon
MBBS, Dip Card , M..</option>
	  <option value="Dr. Shahbaz Sarwar
Cardiac Surgeon
MBBS, Dip Card (pk..">Dr. Shahbaz Sarwar
Cardiac Surgeon
MBBS, Dip Card (pk..</option>
	   <option value="Dr. Ansar Haider
Cardiac Surgeon
MBBS, Dip Card , F..">Dr. Ansar Haider
Cardiac Surgeon
MBBS, Dip Card , F..</option>
	  <option value="Dr. Ajmal Hassan
Cardiac Surgeon">Dr. Ajmal Hassan
Cardiac Surgeon</option>
	  <option value="Dr. Abdul Waheed
Cardiac Surgeon
MBBS, FCPS, - Card..">Dr. Abdul Waheed
Cardiac Surgeon
MBBS, FCPS, - Card..</option>
	  <option value="Dr. Liaqat Ali
Cardiac Surgeon
MBBS, FCPS, - Card..">Dr. Liaqat Ali
Cardiac Surgeon
MBBS, FCPS, - Card..</option>
	  <option value="Dr. M.A Cheema
Cardiac Surgeon
MBBS, FRCS , FCPS,..">Dr. M.A Cheema
Cardiac Surgeon
MBBS, FRCS , FCPS,..</option>
	   <option value="Dr. Mohammad Ayub
Cardiac Surgeon
MBBS, FCPS, - Card..">Dr. Mohammad Ayub
Cardiac Surgeon
MBBS, FCPS, - Card..</option>
	  <option value="Dr. A. Hafeez Khan
Cardiac Surgeon
MBBS, FRCS , FCPS,..">Dr. A. Hafeez Khan
Cardiac Surgeon
MBBS, FRCS , FCPS,..</option>
	  <option value="Dr. Mohammad Yahya
Cardiac Surgeon
MBBS, FRCS (Edin)D..">Dr. Mohammad Yahya
Cardiac Surgeon
MBBS, FRCS (Edin)D..</option>
	  <option value="Dr. Raja Pervaiz Akhtar
Cardiac Surgeon
MBBS, FRCS - Cardi..">Dr. Raja Pervaiz Akhtar
Cardiac Surgeon
MBBS, FRCS - Cardi..</option>
	  <option value="Dr. Afzal Najeeb
Cardiac Surgeon
MBBS, FRCP - Cardi..">Dr. Afzal Najeeb
Cardiac Surgeon
MBBS, FRCP - Cardi..</option>
	   <option value="Dr. Guhlam Shabir Yazdani
Cardiac Surgeon
MBBS, Dip, Card - ..">Dr. Guhlam Shabir Yazdani
Cardiac Surgeon
MBBS, Dip, Card - ..</option>
	  <option value="Dr. Mushtaq Shahid
Cardiac Surgeon
MBBS, FCPS, , Dip ..">Dr. Mushtaq Shahid
Cardiac Surgeon
MBBS, FCPS, , Dip ..</option>
	  <option value="Dr. Nasir Butt
Cardiac Surgeon
MBBS, Dip Card - C..">Dr. Nasir Butt
Cardiac Surgeon
MBBS, Dip Card - C..</option>
	  <option value="Chest Physician"><b>Chest Physician</b></option>
	  <option value="Zaheer Akhtar Prof.
Chest Physician
FCPS, FCCP, USA">Zaheer Akhtar Prof.
Chest Physician
FCPS, FCCP, USA</option>
	  <option value="Child Specialist "><b>Child Specialist </b></option>
	  <option value="Major (retd) Dr Suneel ..
Child Specialist
M.B.B.S,D.C.H,PGPN">Major (retd) Dr Suneel ..
Child Specialist
M.B.B.S,D.C.H,PGPN</option>
	  <option value="Dr Waseem Pasha
Child Specialist
MBBS, DCH, PGPN (U..">Dr Waseem Pasha
Child Specialist
MBBS, DCH, PGPN (U..</option>
	  <option value="Dr Rahat Malik
Child Specialist
M.B.B.S (fmc), M.C..">Dr Rahat Malik
Child Specialist
M.B.B.S (fmc), M.C..</option>
	  <option value="Dr Muhammad Faheem CH
Child Specialist
MBBS, DCH">Dr Muhammad Faheem CH
Child Specialist
MBBS, DCH</option>
	   <option value="Dr Irshad Hasan Khan
Child Specialist
MBBS, DCH">Dr Irshad Hasan Khan
Child Specialist
MBBS, DCH</option>
	  <option value="Dr. Abid Faryad
Child Specialist
MBBS,FCPS">Dr. Abid Faryad
Child Specialist
MBBS,FCPS</option>
	  <option value="Dental Surgeon"><b>Dental Surgeon</b></option>
	  <option value="Dr Aqib Mudassar
Dental Surgeon
DDS">Dr Aqib Mudassar
Dental Surgeon
DDS</option>
	  <option value="Dr.Tauqir Warsi
Dental Surgeon
Mbbs.England Speci..">Dr.Tauqir Warsi
Dental Surgeon
Mbbs.England Speci..</option>
	   <option value="Dr Tauqir Kamboh
Dental Surgeon
M.bb.s Canada brom..">Dr Tauqir Kamboh
Dental Surgeon
M.bb.s Canada brom..</option>
	  <option value="Dr Mahwish Mumtaz
Dental Surgeon
doctor of dental s.">Dr Mahwish Mumtaz
Dental Surgeon
doctor of dental s.</option>
	  <option value="Dr Naureen Sarwar
Dental Surgeon
MDS, MPhil, Diplom..">Dr Naureen Sarwar
Dental Surgeon
MDS, MPhil, Diplom..</option>
	  <option value="Dr Rashid Javaid
Dental Surgeon
B.D.S, M.Phil">Dr Rashid Javaid
Dental Surgeon
B.D.S, M.Phil</option>
	  <option value="Dr. Shoaib A. Kazi
Dental Surgeon
B.D.S, B.Sc, FCPS">Dr. Shoaib A. Kazi
Dental Surgeon
B.D.S, B.Sc, FCPS</option>
	   <option value="Dr. Zahid Subhani
Dental Surgeon
BDS">Dr. Zahid Subhani
Dental Surgeon
BDS</option>
	  <option value="Dr Zaheer Iqbal
Dental Surgeon
B.D.S">Dr Zaheer Iqbal
Dental Surgeon
B.D.S</option>
	  <option value="Dr Fahad Bajwa
Dental Surgeon
BDS,RDS,MHA">Dr Fahad Bajwa
Dental Surgeon
BDS,RDS,MHA</option>
	  <option value="DERMATOLOGIST IN HOSPITALS"><b>DERMATOLOGIST IN HOSPITALS</b></option>
	  <option value="Dr. Sabrina Sohail
Dermatologist">Dr. Sabrina Sohail
Dermatologist</option>
	   <option value="Dr Sayed Jawad Afzal
Dermatologist
MBBS,MCPS">Dr Sayed Jawad Afzal
Dermatologist
MBBS,MCPS</option>
	  <option value="Dr. Iram Ashraf
Dermatologist
M.B.B.S, Dip Derm ..">Dr. Iram Ashraf
Dermatologist
M.B.B.S, Dip Derm ..</option>
	  <option value="Dr. Muhammad Khawar Nazir
Dermatologist
MBBS, MS Dermatolo..">Dr. Muhammad Khawar Nazir
Dermatologist
MBBS, MS Dermatolo..</option>
	  <option value="Tariq Niaz Butt
Dermatologist
MBBS, D. Derm (UK)..">Tariq Niaz Butt
Dermatologist
MBBS, D. Derm (UK)..</option>
	  <option value="Zarqa Taimor Suharwardy
Dermatologist
MBBS,FCPS">Zarqa Taimor Suharwardy
Dermatologist
MBBS,FCPS</option>
	   <option value="Umer Mushtaq
Dermatologist
MBBS, FCPS (Dermat..">Umer Mushtaq
Dermatologist
MBBS, FCPS (Dermat..</option>
	  <option value="Sehrish Ashraf
Dermatologist
MBBS, FCPS (Dermat..">Sehrish Ashraf
Dermatologist
MBBS, FCPS (Dermat..</option>
	  <option value="Uzma Akbar Mirza
Dermatologist
MBBS, Dip. DERM">Uzma Akbar Mirza
Dermatologist
MBBS, Dip. DERM</option>
	  <option value="Zafar Ullah Khan
Dermatologist
MBBS, FCPS, CAAAAM..">Zafar Ullah Khan
Dermatologist
MBBS, FCPS, CAAAAM..</option>
	  <option value="Usman Amiruddin
Dermatologist
MBBS, FCPS (Plasti..">Usman Amiruddin
Dermatologist
MBBS, FCPS (Plasti..</option>
	   <option value="Saleha Zeeshan
Dermatologist
MBBS, MCPS">Saleha Zeeshan
Dermatologist
MBBS, MCPS</option>
	  <option value="Qurat-ul-ain Sajida
Dermatologist
MBBS, MCPS (Dermat..">Qurat-ul-ain Sajida
Dermatologist
MBBS, MCPS (Dermat..</option>
	  <option value="Dr. Faria Asad
Dermatologist
MBBS,FCPS">Dr. Faria Asad
Dermatologist
MBBS,FCPS</option>
	  <option value="DR. BURHAN ASHRAF
Dermatologist
MBBS">DR. BURHAN ASHRAF
Dermatologist
MBBS</option>
	  <option value="Samina Kausar
Dermatologist
MBBS, MCPS">Samina Kausar
Dermatologist
MBBS, MCPS</option>
	   <option value="Dr. Arif Rahim
Dermatologist">Dr. Arif Rahim
Dermatologist</option>
	  <option value="Dr. Aly Feroze
Dermatologist">Dr. Aly Feroze
Dermatologist</option>
	  <option value="Dr. Muhammad Luqman Ahmed
Dermatologist">Dr. Muhammad Luqman Ahmed
Dermatologist</option>
	  <option value="Dr. Maryam Rafat
Dermatologist">Dr. Maryam Rafat
Dermatologist</option>
	  <option value="Dr. Nabila Yusuf
Dermatologist">Dr. Nabila Yusuf
Dermatologist</option>
	   <option value="Dr. Zahid Shahzad
Dermatologist">Dr. Zahid Shahzad
Dermatologist</option>
	  <option value="Dr. A.Rafi Masood
Dermatologist">Dr. A.Rafi Masood
Dermatologist</option>
	  <option value="Dr. Faryal Athar
Dermatologist
dip derm UK. membe..">Dr. Faryal Athar
Dermatologist
dip derm UK. membe..</option>
	  <option value="Dr. Attiya Mahboob
Dermatologist">Dr. Attiya Mahboob
Dermatologist</option>
	  <option value="Dr. Khawar Khursheed
Dermatologist">Dr. Khawar Khursheed
Dermatologist</option>
	   <option value="Dr. Naveed Shehzad Mrs
Dermatologist">Dr. Naveed Shehzad Mrs
Dermatologist</option>
	  <option value="Dr. Sohail Sheikh
Dermatologist">Dr. Sohail Sheikh
Dermatologist</option>
	  <option value="Dr. Omar H.Shaikh
Dermatologist">Dr. Omar H.Shaikh
Dermatologist</option>
	  <option value="Dr. Haseeb Sajjad
Dermatologist">Dr. Haseeb Sajjad
Dermatologist</option>
	  <option value="Dr. Atif Kazami
Dermatologist">Dr. Atif Kazami
Dermatologist</option>
	   <option value="Dr. Agha Nasrullah Khan
Dermatologist
MBBS .D. Derm - De..">Dr. Agha Nasrullah Khan
Dermatologist
MBBS .D. Derm - De..</option>
	  <option value="Dr. Khalid Mehmood
Dermatologist
MBBS D.D.V (Austri..">Dr. Khalid Mehmood
Dermatologist
MBBS D.D.V (Austri..</option>
	  <option value="Dr. Laquman Ahmad
Dermatologist
MBBS, FCPS - Derma..">Dr. Laquman Ahmad
Dermatologist
MBBS, FCPS - Derma..</option>
	  <option value="Dr. Muhammd Faisal Nawaz
Dermatologist
BSc, MBBS - Dermat..">Dr. Muhammd Faisal Nawaz
Dermatologist
BSc, MBBS - Dermat..</option>
	  <option value="Dr. Ghazanfar Ilahi
Dermatologist
MBBS , D.Derm , M...">Dr. Ghazanfar Ilahi
Dermatologist
MBBS , D.Derm , M...</option>
	   <option value="DIABETOLOGISTS IN HOSPITALS"><b>DIABETOLOGISTS IN HOSPITALS</b></option>
	  <option value="Dr. Asad Saeed
Diabetologists
MBBS, DABIM">Dr. Asad Saeed
Diabetologists
MBBS, DABIM</option>
	  <option value="Dr. Tahir H.Malik
Diabetologists
MBBS, MRCP, DGM">Dr. Tahir H.Malik
Diabetologists
MBBS, MRCP, DGM</option>
	  <option value="Dr. Raheel Akbar
Diabetologists">Dr. Raheel Akbar
Diabetologists</option>
	  <option value="Prof Zaheer Akhtar
Diabetologists
FCPS FCCP USA">Prof Zaheer Akhtar
Diabetologists
FCPS FCCP USA</option>
	   <option value="Jamal Bukhari
Diabetologists
Bsc, mbbs, fcps">Jamal Bukhari
Diabetologists
Bsc, mbbs, fcps</option>
	  <option value="ENDOCRINOLOGIST IN HOSPITALS"><b>ENDOCRINOLOGIST IN HOSPITALS</b></option>
	  <option value="Dr. Zaar
Endocrinologist
MBBS, MD, PhD, FRC..">Dr. Zaar
Endocrinologist
MBBS, MD, PhD, FRC..</option>
	  <option value="Dr Fawad Ahmad Randhawa
Endocrinologist
MBBS, FCPS (Endocr..">Dr Fawad Ahmad Randhawa
Endocrinologist
MBBS, FCPS (Endocr..</option>
	  <option value="Maliha Hameed
Endocrinologist
MBBS, FCPS (Medici..">Maliha Hameed
Endocrinologist
MBBS, FCPS (Medici..</option>
	   <option value="Jaida Manzoor
Endocrinologist
MBBS, FCPS">Jaida Manzoor
Endocrinologist
MBBS, FCPS</option>
	  <option value="Amena Moazzam Baig
Endocrinologist
MBBS, MRCP, FCPS (..">Amena Moazzam Baig
Endocrinologist
MBBS, MRCP, FCPS (..</option>
	  <option value="Gulshad Hasan
Endocrinologist
MBBS, MRCP (UK), F..">Gulshad Hasan
Endocrinologist
MBBS, MRCP (UK), F..</option>
	  <option value="Shehzad Ul Haq
Endocrinologist
MD, FACE, Diplomat..">Shehzad Ul Haq
Endocrinologist
MD, FACE, Diplomat..</option>
	  <option value="Dr. Raees Ahsan Mushtaq
Endocrinologist
MBBS,DIPLOMA IN DI..">Dr. Raees Ahsan Mushtaq
Endocrinologist
MBBS,DIPLOMA IN DI..</option>
	  <option value="Dr. Imran Abdullah
Endocrinologist
M.B.BS. MS NUCLEAR..">Dr. Imran Abdullah
Endocrinologist
M.B.BS. MS NUCLEAR..</option>
	  <option value="Dr.Syed Abbass Raza
Endocrinologist
MBBS - Endocrinolo..">Dr.Syed Abbass Raza
Endocrinologist
MBBS - Endocrinolo..</option>
	  <option value="Dr.Muhammad Javaid Shah
Endocrinologist
M.B.B.S,M.SC,M.C.P.S">Dr.Muhammad Javaid Shah
Endocrinologist
M.B.B.S,M.SC,M.C.P.S</option>
	  <option value="Awais Masood
Endocrinologist
MBBS, Diplomate Am..">Awais Masood
Endocrinologist
MBBS, Diplomate Am..</option>
	  <option value="Muhammad Tabish Raza
Endocrinologist
MBBS,MD,(USA), FCP..">Muhammad Tabish Raza
Endocrinologist
MBBS,MD,(USA), FCP..</option>
	   <option value="ENT SURGEON IN HOSPITALS"><b>ENT SURGEON IN HOSPITALS</b></option>
	  <option value="Ramzan Ali
ENT Surgeon
MD, FCPS (ENT)">Ramzan Ali
ENT Surgeon
MD, FCPS (ENT)</option>
	  <option value="Ijaz Nazir
ENT Surgeon
MBBS, DLO">Ijaz Nazir
ENT Surgeon
MBBS, DLO</option>
	  <option value="Shahid Ghafoor Malik
ENT Surgeon
MBBS, FCPS">Shahid Ghafoor Malik
ENT Surgeon
MBBS, FCPS</option>
	  <option value="Khurshid Alam
ENT Surgeon
F.R.C.S. ORL (UK)...">Khurshid Alam
ENT Surgeon
F.R.C.S. ORL (UK)...</option>
	   <option value="Nasir Riaz
ENT Surgeon
MBBS, FCPS">Nasir Riaz
ENT Surgeon
MBBS, FCPS</option>
	  <option value="Taimoor Latif Malik
ENT Surgeon
MBBS, FCPS (ENT)">Taimoor Latif Malik
ENT Surgeon
MBBS, FCPS (ENT)</option>
	  <option value="Muhammad Awais Amin
ENT Surgeon
BSC, MBBS, FCPS (E..">Muhammad Awais Amin
ENT Surgeon
BSC, MBBS, FCPS (E..</option>
	  <option value="Dr. Ayub Ahmad Khan
ENT Surgeon
MBBS, MCPS (ENT), ..">Dr. Ayub Ahmad Khan
ENT Surgeon
MBBS, MCPS (ENT), ..</option>
	  <option value="Dr Rashid Hameed
ENT Surgeon
MBBS,MCPS ,MS">Dr Rashid Hameed
ENT Surgeon
MBBS,MCPS ,MS</option>
	   <option value="DR MUHAMMAD ARSHAD CHOH..
ENT Surgeon
MBBS-DLO">DR MUHAMMAD ARSHAD CHOH..
ENT Surgeon
MBBS-DLO</option>
	  <option value="Dr. Rashid Zia
ENT Surgeon
ENT CONSULTANT">Dr. Rashid Zia
ENT Surgeon
ENT CONSULTANT</option>
	  <option value="Dr Mazhar Iftikhar
ENT Surgeon
MBBS,FCPS">Dr Mazhar Iftikhar
ENT Surgeon
MBBS,FCPS</option>
	  <option value="Dr Muhammad Ali Raza
ENT Surgeon
M.B;B.S. M.C.P.S (..">Dr Muhammad Ali Raza
ENT Surgeon
M.B;B.S. M.C.P.S (..</option>
	  <option value="Prof Zubair Ahmed
ENT Surgeon
MBBS, DLO.RCS (Lon..">Prof Zubair Ahmed
ENT Surgeon
MBBS, DLO.RCS (Lon..</option>
	   <option value="Dr Aqsa
ENT Surgeon">Dr Aqsa
ENT Surgeon</option>
	  <option value="EYE SURGEON IN HOSPITALS"><b>EYE SURGEON IN HOSPITALS</b></option>
	  <option value="Muhammad Sufyan Aneeq A..
Eye Surgeon
MBBS, FCPS">Muhammad Sufyan Aneeq A..
Eye Surgeon
MBBS, FCPS</option>
	  <option value="Syed Abdullah Mazhar
Eye Surgeon
MBBS, FCPS, MRCS">Syed Abdullah Mazhar
Eye Surgeon
MBBS, FCPS, MRCS</option>
	  <option value="Adeel Randhawa
Eye Surgeon
MBBS,MCPS, FCPS, (..">Adeel Randhawa
Eye Surgeon
MBBS,MCPS, FCPS, (..</option>
	   <option value="Rashid Nawaz
Eye Surgeon
MBBS, MRCS (Optha ..">Rashid Nawaz
Eye Surgeon
MBBS, MRCS (Optha ..</option>
	  <option value="Prof Huma Kayani
Eye Surgeon
MBBS, FCPS, FRCS (..">Prof Huma Kayani
Eye Surgeon
MBBS, FCPS, FRCS (..</option>
	  <option value="Abdul Rauf
Eye Surgeon
MBBS, FCPS">Abdul Rauf
Eye Surgeon
MBBS, FCPS</option>
	  <option value="Waseem Iqbal
Eye Surgeon
MBBS, FCPS (ophth)..">Waseem Iqbal
Eye Surgeon
MBBS, FCPS (ophth)..</option>
	  <option value="Dr Shamshad Ali
Eye Surgeon
MBBS, FCPS OPHTHA..">Dr Shamshad Ali
Eye Surgeon
MBBS, FCPS OPHTHA..</option>
	   <option value="FERTILITY SPECIALIST IN HOSPITALS"><b>FERTILITY SPECIALIST IN HOSPITALS</b></option>
	  <option value="Dr. Mujahid Hussain
Fertility Specialist
MD PH D MISID (USA..">Dr. Mujahid Hussain
Fertility Specialist
MD PH D MISID (USA..</option>
	  <option value="Dr. Rashid Latief Khan
Fertility Specialist">Dr. Rashid Latief Khan
Fertility Specialist</option>
	  <option value="GENERAL PHYSICIAN IN HOSPITALS"><b>GENERAL PHYSICIAN IN HOSPITALS</b></option>
	  <option value="Dr Shahzad Khurram Durr..
General Physician
MBBS">Dr Shahzad Khurram Durr..
General Physician
MBBS</option>
	   <option value="Dr Ashfaq Naru
General Physician
MBBS">
Dr Ashfaq Naru
General Physician
MBBS</option>
	  <option value="Dr Mohammad Asif Hashmi
General Physician
MBBS">Dr Mohammad Asif Hashmi
General Physician
MBBS</option>
	  <option value="Somia Iqtadar
General Physician
MBBS, FCPS (Medici..">Somia Iqtadar
General Physician
MBBS, FCPS (Medici..</option>
	  <option value="Nasir Siddique
General Physician
MBBS, MRCP (UK), F..">Nasir Siddique
General Physician
MBBS, MRCP (UK), F..</option>
	  <option value="Muhammad Ali
General Physician
MBBS, MRCGPS">Muhammad Ali
General Physician
MBBS, MRCGPS</option>
	   <option value="Fatima Hamdani
General Physician
MBBS, FCPS, MRCP(UK)">Fatima Hamdani
General Physician
MBBS, FCPS, MRCP(UK)</option>
	  <option value="Khizer Mehmood
General Physician
MBBS,MRCGP,PLAB (G..">Khizer Mehmood
General Physician
MBBS,MRCGP,PLAB (G..</option>
	  <option value="Atif Masood
General Physician
MBBS, FCPS (Medici..">Atif Masood
General Physician
MBBS, FCPS (Medici..</option>
	  <option value="Farheen Kayani
General Physician
MBBS, MRCGP">Farheen Kayani
General Physician
MBBS, MRCGP</option>
	  <option value="Prof Javed Akram
General Physician
MRCP (UK), FRCP (L..">Prof Javed Akram
General Physician
MRCP (UK), FRCP (L..</option>
	   <option value="Waqas Cheema
General Physician
MBBS, FCPS">Waqas Cheema
General Physician
MBBS, FCPS</option>
	  <option value="Ahmad Malik
General Physician
MBBS, MD (USA)">Ahmad Malik
General Physician
MBBS, MD (USA)</option>
	  <option value="Aisha Sheikh
General Physician
MBBS, MPhiL (Chemi..">Aisha Sheikh
General Physician
MBBS, MPhiL (Chemi..</option>
	  <option value="Dr Qurban Hussain
General Physician
MBBS, MRCP, FCPS (..">Dr Qurban Hussain
General Physician
MBBS, MRCP, FCPS (..</option>
	  <option value="Naeem Ashraf
General Physician
MBBS, MCPS ( Famil..">Naeem Ashraf
General Physician
MBBS, MCPS ( Famil..</option>
	   <option value="Dr Muhammad Jasra Bhatti
General Physician
MBBS FCPS BSc Assi..">Dr Muhammad Jasra Bhatti
General Physician
MBBS FCPS BSc Assi..</option>
	  <option value="Dr SYED ATA UL HALEEM
General Physician
M.B.B.S.">Dr SYED ATA UL HALEEM
General Physician
M.B.B.S.</option>
	  <option value="Dr Amjad Ali Parvez
General Physician">Dr Amjad Ali Parvez
General Physician</option>
	  <option value="Dr Tariq Butt
General Physician">Dr Tariq Butt
General Physician</option>
	  <option value="Anjum Saeed
General Physician">Anjum Saeed
General Physician</option>
	   <option value="Dr.Syed Niaz Muhammad H..
General Physician">Dr.Syed Niaz Muhammad H..
General Physician</option>
	  <option value="Dr ZAHID NISAR
General Physician
MBBS">Dr ZAHID NISAR
General Physician
MBBS</option>
	  <option value="Umair Saleem
General Physician
MBBS">Umair Saleem
General Physician
MBBS</option>
	  <option value="Dr. Fouad Aslam
General Physician
BSc, MBBS">Dr. Fouad Aslam
General Physician
BSc, MBBS</option>
	  <option value="Dr. Azam Yousaf
General Physician">Dr. Azam Yousaf
General Physician</option>
	   <option value="Dr. Yousaf Latif Khan
General Physician">Dr. Yousaf Latif Khan
General Physician</option>
	  <option value="Dr. Adil Iqbal
General Physician">Dr. Adil Iqbal
General Physician</option>
	  <option value="Nadia Raj
General Physician">Nadia Raj
General Physician</option>
	  <option value="Dr. Syeda Mahida Ali
General Physician
MBBS">Dr. Syeda Mahida Ali
General Physician
MBBS</option>
	  <option value="Dr. Rashid Iqbal
General Physician">Dr. Rashid Iqbal
General Physician</option>
	   <option value="Dr. Rehana Kanwal Mohal
General Physician">Dr. Rehana Kanwal Mohal
General Physician</option>
	  <option value="Dr. Madiha Kamal
General Physician
MBBS">Dr. Madiha Kamal
General Physician
MBBS</option>
	  <option value="Dr WAQAS AHMAD
General Physician
M.B.B.S.">Dr WAQAS AHMAD
General Physician
M.B.B.S.</option>
	  <option value="DR. RAI M. AMMAR MADNI
General Physician
MBBS">DR. RAI M. AMMAR MADNI
General Physician
MBBS</option>
	  <option value="Dr Rabia Atta Mohyuddin
General Physician
M.B.B.S.">Dr Rabia Atta Mohyuddin
General Physician
M.B.B.S.</option>
	  <option value="GENETICIST IN HOSPITALS "><b>GENETICIST IN HOSPITALS </b></option>
	  <option value="Munir Ahmad Bhinder
Geneticist
MPHILL, PHD (Molec..">Munir Ahmad Bhinder
Geneticist
MPHILL, PHD (Molec..</option>
	  <option value="HAIR TRANSPLANT"><b>HAIR TRANSPLANT</b></option>
	  <option value="Dr. Azim Jahangir Khan
Hair Transplant">Dr. Azim Jahangir Khan
Hair Transplant</option>
	  <option value="HEMATOLOGIST IN HOSPITALS "><b>HEMATOLOGIST IN HOSPITALS </b></option>
	   <option value="Ali Raza
Hematologist
MBBS. MPhil">Ali Raza
Hematologist
MBBS. MPhil</option>
	  <option value="Dr. Nadia Sajid
Hematologist
MBBS,FCPS">Dr. Nadia Sajid
Hematologist
MBBS,FCPS</option>
	  <option value="Dr. Abdul Hameed
Hematologist
MBBS, MRCP (UK), M..">Dr. Abdul Hameed
Hematologist
MBBS, MRCP (UK), M..</option>
	  <option value="Dr Mona Aziz
Hematologist
MBBS.FCPS">Dr Mona Aziz
Hematologist
MBBS.FCPS</option>
	  <option value="Dr. Abdul Hayae
Hematologist">Dr. Abdul Hayae
Hematologist</option>
	   <option value="HERBALIST IN HOSPITALS"><b>HERBALIST IN HOSPITALS</b></option>
	  <option value="Dr Muhammad Rizwan Arshad
Herbalist
Consultant Herbal">Dr Muhammad Rizwan Arshad
Herbalist
Consultant Herbal</option>
	  <option value="INFECTIOUS DISEASE SPECIALIST IN HOSPITALS"><b>INFECTIOUS DISEASE SPECIALIST IN HOSPITALS</b></option>
	  <option value="Dr. Naveed Rashid
Infectious Disease Specialist
MBBS, FCPS (Intern..">Dr. Naveed Rashid
Infectious Disease Specialist
MBBS, FCPS (Intern..</option>
	  <option value="DR MUHAMMAD TAUSEEF JAVED
Infectious Disease Specialist
MBBS. DPH. PHil. F..
">DR MUHAMMAD TAUSEEF JAVED
Infectious Disease Specialist
MBBS. DPH. PHil. F..
</option>
	   <option value="INTERNAL MEDICINE IN HOSPITALS"><b>INTERNAL MEDICINE IN HOSPITALS</b></option>
	  <option value="Dr. Nisar Haider Anjum
Internal Medicine
MBBS, FCPS">Dr. Nisar Haider Anjum
Internal Medicine
MBBS, FCPS</option>
	  <option value="Dr. Zeeshan Akhtar Wali
Internal Medicine
MBBS,FCPS (medicine)">Dr. Zeeshan Akhtar Wali
Internal Medicine
MBBS,FCPS (medicine)</option>
	  <option value="Dr. Sajid Mahmood Rana
Internal Medicine
MBBS, FCPS">Dr. Sajid Mahmood Rana
Internal Medicine
MBBS, FCPS</option>
	  <option value="Dr Faisal Amin Baig
Internal Medicine
MBBS, FCPS">Dr Faisal Amin Baig
Internal Medicine
MBBS, FCPS</option>
	   <option value="Uzair Akbar Ali
Internal Medicine
MBBS, MRCP (Ireland)">Uzair Akbar Ali
Internal Medicine
MBBS, MRCP (Ireland)</option>
	  <option value="Sami Ullah Mumtaz
Internal Medicine
MBBS, FCPS (Medici..">Sami Ullah Mumtaz
Internal Medicine
MBBS, FCPS (Medici..</option>
	  <option value="Tahir Islam
Internal Medicine
MBBS, MCPS, DTCD (..">Tahir Islam
Internal Medicine
MBBS, MCPS, DTCD (..</option>
	  <option value="Dr. Altaf A Cheema
Internal Medicine">Dr. Altaf A Cheema
Internal Medicine</option>
	  <option value="Dr. Mazhar Ul Islam
Internal Medicine">Dr. Mazhar Ul Islam
Internal Medicine</option>
	   <option value="Dr. Ahmed Nadeem
Internal Medicine">Dr. Ahmed Nadeem
Internal Medicine</option>
	  <option value="Dr Bilal Azeem Butt
Internal Medicine
FCPS">Dr Bilal Azeem Butt
Internal Medicine
FCPS</option>
	  <option value="Dr MUBASHAR SULTAN HASHMI
Internal Medicine
Fcps medicine">Dr MUBASHAR SULTAN HASHMI
Internal Medicine
Fcps medicine</option>
	  <option value="Dr Asad Ullah Ijaz
Internal Medicine
MBBS, FCPS">Dr Asad Ullah Ijaz
Internal Medicine
MBBS, FCPS</option>
	  <option value="Dr Atiq Rehman
Internal Medicine
MRCP UK">Dr Atiq Rehman
Internal Medicine
MRCP UK</option>
	   <option value="Zahabia Manzoor
Internal Medicine
mbbs, fcps">Zahabia Manzoor
Internal Medicine
mbbs, fcps</option>
	  <option value="Dr. Amir Aziz
Internal Medicine
MBBS, FRCS, FCPS -..">Dr. Amir Aziz
Internal Medicine
MBBS, FRCS, FCPS -..</option>
	  <option value="NEONATOLOGIST IN HOSPITALS"><b>NEONATOLOGIST IN HOSPITALS</b></option>
	  <option value="Dr Muhammad Anwar
Neonatologist
MBBS, DCH, FCPS (P..">Dr Muhammad Anwar
Neonatologist
MBBS, DCH, FCPS (P..</option>
	  <option value="Abdul Rehman
Neonatologist">Abdul Rehman
Neonatologist</option>
	   <option value="Prof Dr Zareen Fasih
Neonatologist
F.C.P.S. M.B.B.S. ..">Prof Dr Zareen Fasih
Neonatologist
F.C.P.S. M.B.B.S. ..</option>
	  <option value="Dr. Farooq Khan
Neonatologist
(Physician) MBBS, ..">Dr. Farooq Khan
Neonatologist
(Physician) MBBS, ..</option>
	  <option value="Dr Ahmed Wali
Neonatologist
FCPS (Neurology), ..">Dr Ahmed Wali
Neonatologist
FCPS (Neurology), ..</option>
	  <option value="NEURO PHYSICIAN IN HOSPITALS"><b>NEURO PHYSICIAN IN HOSPITALS</b></option>
	  <option value="Dr Rashid Imran
Neuro Physician
MBBS, FCPS (Neurol..">Dr Rashid Imran
Neuro Physician
MBBS, FCPS (Neurol..</option>
	   <option value="Dr Rashid Imran
Neuro Physician
MBBS, FCPS (Neurol..">Dr Muhammad Akbar Malik
Neuro Physician
MBBS, DCH, MCPS, F..</option>
	  <option value="Dr. Faheem Saeed
Neuro Physician
M.B.B.S.(K.E.), F...">Dr. Faheem Saeed
Neuro Physician
M.B.B.S.(K.E.), F...</option>
	  <option value="Dr MUHAMMAD ATHAR JAVED
Neuro Physician
M.B.B.S.">Dr MUHAMMAD ATHAR JAVED
Neuro Physician
M.B.B.S.</option>
	  <option value="Dr. Shahid Mukhtar
Neuro Physician
MBBS (KE) FCPS neu..">Dr. Shahid Mukhtar
Neuro Physician
MBBS (KE) FCPS neu..</option>
	  <option value="Dr. Abubakar Siddique
Neuro Physician
MBBS. FCPS (Neurol..">Dr. Abubakar Siddique
Neuro Physician
MBBS. FCPS (Neurol..</option>
	   <option value="NEUROSURGEON IN HOSPITALS"><b>NEUROSURGEON IN HOSPITALS</b></option>
	  <option value="Usman Ahmad Kamboh
Neurosurgeon
MBBS, FCPS (Neuro ..">Usman Ahmad Kamboh
Neurosurgeon
MBBS, FCPS (Neuro ..</option>
	  <option value="MUHAMMAD ADIL AMIN
Neurosurgeon
FCPS">MUHAMMAD ADIL AMIN
Neurosurgeon
FCPS</option>
	  <option value="Prof Khalid Mehmood
Neurosurgeon
FRCS (Glasg) FRCS ..">Prof Khalid Mehmood
Neurosurgeon
FRCS (Glasg) FRCS ..</option>
	  <option value="Professor Dr. Khalid Ma..
Neurosurgeon
FRCS, FRCS(SN)Glasg">Professor Dr. Khalid Ma..
Neurosurgeon
FRCS, FRCS(SN)Glasg</option>
	   <option value="Dr Waqas Mehdi
Neurosurgeon
M.B.B.S, B.Sc, FCP..">Dr Waqas Mehdi
Neurosurgeon
M.B.B.S, B.Sc, FCP..</option>
	  <option value="Dr. Yaser Uddin
Neurosurgeon
MBBS(PAK), M.D(USA..">Dr. Yaser Uddin
Neurosurgeon
MBBS(PAK), M.D(USA..</option>
	  <option value="Dr Zahid Ullah Safi
Neurosurgeon
MD MS">Dr Zahid Ullah Safi
Neurosurgeon
MD MS</option>
	  <option value="Dr. Asif Bashir
Neurosurgeon
MD, FACS, FAANS, A..">Dr. Asif Bashir
Neurosurgeon
MD, FACS, FAANS, A..</option>
	  <option value="Prof Dr Sabir H Bhatti ..
Neurosurgeon
MBBS, FCPS(Neurosu.">Prof Dr Sabir H Bhatti ..
Neurosurgeon
MBBS, FCPS(Neurosu.</option>
	   <option value="Dr. Nazir Ahmed
Neurosurgeon
MBBS, MS. - Neuros..">Dr. Nazir Ahmed
Neurosurgeon
MBBS, MS. - Neuros..</option>
	  <option value="Prof. Shahzad Shams
Neurosurgeon
BSc, MBBS, FRCS, F..">Prof. Shahzad Shams
Neurosurgeon
BSc, MBBS, FRCS, F..</option>
	  <option value="Dr. Atiq - Ur - Rehman ..
Neurosurgeon
MBBS, MD, DAB. - N..">Dr. Atiq - Ur - Rehman ..
Neurosurgeon
MBBS, MD, DAB. - N..</option>
	  <option value="Dr. Shahzad Shams
Neurosurgeon
BSc, MBBS, FRCS, F..">Dr. Shahzad Shams
Neurosurgeon
BSc, MBBS, FRCS, F..</option>
	  <option value="Dr. Naeem Ul Hameed
Neurosurgeon
MBBS, FRCP. - Neur..">Dr. Naeem Ul Hameed
Neurosurgeon
MBBS, FRCP. - Neur..</option>
	   <option value="Dr. Naveed Ashraf
Neurosurgeon
MBBS, MS. - Neuros..">Dr. Naveed Ashraf
Neurosurgeon
MBBS, MS. - Neuros..</option>
	  <option value="Dr. Muhammad Zafar Iqbal
Neurosurgeon
MBBS, FCPS., FRCS ..">Dr. Muhammad Zafar Iqbal
Neurosurgeon
MBBS, FCPS., FRCS ..</option>
	  <option value="Dr. Saeed A. Bajwa
Neurosurgeon
MD, FACS, DAB. - N..">Dr. Saeed A. Bajwa
Neurosurgeon
MD, FACS, DAB. - N..</option>
	  <option value="Dr. Rizwan Masood Butt
Neurosurgeon
MBBS, MD, FRCS, FC..">Dr. Rizwan Masood Butt
Neurosurgeon
MBBS, MD, FRCS, FC..</option>
	  <option value="Dr. Salman Asghar
Neurosurgeon
MBBS, FRCS - Neuro..">Dr. Salman Asghar
Neurosurgeon
MBBS, FRCS - Neuro..</option>
	   <option value="Dr. Rizwan Masood Butt
Neurosurgeon
MBBS, MD, FRCS - N..">Dr. Rizwan Masood Butt
Neurosurgeon
MBBS, MD, FRCS - N..</option>
	  <option value="Dr. M. Shahid Sial
Neurosurgeon
MBBS, MCPS. - Neur..">Dr. M. Shahid Sial
Neurosurgeon
MBBS, MCPS. - Neur..</option>
	  <option value="Prof Dr Rizwan M Butt
Neurosurgeon
MBBS, MD, FCPS, FR..">Prof Dr Rizwan M Butt
Neurosurgeon
MBBS, MD, FCPS, FR..</option>
	  <option value="Dr. Nazir Ahmad
Neurosurgeon">Dr. Nazir Ahmad
Neurosurgeon</option>
	  <option value="Dr. Abdullah Haroon
Neurosurgeon
MBBS, FCPS. - Neur..">Dr. Abdullah Haroon
Neurosurgeon
MBBS, FCPS. - Neur..</option>
	  
	  <option value="Dr. Khalid Mehmood Butt
Neurosurgeon
MBBS, FRCS, - Neur..">Dr. Khalid Mehmood Butt
Neurosurgeon
MBBS, FRCS, - Neur..</option>
	  <option value="Dr. Kamran Hussain
Neurosurgeon
MBBS, FRCS - Neuro..">Dr. Kamran Hussain
Neurosurgeon
MBBS, FRCS - Neuro..</option>
	  <option value="Dr. Amer Ikram
Neurosurgeon
MBBS, DAB. - Neuro..">Dr. Amer Ikram
Neurosurgeon
MBBS, DAB. - Neuro..</option>
	  <option value="Dr. Khalid Hussain Abbas
Neurosurgeon
MBBS, FRCS - Neuro..">Dr. Khalid Hussain Abbas
Neurosurgeon
MBBS, FRCS - Neuro..</option>
	  <option value="Dr. Shahzad Shams
Neurosurgeon
MBBS - Neurosurgeon">Dr. Shahzad Shams
Neurosurgeon
MBBS - Neurosurgeon</option>
	  <option value="Dr. Javed Majeed Mian
Neurosurgeon
MBBS, MCPS, MS. - ..">Dr. Javed Majeed Mian
Neurosurgeon
MBBS, MCPS, MS. - ..</option>
	   <option value="Dr. Shahzad Yousaf
Neurosurgeon">Dr. Shahzad Yousaf
Neurosurgeon</option>
	  <option value="Dr. Imran Masood
Neurosurgeon">Dr. Imran Masood
Neurosurgeon</option>
	  <option value="Dr. Iftikhar Ali Raja
Neurosurgeon
(FRCS) (late)">Dr. Iftikhar Ali Raja
Neurosurgeon
(FRCS) (late)</option>
	  <option value="Dr. Malik Muhammad Nade..
Neurosurgeon
Consultant Pediatr..">Dr. Malik Muhammad Nade..
Neurosurgeon
Consultant Pediatr..</option>
	  <option value="Dr. Khalid H. Abbas
Neurosurgeon
MBBS, FRCS - Neuro..">Dr. Khalid H. Abbas
Neurosurgeon
MBBS, FRCS - Neuro..</option>
	   <option value="Dr Amjad Ali
Neurosurgeon
M.B.B.S,FCPS">Dr Amjad Ali
Neurosurgeon
M.B.B.S,FCPS</option>
	  <option value="ONCOLOGIST IN HOSPITALS "><b>ONCOLOGIST IN HOSPITALS </b></option>
	  <option value="Najam Ul Hasan
Oncologist
MD, DICOR">Najam Ul Hasan
Oncologist
MD, DICOR</option>
	  <option value="Syed Nasir Abbas Bukhari
Oncologist
MBBS(Pb).FCPS.DH(U..">Syed Nasir Abbas Bukhari
Oncologist
MBBS(Pb).FCPS.DH(U..</option>
	  <option value="Amjad Shahbaz khan Durr..
Oncologist
MBBS,DMRT,AFSA">Amjad Shahbaz khan Durr..
Oncologist
MBBS,DMRT,AFSA</option>
	   <option value="Dr Muhammad Arif Ch.
Oncologist
Diplomate American..">Dr Muhammad Arif Ch.
Oncologist
Diplomate American..</option>
	  <option value="Dr. Rehan Abdullah
Oncologist
M.B.B.S. M.S. F.C...">Dr. Rehan Abdullah
Oncologist
M.B.B.S. M.S. F.C...</option>
	  <option value="Prof. Ghulam Sarwar
Oncologist">Prof. Ghulam Sarwar
Oncologists</option>
	  <option value="Dr. Adeeba Quddus
Oncologist
MBBS, DAB - Oncolo..">Dr. Adeeba Quddus
Oncologist
MBBS, DAB - Oncolo..</option>
	  <option value="Dr. Akram Muslim
Oncologist
MBBS, DAB.I.M. - O..">Dr. Akram Muslim
Oncologist
MBBS, DAB.I.M. - O..</option>
	   <option value="Dr. Alia Zaidi
Oncologist
MBBS, MRCP - Oncol..">Dr. Alia Zaidi
Oncologist
MBBS, MRCP - Oncol..</option>
	  <option value="Dr. Mazhar Ali Shah
Oncologist
MBBS, DMRT - Oncol..">Dr. Mazhar Ali Shah
Oncologist
MBBS, DMRT - Oncol..</option>
	  <option value="Dr. Shahid Hameed
Oncologist
MBBS, DAB - Oncolo..">Dr. Shahid Hameed
Oncologist
MBBS, DAB - Oncolo..</option>
	  <option value="Dr. Shakeeb Yunus
Oncologist
MBBS, DABIM - Onco..">Dr. Shakeeb Yunus
Oncologist
MBBS, DABIM - Onco..</option>
	  <option value="Dr. Rab Nawaz Maken
Oncologist
MBBS, MSc, FCPS - .">Dr. Rab Nawaz Maken
Oncologist
MBBS, MSc, FCPS - .</option>
	   <option value="Dr. Sheharyar
Oncologist
MBBS, MCPS, DMRT, ..">Dr. Sheharyar
Oncologist
MBBS, MCPS, DMRT, ..</option>
	  <option value="Dr. Zeba Aziz
Oncologist
MBBS, MCPS, DMRT, ..">Dr. Zeba Aziz
Oncologist
MBBS, MCPS, DMRT, ..</option>
	  <option value="Dr. Imtiaz Randhawa
Oncologist
MBBS, DMRT, GTC - ..">Dr. Imtiaz Randhawa
Oncologist
MBBS, DMRT, GTC - ..</option>
	  <option value="Dr. Shahina Parveen
Oncologist
MBBS, MD, DMRT - O..">Dr. Shahina Parveen
Oncologist
MBBS, MD, DMRT - O..</option>
	  <option value="Dr. Ghulam Sarwar
Oncologist
MBBS, DMRT, FICS -..">Dr. Ghulam Sarwar
Oncologist
MBBS, DMRT, FICS -..</option>
	   <option value="Dr. Abdul Sami Qazi
Oncologist
MBBS, DMRT, MCPS, ..">Dr. Abdul Sami Qazi
Oncologist
MBBS, DMRT, MCPS, ..</option>
	  <option value="OPTOMETRIST IN HOSPITALS"><b>OPTOMETRIST IN HOSPITALS</b></option>
	  <option value="Rashid Asghar khan
Optometrist
BS in vision scien..">Rashid Asghar khan
Optometrist
BS in vision scien..</option>
	  <option value="Syed Waqas Naqvi
Optometrist
Doctor of Optometry">Syed Waqas Naqvi
Optometrist
Doctor of Optometry</option>
	  <option value="Dr. Nasir Farid Sandila
Optometrist
Doctor of Optometry">Dr. Nasir Farid Sandila
Optometrist
Doctor of Optometry</option>
	   <option value="Dr Farman Barki
Optometrist
Doctor of optometry">Dr Farman Barki
Optometrist
Doctor of optometry</option>
	  <option value="ORTHOPEDIC SURGEON IN HOSPITALS"><b>ORTHOPEDIC SURGEON IN HOSPITALS</b></option>
	  <option value="Saeed Taj
Orthopedic Surgeon
FCPS">Saeed Taj
Orthopedic Surgeon
FCPS</option>
	  <option value="Dr Mehdi Ali Mehdavi
Orthopedic Surgeon
M.B.B.S. FCPS(orth..">Dr Mehdi Ali Mehdavi
Orthopedic Surgeon
M.B.B.S. FCPS(orth..</option>
	  <option value="Dr. Muhammad Abdul Basit
Orthopedic Surgeon
MBBS. Master of Su..">Dr. Muhammad Abdul Basit
Orthopedic Surgeon
MBBS. Master of Su..</option>
	   <option value="Dr Umair Abu Bakar Siddiq
Orthopedic Surgeon
M.B;B.S (KEMU), FC..">Dr Umair Abu Bakar Siddiq
Orthopedic Surgeon
M.B;B.S (KEMU), FC..</option>
	  <option value="Dr Kamran Butt
Orthopedic Surgeon
MBBS,FRCS,DSM,RCP&..">Dr Kamran Butt
Orthopedic Surgeon
MBBS,FRCS,DSM,RCP&..</option>
	  <option value="Dr. Atiq Durrani
Orthopedic Surgeon
MD, FAAOS, FACS, F..">Dr. Atiq Durrani
Orthopedic Surgeon
MD, FAAOS, FACS, F..</option>
	  <option value="Mr Ahsan Alam
Orthopedic Surgeon
FRCSEd, FRCSI, FRC..">Mr Ahsan Alam
Orthopedic Surgeon
FRCSEd, FRCSI, FRC..</option>
	  <option value="Ahsan Alam
Orthopedic Surgeon
MBBS, FRCSEd, FRCS..">Ahsan Alam
Orthopedic Surgeon
MBBS, FRCSEd, FRCS..</option>
	   <option value="Prof Dr M A Wajid
Orthopedic Surgeon
FRCS, FRCS(Tr & Or..">Prof Dr M A Wajid
Orthopedic Surgeon
FRCS, FRCS(Tr & Or..</option>
	  <option value="Dr. Ghulam Abbas
Orthopedic Surgeon
F.R.C.S (UK). M.I...">Dr. Ghulam Abbas
Orthopedic Surgeon
F.R.C.S (UK). M.I...</option>
	  <option value="Dr. Imran Nausher
Orthopedic Surgeon
MBBS, FCPS">Dr. Imran Nausher
Orthopedic Surgeon
MBBS, FCPS</option>
	  <option value="Dr Muhammad Bilal
Orthopedic Surgeon
MBBS, FCPS, FRCS (..">Dr Muhammad Bilal
Orthopedic Surgeon
MBBS, FCPS, FRCS (..</option>
	  <option value="Mohammad Bilal Raza
Orthopedic Surgeon
MBBS, FCPS, A.O. T..">Mohammad Bilal Raza
Orthopedic Surgeon
MBBS, FCPS, A.O. T..</option>
	   <option value="Usman Ahmed
Orthopedic Surgeon
MBBS, MS(ortho)">Usman Ahmed
Orthopedic Surgeon
MBBS, MS(ortho)</option>
	  <option value="Muhammad Noman raza
Orthopedic Surgeon
MBBS, FCPS (Tr & O..">Muhammad Noman raza
Orthopedic Surgeon
MBBS, FCPS (Tr & O..</option>
	  <option value="Syed Wasif Ali Shah
Orthopedic Surgeon
MBBS, FCPS (Orthop..">Syed Wasif Ali Shah
Orthopedic Surgeon
MBBS, FCPS (Orthop..</option>
	  <option value="Prof M A Wajid
Orthopedic Surgeon
FRCS(Tr & Orth) UK..">Prof M A Wajid
Orthopedic Surgeon
FRCS(Tr & Orth) UK..</option>
	  <option value="Tariq Sohail
Orthopedic Surgeon
MBBS, M.ch.(Ortho)..">Tariq Sohail
Orthopedic Surgeon
MBBS, M.ch.(Ortho)..</option>
	   <option value="Dr Rashid Saeed
Orthopedic Surgeon
MBBS, FCPS, FRCS">Dr Rashid Saeed
Orthopedic Surgeon
MBBS, FCPS, FRCS</option>
	  <option value="Dr. Dilavaiz Nadeem
Orthopedic Surgeon">Dr. Dilavaiz Nadeem
Orthopedic Surgeon</option>
	  <option value="Professor Aasim Malik
Orthopedic Surgeon">Professor Aasim Malik
Orthopedic Surgeon</option>
	  <option value="Dr. (Maj Gen) S M H And..
Orthopedic Surgeon">Dr. (Maj Gen) S M H And..
Orthopedic Surgeon</option>
	  <option value="Dr. Abdullah Farooq Khan
Orthopedic Surgeon">Dr. Abdullah Farooq Khan
Orthopedic Surgeon</option>
	   <option value="Prof. Dr.Naseer Mehmood..
Orthopedic Surgeon">Prof. Dr.Naseer Mehmood..
Orthopedic Surgeon</option>
	  <option value="Dr Shafqat Waseem Chaud..
Orthopedic Surgeon
MBBS Fcps MD usa">Dr Shafqat Waseem Chaud..
Orthopedic Surgeon
MBBS Fcps MD usa</option>
	  <option value="Dr. Shoaib Anwar
Orthopedic Surgeon
MBBS, FCPS">Dr. Shoaib Anwar
Orthopedic Surgeon
MBBS, FCPS</option>
	  <option value="Dr. Talha Khan Niazi
Orthopedic Surgeon
MBBS, FCPS">Dr. Talha Khan Niazi
Orthopedic Surgeon
MBBS, FCPS</option>
	  <option value="Dr. Afzal Hussain
Orthopedic Surgeon
MBBS, FCPS">Dr. Afzal Hussain
Orthopedic Surgeon
MBBS, FCPS</option>
	   <option value="Dr. Abdullah Farooq
Orthopedic Surgeon
MBBS, MS, MRCS">Dr. Abdullah Farooq
Orthopedic Surgeon
MBBS, MS, MRCS</option>
	  <option value="Faisal Qamar
Orthopedic Surgeon
MBBS, MRCS UK, FRC..">Faisal Qamar
Orthopedic Surgeon
MBBS, MRCS UK, FRC..</option>
	  <option value="Dr. Ali Raza Hashmi
Orthopedic Surgeon
MBBS - Orthpedic S..">Dr. Ali Raza Hashmi
Orthopedic Surgeon
MBBS - Orthpedic S..</option>
	  <option value="Dr. Rana Dilawaz Khan
Orthopedic Surgeon
MBBS - Orthpedic S..">Dr. Rana Dilawaz Khan
Orthopedic Surgeon
MBBS - Orthpedic S..</option>
	  <option value="Dr. Dr. Faisal Mushtaq
Orthopedic Surgeon
FCPS (Orth) - Orth..">Dr. Dr. Faisal Mushtaq
Orthopedic Surgeon
FCPS (Orth) - Orth..</option>
	  <option value="Dr. Atiq Uz Zaman
Orthopedic Surgeon
MBBS & FCPS (orth)..">Dr. Atiq Uz Zaman
Orthopedic Surgeon
MBBS & FCPS (orth)..</option>
	  <option value="Prof. Amer Aziz
Orthopedic Surgeon
MBBS - FRCS - Dipl..">Prof. Amer Aziz
Orthopedic Surgeon
MBBS - FRCS - Dipl..</option>
	  <option value="Dr. Subhan Shahid
Orthopedic Surgeon
MBBS, FCPS, MCPS -..">Dr. Subhan Shahid
Orthopedic Surgeon
MBBS, FCPS, MCPS -..</option>
<option value="OTHER IN HOSPITALS"><b>OTHER IN HOSPITALS</b></option>
	  <option value="Dr Fouzia Zaigham
Other
MBBS">Dr Fouzia Zaigham
Other
MBBS</option>
	   <option value="Dr. Imran Ahmed
Other
MBBS, MCPS, M.D">Dr. Imran Ahmed
Other
MBBS, MCPS, M.D</option>
	  <option value="Awais Amjad Malik
Other
FCPS, Fellowship S..">Awais Amjad Malik
Other
FCPS, Fellowship S..</option>
	  <option value="Atif Aslam
Other">Atif Aslam
Other</option>
	  <option value="PAEDIATRIC SURGEON IN HOSPITALS"><b>PAEDIATRIC SURGEON IN HOSPITALS</b></option>
	   <option value="Dr. Rashid Zia
Paediatric Surgeon
MBBS, MRCP, FRCP, ..">Dr. Rashid Zia
Paediatric Surgeon
MBBS, MRCP, FRCP, ..</option>
	  <option value="Dr. Abid Quddus Qazi
Paediatric Surgeon
FRCS, FCPS (Paedia..">Dr. Abid Quddus Qazi
Paediatric Surgeon
FRCS, FCPS (Paedia..</option>
	  <option value="Muhammad Ali Sheikh
Paediatric Surgeon
MBBS, FCPS (Paedia..">Muhammad Ali Sheikh
Paediatric Surgeon
MBBS, FCPS (Paedia..</option>
	  <option value="Dr. Javed Iqbal
Paediatric Surgeon
MBBS, FRCS (Irelan..">Dr. Javed Iqbal
Paediatric Surgeon
MBBS, FRCS (Irelan..</option>
	  <option value="Syed Faisal Usman
Paediatric Surgeon
MBBS,FCPS">Syed Faisal Usman
Paediatric Surgeon
MBBS,FCPS</option>
	   <option value="Muhammad Javaid Iqbal K..
Paediatric Surgeon
M.B.B.S ; FCPS">Muhammad Javaid Iqbal K..
Paediatric Surgeon
M.B.B.S ; FCPS</option>
	  <option value="Malik Waqas
Paediatric Surgeon
MBBS, FCPS">Malik Waqas
Paediatric Surgeon
MBBS, FCPS</option>
	  <option value="Mohammad Iqbal
Paediatric Surgeon
MBBS, DCH - Paedia..">Mohammad Iqbal
Paediatric Surgeon
MBBS, DCH - Paedia..</option>
	  <option value="Dr. Mohammad Ali Khan
Paediatric Surgeon
MBBS, DCP, MRCP - ..">Dr. Mohammad Ali Khan
Paediatric Surgeon
MBBS, DCP, MRCP - ..</option>
	  <option value="Dr. Aja.Samdani
Paediatric Surgeon
MBBS, MD, DCH - Pa..">Dr. Aja.Samdani
Paediatric Surgeon
MBBS, MD, DCH - Pa..</option>
	   <option value="Dr. Iqbal Ahmed Azhar
Paediatric Surgeon
MBBS, FCPS - Paedi..">Dr. Iqbal Ahmed Azhar
Paediatric Surgeon
MBBS, FCPS - Paedi..</option>
	  <option value="Dr. Tahira S. Izhar
Paediatric Surgeon
MBBS, DCH, MCPS - ..">Dr. Tahira S. Izhar
Paediatric Surgeon
MBBS, DCH, MCPS - ..</option>
	  <option value="Dr. Maj Ghulam Abbas Ch
Paediatric Surgeon
MBBS(Pb).DCH.(Pb) ..">Dr. Maj Ghulam Abbas Ch
Paediatric Surgeon
MBBS(Pb).DCH.(Pb) ..</option>
	  <option value="Dr. Zia - Ul -Miraj
Paediatric Surgeon
MBBS, DCH, FRCS - ..">Dr. Zia - Ul -Miraj
Paediatric Surgeon
MBBS, DCH, FRCS - ..</option>
	  <option value="Dr. Tariq Latif
Paediatric Surgeon
MBBS, FRCS - Paedi..">Dr. Tariq Latif
Paediatric Surgeon
MBBS, FRCS - Paedi..</option>
	   <option value="Dr. Abdul Hameed
Paediatric Surgeon
MBBS, FRCS, FCPS, ..">Dr. Abdul Hameed
Paediatric Surgeon
MBBS, FRCS, FCPS, ..</option>
	  <option value="Dr. Mohammad Aslam Malik
Paediatric Surgeon
MBBS, DCH, MRCP - ..">Dr. Mohammad Aslam Malik
Paediatric Surgeon
MBBS, DCH, MRCP - ..</option>
	  <option value="Dr. Mohammad Imran Mir
Paediatric Surgeon
MBBS, DCH, DCH - P..">Dr. Mohammad Imran Mir
Paediatric Surgeon
MBBS, DCH, DCH - P..</option>
	  <option value="Dr. Haroon
Paediatric Surgeon
MBBS, FCPS - Paedi..">Dr. Haroon
Paediatric Surgeon
MBBS, FCPS - Paedi..</option>
	  <option value="Dr. Imran Yousaf
Paediatric Surgeon
MBBS, FRCS - Paedi..">Dr. Imran Yousaf
Paediatric Surgeon
MBBS, FRCS - Paedi..</option>
	   <option value="Dr. Fauzia Shaukat
Paediatric Surgeon
MBBS, MCPS, FCPS, ..">Dr. Fauzia Shaukat
Paediatric Surgeon
MBBS, MCPS, FCPS, ..</option>
	  <option value="Dr. Ali Atif Goheir
Paediatric Surgeon
MBBS, FRCS - Paedi..">Dr. Ali Atif Goheir
Paediatric Surgeon
MBBS, FRCS - Paedi..</option>
	  <option value="Dr. Muhammad Aslam Malik
Paediatric Surgeon
MBBS, DCH, MRCP - ..">Dr. Muhammad Aslam Malik
Paediatric Surgeon
MBBS, DCH, MRCP - ..</option>
	  <option value="Dr. Muhammad Tariq Bhatti
Paediatric Surgeon
MBBS, MCPS, FCPS -..">Dr. Muhammad Tariq Bhatti
Paediatric Surgeon
MBBS, MCPS, FCPS -..</option>
	  <option value="Dr. Muzammal Hussain Za..
Paediatric Surgeon
MBBS, FICP - Paedi..">Dr. Muzammal Hussain Za..
Paediatric Surgeon
MBBS, FICP - Paedi..</option>
	   <option value="Dr. Misbah Mubashar
Paediatric Surgeon
MBBS, DCH - Paedia..">Dr. Misbah Mubashar
Paediatric Surgeon
MBBS, DCH - Paedia..</option>
	  <option value="Dr. M. Islam Shahid
Paediatric Surgeon
MBBS, FCPS - Paedi..">Dr. M. Islam Shahid
Paediatric Surgeon
MBBS, FCPS - Paedi..</option>
	  <option value="Dr. Parveen Zulfiqar
Paediatric Surgeon
MBBS, DCH - Paedia..">Dr. Parveen Zulfiqar
Paediatric Surgeon
MBBS, DCH - Paedia..</option>
	  <option value="Dr. Ghulam Sarwar
Paediatric Surgeon
MBBS, DCH - Paedia..">Dr. Ghulam Sarwar
Paediatric Surgeon
MBBS, DCH - Paedia..</option>
	  <option value="Dr. Zaheer Ul Haq Qureshi
Paediatric Surgeon
MBBS, DCH, MCPS - ..">Dr. Zaheer Ul Haq Qureshi
Paediatric Surgeon
MBBS, DCH, MCPS - ..</option>
	   <option value="Dr. Ijaz Hussain Gilani
Paediatric Surgeon
MBBS, DCH -I - Pae..">Dr. Ijaz Hussain Gilani
Paediatric Surgeon
MBBS, DCH -I - Pae..</option>
	  <option value="Dr. Khaliq Ahmed Qureshi
Paediatric Surgeon
MBBS, DCH - Paedia..">Dr. Khaliq Ahmed Qureshi
Paediatric Surgeon
MBBS, DCH - Paedia..</option>
	  <option value="Dr. Riffat - Ur - Rehman
Paediatric Surgeon
MBBS, FCPS - Paedi..">Dr. Riffat - Ur - Rehman
Paediatric Surgeon
MBBS, FCPS - Paedi..</option>
	  <option value="Dr. Rao Muhammad Riaz U..
Paediatric Surgeon
MBBS, FCPS - Paedi..">Dr. Rao Muhammad Riaz U..
Paediatric Surgeon
MBBS, FCPS - Paedi..</option>
	  <option value="Dr. Mohammad Saeed Chau..
Paediatric Surgeon
MBBS, MCPS, MRCP -..">Dr. Mohammad Saeed Chau..
Paediatric Surgeon
MBBS, MCPS, MRCP -..</option>
	   <option value="Dr. Mohammad Shaukat
Paediatric Surgeon
MBBS, FRCS - Paedi..">Dr. Mohammad Shaukat
Paediatric Surgeon
MBBS, FRCS - Paedi..</option>
	  <option value="MAXILLOFACIAL SURGEON IN HOSPITALS"><b>MAXILLOFACIAL SURGEON IN HOSPITALS</b></option>
	  <option value="Dr Asad Aizaz Chatha
Maxillofacial Surgeon
BDS, FCPS, MDS, FF..">Dr Asad Aizaz Chatha
Maxillofacial Surgeon
BDS, FCPS, MDS, FF..</option>
	  <option value="Dr Gulraiz Zulfiqar
Maxillofacial Surgeon
BS,BDS,FCPS,FOCMF(..">Dr Gulraiz Zulfiqar
Maxillofacial Surgeon
BS,BDS,FCPS,FOCMF(..</option>
	  <option value="Dr. Ali Hassan Sajid
Maxillofacial Surgeon
B.D.S., F.C.P.S
">Dr. Ali Hassan Sajid
Maxillofacial Surgeon
B.D.S., F.C.P.S
</option>
	   <option value="LIVER SPECIALIST IN HOSPITALS"><b>LIVER SPECIALIST IN HOSPITALS</b></option>
	  <option value="Hussam Ahmed
Liver Specialist
MBBS, MS (General ..">Hussam Ahmed
Liver Specialist
MBBS, MS (General ..</option>
	  <option value="Muhammad Zakria
Liver Specialist
MBBS, MRCS (UK), F..">Muhammad Zakria
Liver Specialist
MBBS, MRCS (UK), F..</option>
	  <option value="DR. ISRAR UL HAQ
Liver Specialist
MBBS, FCPS">DR. ISRAR UL HAQ
Liver Specialist
MBBS, FCPS</option>
	  <option value="Dr. Muhammad Zahid Akba..
Liver Specialist
MBBS, FRCS (UK)
">Dr. Muhammad Zahid Akba..
Liver Specialist
MBBS, FRCS (UK)
</option>
	   <option value="WEIGHT LOSS SPECIALIST IN HOSPITALS "><b>WEIGHT LOSS SPECIALIST IN HOSPITALS </b></option>
	  <option value="Dr Zafar Iqbal
Weight Loss Specialist
MD Alternative Med..">Dr Zafar Iqbal
Weight Loss Specialist
MD Alternative Med..</option>
	  <option value="Dr. Zeeshan Tanweer
Weight Loss Specialist">Dr. Zeeshan Tanweer
Weight Loss Specialist</option>
	  <option value="UROLOGIST IN HOSPITALS"><b>UROLOGIST IN HOSPITALS</b></option>
	  <option value="Dr. Fateh Khan Akhtar
Urologist
MBBS - Urologist">Dr. Fateh Khan Akhtar
Urologist
MBBS - Urologist</option>
	   <option value="Dr. Fawad Nasrullah
Urologist
MBBS, FCPS (Urolog..">Dr. Fawad Nasrullah
Urologist
MBBS, FCPS (Urolog..</option>
	  <option value="Athar Mehmood
Urologist
MBBS, FCPS">Athar Mehmood
Urologist
MBBS, FCPS</option>
	  <option value="Irfan Ahmed
Urologist
MBBS, FRCS, D.Urol">Irfan Ahmed
Urologist
MBBS, FRCS, D.Urol</option>
	  <option value="Prof Zafar ul Ahsan
Urologist
MBBS, FRCS Surgery..">Prof Zafar ul Ahsan
Urologist
MBBS, FRCS Surgery..</option>
	  <option value="Khizer Hayat Gondal
Urologist
MBBS, FCPS, Traini..">Khizer Hayat Gondal
Urologist
MBBS, FCPS, Traini..</option>
	   <option value="Hassan Raza Asghar
Urologist
MBBS, FCPS (Urology)">Hassan Raza Asghar
Urologist
MBBS, FCPS (Urology)</option>
	  <option value="Zahid Hussain
Urologist
MBBS, FCPS, F.A.C.S">Zahid Hussain
Urologist
MBBS, FCPS, F.A.C.S</option>
	  <option value="Muhammad Asif Baloch
Urologist
MBBS, FCPS (Urology)">Muhammad Asif Baloch
Urologist
MBBS, FCPS (Urology)</option>
	  <option value="Dr. Asgharali Dogar
Urologist
MBBS - Urologist">Dr. Asgharali Dogar
Urologist
MBBS - Urologist</option>
	  <option value="Dr. Mumtaz Ahmad
Urologist
MBBS - Urologist">Dr. Mumtaz Ahmad
Urologist
MBBS - Urologist</option>
	   <option value="Dr. Mohammad Nawaz Chug..
Urologist
MBBS - Urologist">Dr. Mohammad Nawaz Chug..
Urologist
MBBS - Urologist</option>
	  <option value="Dr. Kamran K. Cheema
Urologist
MBBS' FCPS">Dr. Kamran K. Cheema
Urologist
MBBS' FCPS</option>
	  <option value="Dr. Ahmad Salamanwaris
Urologist
MBBS - Urologist">Dr. Ahmad Salamanwaris
Urologist
MBBS - Urologist</option>
	  <option value="Prof. Khalid Javed Rabb..
Urologist
MBBS - Urologist">Prof. Khalid Javed Rabb..
Urologist
MBBS - Urologist</option>
	  <option value="Dr. Khalid Rabbani
Urologist
MBBS - Urologist">Dr. Khalid Rabbani
Urologist
MBBS - Urologist</option>
	  <option value="Dr. Munir Amin Mughal
Urologist
MBBS - FRCS. DU">Dr. Munir Amin Mughal
Urologist
MBBS - FRCS. DU</option>
	  <option value="Dr. Latif Qureshi
Urologist
MBBS - Urologist">Dr. Latif Qureshi
Urologist
MBBS - Urologist</option>
	  <option value="Dr. Manzoor Ahmad Malik
Urologist
MBBS - Urologist">Dr. Manzoor Ahmad Malik
Urologist
MBBS - Urologist</option>
	  <option value="Dr. Rai Ijaz Ahmad Kharal
Urologist
MBBS - Urologist">Dr. Rai Ijaz Ahmad Kharal
Urologist
MBBS - Urologist</option>
	  <option value="Dr. Zafar Ehsan
Urologist
MBBS - Urologist">Dr. Zafar Ehsan
Urologist
MBBS - Urologist</option>
	   <option value="Dr. Mohammad I.Javaid
Urologist
MBBS - Urologist">Dr. Mohammad I.Javaid
Urologist
MBBS - Urologist</option>
	  <option value="Dr. Sajjad Hussain
Urologist
MBBS - Urologist">Dr. Sajjad Hussain
Urologist
MBBS - Urologist</option>
	  <option value="Dr. Dr. M. Sarfraz Ahmad
Urologist
MBBS - Urologist">Dr. Dr. M. Sarfraz Ahmad
Urologist
MBBS - Urologist</option>
	  <option value="Dr. Zafar Ul Ahsan
Urologist
MBBS - Urologist">Dr. Zafar Ul Ahsan
Urologist
MBBS - Urologist</option>
	  <option value="Dr. Junaid Habib Khan
Urologist
MBBS - M.S (Urology)">Dr. Junaid Habib Khan
Urologist
MBBS - M.S (Urology)</option>
	   <option value="Brig Dr. Mohammad Ramza..
Urologist">Brig Dr. Mohammad Ramza..
Urologist</option>
	  <option value="Dr. Asghar Ali Dogar
Urologist">Dr. Asghar Ali Dogar
Urologist</option>
	  <option value="Dr. Muhammad Kaleem
Urologist">Dr. Muhammad Kaleem
Urologist</option>
	  <option value="Dr. Muhammad Khalid Butt
Urologist">Dr. Muhammad Khalid Butt
Urologist</option>
	  <option value="Dr. Shoukat Zubair
Urologist">Dr. Shoukat Zubair
Urologist</option>
	   <option value="Dr. Zia Ul Miraj Ahmed
Urologist">Dr. Zia Ul Miraj Ahmed
Urologist</option>
	  <option value="Dr. Ahmad Salaman Waris
Urologist">Dr. Ahmad Salaman Waris
Urologist</option>
	  <option value="Dr. Ehsan Ullah Khan
Urologist">Dr. Ehsan Ullah Khan
Urologist</option>
	  <option value="Dr. Mohammad I Javaid
Urologist">Dr. Mohammad I Javaid
Urologist</option>
	  <option value="Dr. Naveed Iqbal
Urologist">Dr. Naveed Iqbal
Urologist</option>
	   <option value="TRAUMATOLOGIST IN HOSPITALS"><b>TRAUMATOLOGIST IN HOSPITALS</b></option>
	  <option value="Syed Hasnain Raza Shirazi
Traumatologist
emergency medical ..">Syed Hasnain Raza Shirazi
Traumatologist
emergency medical ..</option>
	  <option value="SPEECH THERAPIST IN HOSPITALS"><b>SPEECH THERAPIST IN HOSPITALS</b></option>
	  <option value="Sana Asghar
Speech Therapist
BSc (hons) Speech .">Sana Asghar
Speech Therapist
BSc (hons) Speech .</option>
	  <option value="Waqas Azeem
Speech Therapist
Ms-Speech and Lang..">Waqas Azeem
Speech Therapist
Ms-Speech and Lang..</option>
	   <option value="Mrs Mehak Murad
Speech Therapist
BS (hons) Speech a..">Mrs Mehak Murad
Speech Therapist
BS (hons) Speech a..</option>
	  <option value="Asia Nazir
Speech Therapist
M.Phil Speech lang..">Asia Nazir
Speech Therapist
M.Phil Speech lang..</option>
	  <option value="Hafsa Fiaz
Speech Therapist
MS Speech - Langua..">Hafsa Fiaz
Speech Therapist
MS Speech - Langua..</option>
	  <option value="Amna Ashraf
Speech Therapist
BSC.Hon,MS in Spee..">Amna Ashraf
Speech Therapist
BSC.Hon,MS in Spee..</option>
	  <option value="Maria Awan
Speech Therapist
BS Speech and lang..">Maria Awan
Speech Therapist
BS Speech and lang..</option>
	   <option value="Mrs. Uzma Rizwan
Speech Therapist
Masters in Special..">Mrs. Uzma Rizwan
Speech Therapist
Masters in Special..</option>
	  <option value="Amna Ashraf
Speech Therapist
BSC Hons M.S Spee..">Amna Ashraf
Speech Therapist
BSC Hons M.S Spee..</option>
	  <option value="Aqsa Waris
Speech Therapist
BS Speech Language..">Aqsa Waris
Speech Therapist
BS Speech Language..</option>
	  <option value="Iqra Naseer
Speech Therapist
Mphil Speech Langu..">Iqra Naseer
Speech Therapist
Mphil Speech Langu..</option>
	  <option value="Saima Ashraf
Speech Therapist
Msc psychology, PG..">Saima Ashraf
Speech Therapist
Msc psychology, PG..</option>
	   <option value="Ms. Safa Pervaiz
Speech Therapist
Mphil Speech Langu..">Ms. Safa Pervaiz
Speech Therapist
Mphil Speech Langu..</option>
	  <option value="Ms.Rabia Azmat
Speech Therapist
BS (hons) speech a..">Ms.Rabia Azmat
Speech Therapist
BS (hons) speech a..</option>
	  <option value="Dr Fouzia Saleemi
Speech Therapist
MPhil speech langu..">Dr Fouzia Saleemi
Speech Therapist
MPhil speech langu..</option>
	  <option value="Anum Ashraf
Speech Therapist
BS-SLP (UHS), clin..">Anum Ashraf
Speech Therapist
BS-SLP (UHS), clin..</option>
	  <option value="Ghazal Awais
Speech Therapist
BS (Speech and lan..">Ghazal Awais
Speech Therapist
BS (Speech and lan..</option>
	   <option value="Sidra Ansar
Speech Therapist
MS in Speech and L..">Sidra Ansar
Speech Therapist
MS in Speech and L..</option>
	  <option value="Razia Sultana

Speech Therapist">Razia Sultana

Speech Therapist</option>
	  <option value="Ms Samia Kanwal
Speech Therapist
BS(Speech and Lang..">Ms Samia Kanwal
Speech Therapist
BS(Speech and Lang..</option>
	  <option value="Iqra javaid
Speech Therapist
Bs speech and lang..">Iqra javaid
Speech Therapist
Bs speech and lang..</option>
	  <option value="Maria Ishtiaq
Speech Therapist
M.S Speech and lan..">Maria Ishtiaq
Speech Therapist
M.S Speech and lan..</option>
	   <option value="Rabia Naeem
Speech Therapist
Bs(hons) speech an..">Rabia Naeem
Speech Therapist
Bs(hons) speech an..</option>
	  <option value="Nimra Nawaz
Speech Therapist
MS SLP (RIU) . BSc..">Nimra Nawaz
Speech Therapist
MS SLP (RIU) . BSc..</option>
	  <option value="SKIN SPECIALIST IN HOSPITALS"><b>SKIN SPECIALIST IN HOSPITALS</b></option>
	  <option value="Dr Ahsan Kambob
Skin Specialist
M.b.b.s England Sp..">Dr Ahsan Kambob
Skin Specialist
M.b.b.s England Sp..</option>
	  <option value="Dr Tanveer Gillani
Skin Specialist">Dr Tanveer Gillani
Skin Specialist</option>
	   <option value="Dr. Afshan K Siddiqui
Skin Specialist">Dr. Afshan K Siddiqui
Skin Specialist</option>
	  <option value="Dr. Abdussalam Cheema
Skin Specialist">Dr. Abdussalam Cheema
Skin Specialist</option>
	  <option value="Dr. Sohail Asad
Skin Specialist">Dr. Sohail Asad
Skin Specialist</option>
	  <option value="Dr. Tariq Zaman
Skin Specialist">Dr. Tariq Zaman
Skin Specialist</option>
	  <option value="Dr. A. Rafi Masood
Skin Specialist">Dr. A. Rafi Masood
Skin Specialist</option>
	   <option value="Dr. Naveed Shehzad Mrs
Skin Specialist">Dr. Naveed Shehzad Mrs
Skin Specialist</option>
	  <option value="Dr. Syed Ghulam Shabbir
Skin Specialist">Dr. Syed Ghulam Shabbir
Skin Specialist</option>
	  <option value="Dr. Rizwantoor
Skin Specialist">Dr. Rizwantoor
Skin Specialist</option>
	  <option value="Dr. Mohammad Jamshaid B..
Skin Specialist">Dr. Mohammad Jamshaid B..
Skin Specialist</option>
	  <option value="Dr. Omar H.Shaikh
Skin Specialist">Dr. Omar H.Shaikh
Skin Specialist</option>
	   <option value="Dr. Syed Atif Hasnain K..
Skin Specialist">Dr. Syed Atif Hasnain K..
Skin Specialist</option>
	  <option value="Dr. Sabrina Sohail
Skin Specialist">Dr. Sabrina Sohail
Skin Specialist</option>
	  <option value="Dr. Obaid-Ur-Rehman
Skin Specialist">Dr. Obaid-Ur-Rehman
Skin Specialist</option>
	  <option value="Dr. Syed Ghulam Shabir
Skin Specialist">Dr. Syed Ghulam Shabir
Skin Specialist</option>
	  <option value="Dr. S. Atif Kazmi
Skin Specialist">Dr. S. Atif Kazmi
Skin Specialist</option>
	   <option value="Dr. Brig. (Retd) Syed M..
Skin Specialist">Dr. Brig. (Retd) Syed M..
Skin Specialist</option>
	  <option value="Dr. Khawar Khursheed
Skin Specialist">Dr. Khawar Khursheed
Skin Specialist</option>
	  <option value="Dr. Mohammad Idrees
Skin Specialist">Dr. Mohammad Idrees
Skin Specialist</option>
	  <option value="Dr. Haseeb Sajjad
Skin Specialist">Dr. Haseeb Sajjad
Skin Specialist</option>
	  <option value="Dr. Tahir Kamal
Skin Specialist">Dr. Tahir Kamal
Skin Specialist</option>
	  <option value="Dr. Chaudhary Mohammad ..
Skin Specialist">Dr. Chaudhary Mohammad ..
Skin Specialist</option>
	  <option value="Dr. H. A. Khawaja
Skin Specialist">Dr. H. A. Khawaja
Skin Specialist</option>
	  <option value="Dr. Mian Muhammad Muslim
Skin Specialist">Dr. Mian Muhammad Muslim
Skin Specialist</option>
	  <option value="Barig Naser Rasheed Dar
Skin Specialist
B.a">Barig Naser Rasheed Dar
Skin Specialist
B.a</option>
	  <option value="Dr Tariq Niaz
Skin Specialist
MBBS,M,Derm (UK)">Dr Tariq Niaz
Skin Specialist
MBBS,M,Derm (UK)</option>
	   <option value="Dr Tariq Niaz
Skin Specialist
MBBS,MSc ,Derm (UK)
">Dr Tariq Niaz
Skin Specialist
MBBS,MSc ,Derm (UK)
</option>
	  <option value="RHEUMATOLOGIST IN HOSPITALS"><b>RHEUMATOLOGIST IN HOSPITALS</b></option>
	  <option value="Tafazzul H. Mahmud MD
Rheumatologist
MB, MRCP (UK),FRCP..">Tafazzul H. Mahmud MD
Rheumatologist
MB, MRCP (UK),FRCP..</option>
	  <option value="Dr. Ruidong Zhang
Rheumatologist
Rheumatology Speci.">Dr. Ruidong Zhang
Rheumatologist
Rheumatology Speci.</option>
	  <option value="Dr Saba Saif
Rheumatologist
Mbbs fcps medicine..">Dr Saba Saif
Rheumatologist
Mbbs fcps medicine..</option>
	   <option value="Aamir Saeed
Rheumatologist
MRCP (Ire), MRCPS ..">Aamir Saeed
Rheumatologist
MRCP (Ire), MRCPS ..</option>
	  <option value="RADIOLOGIST IN HOSPITALS"><b>RADIOLOGIST IN HOSPITALS</b></option>
	  <option value="Dr.Khalid Idrees
Radiologist
MBBS, FCPS (Radiol..">Dr.Khalid Idrees
Radiologist
MBBS, FCPS (Radiol..</option>
	  <option value="Tanveer Zubairi
Radiologist
MBBS, MCPS, Advanc..">Tanveer Zubairi
Radiologist
MBBS, MCPS, Advanc..</option>
	  <option value="Dr Rafia Asim
Radiologist
M.B.B.S. FCPS Radi..">Dr Rafia Asim
Radiologist
M.B.B.S. FCPS Radi..</option>
	   <option value="Rashid Rasheed
Radiologist
MBBS, FCPS">Rashid Rasheed
Radiologist
MBBS, FCPS</option>
	  <option value="Dr Khurrum Ejaz
Radiologist
MBBS,FCPS">Dr Khurrum Ejaz
Radiologist
MBBS,FCPS</option>
	  <option value="Dr. Shumaila Auqil
Radiologist
M.B.B.S, FCPS Radi..">Dr. Shumaila Auqil
Radiologist
M.B.B.S, FCPS Radi..</option>
	  <option value="Dr Farah Rashid
Radiologist
MBBS, FCPS">Dr Farah Rashid
Radiologist
MBBS, FCPS</option>
	  <option value="Dr Rafia Irum
Radiologist
Mbbs FCPS Radiology">Dr Rafia Irum
Radiologist
Mbbs FCPS Radiology</option>
	   <option value="Dr Muhammad Wasif Iqbal
Radiologist
MBBS,MCPS,FCPS">Dr Muhammad Wasif Iqbal
Radiologist
MBBS,MCPS,FCPS</option>
	  <option value="Shafiq Ahmad
Radiologist
MBBS, DMRD - Radio..">Shafiq Ahmad
Radiologist
MBBS, DMRD - Radio..</option>
	  <option value="Dr. Robina Anwar
Radiologist
MBBS, FTIDU (Tokyo..">Dr. Robina Anwar
Radiologist
MBBS, FTIDU (Tokyo..</option>
	  <option value="Dr. Asghar Saleem
Radiologist
MBBS, DMRD - Radio.">Dr. Asghar Saleem
Radiologist
MBBS, DMRD - Radio.</option>
	  <option value="Dr. Mohamad Iqbal
Radiologist
MBBS, DMRD - Radio..">Dr. Mohamad Iqbal
Radiologist
MBBS, DMRD - Radio..</option>
	   <option value="Dr. Najam Ud Din
Radiologist
MBBS, MCPS , DMRD,..">Dr. Najam Ud Din
Radiologist
MBBS, MCPS , DMRD,..</option>
	  <option value="Dr. Solomon Elahi
Radiologist
MBBS, DMRD - Radio..">Dr. Solomon Elahi
Radiologist
MBBS, DMRD - Radio..</option>
	  <option value="Dr. Mohammad Aslam Qure..
Radiologist
MBBS, DMRD - Radio..">Dr. Mohammad Aslam Qure..
Radiologist
MBBS, DMRD - Radio..</option>
	  <option value="Dr. Saqib Javed Ahmad
Radiologist
MBBS, MD, DMRD , M..">Dr. Saqib Javed Ahmad
Radiologist
MBBS, MD, DMRD , M..</option>
	  <option value="Dr. Irfan Masood
Radiologist
MBBS, DMRD - Radio..">Dr. Irfan Masood
Radiologist
MBBS, DMRD - Radio..</option>
	   <option value="Dr. Nila Rahim
Radiologist
MBBS, DMRD - Radio..">Dr. Nila Rahim
Radiologist
MBBS, DMRD - Radio..</option>
	  <option value="Dr. Aamer Rahim
Radiologist
MBBS, DMRD, FCPS, ..">Dr. Aamer Rahim
Radiologist
MBBS, DMRD, FCPS, ..</option>
	  <option value="Dr. Najam Bohkari
Radiologist
MBBS, MCPS(PAK).DM..">Dr. Najam Bohkari
Radiologist
MBBS, MCPS(PAK).DM..</option>
	  <option value="Dr. Mazhar Zaidi
Radiologist
MBBS, (pb) DMRD, M..">Dr. Mazhar Zaidi
Radiologist
MBBS, (pb) DMRD, M..</option>
	  <option value="Dr. M.Rahim
Radiologist
MBBS, DMRD - Radio..">Dr. M.Rahim
Radiologist
MBBS, DMRD - Radio..</option>
	   <option value="Dr. S.M. Nasir Qadri
Radiologist
MBBS, DMRD - Radio..">Dr. S.M. Nasir Qadri
Radiologist
MBBS, DMRD - Radio..</option>
	  <option value="Dr. Syed Imran Haidar
Radiologist
MBBS, DMRD - Radio..">Dr. Syed Imran Haidar
Radiologist
MBBS, DMRD - Radio..</option>
	  <option value="Dr. Ghulam Mohammad
Radiologist
MBBS, DMRD - Radio..">Dr. Ghulam Mohammad
Radiologist
MBBS, DMRD - Radio..</option>
	  <option value="Dr. Shazia Sultan
Radiologist
MBBS, DMRD - Radio..">Dr. Shazia Sultan
Radiologist
MBBS, DMRD - Radio..</option>
	  <option value="Dr. Mohammad Inam Elahi
Radiologist
MBBS, MD(USA), DMR..">Dr. Mohammad Inam Elahi
Radiologist
MBBS, MD(USA), DMR..</option>
	   <option value="Dr. Mohammad Zaheer Khan
Radiologist
MBBS, DMRD - Radio..">Dr. Mohammad Zaheer Khan
Radiologist
MBBS, DMRD - Radio..</option>
	  <option value="Dr. Khubaib Shahid
Radiologist
MBBS, MCPS, FCPS, ..">Dr. Khubaib Shahid
Radiologist
MBBS, MCPS, FCPS, ..</option>
	  <option value="Dr. Sohail Naqvi
Radiologist
MBBS, DMRD - Radio..">Dr. Sohail Naqvi
Radiologist
MBBS, DMRD - Radio..</option>
	  <option value="Dr. Arif Qureshi
Radiologist
MD, FACA - Radiolo..">Dr. Arif Qureshi
Radiologist
MD, FACA - Radiolo..</option>
	  <option value="Dr. Nila L.Khan
Radiologist
MBBS, DMRD - Radio..">Dr. Nila L.Khan
Radiologist
MBBS, DMRD - Radio..</option>
	   <option value="Dr. Sadaf Ali
Radiologist
MBBS, DMRD - Radio..">Dr. Sadaf Ali
Radiologist
MBBS, DMRD - Radio..</option>
	  <option value="Dr. M Jamshaid Mohsin
Radiologist
MBBS, DMRD - Radio..">Dr. M Jamshaid Mohsin
Radiologist
MBBS, DMRD - Radio..</option>
	  <option value="Dr. Iqbal Hussain Dogar
Radiologist
MBBS, MAIUM , DMRD..">Dr. Iqbal Hussain Dogar
Radiologist
MBBS, MAIUM , DMRD..</option>
	  <option value="PHYSICAL THERAPIST IN HOSPITALS "><b>PHYSICAL THERAPIST IN HOSPITALS </b></option>
	  <option value="Ayesha Rehman
Physical Therapist
DPT, M.S (Orthoped..">Ayesha Rehman
Physical Therapist
DPT, M.S (Orthoped..</option>
	   <option value="Zeeshan Saeed
Physical Therapist
DPT">Zeeshan Saeed
Physical Therapist
DPT</option>
	  <option value="Waseem Javaid
Physical Therapist
BSC (Physiotherapy..">Waseem Javaid
Physical Therapist
BSC (Physiotherapy..</option>
	  <option value="Shahid Imran
Physical Therapist
BS (Physiotherapy)..">Shahid Imran
Physical Therapist
BS (Physiotherapy)..</option>
	  <option value="Mehwish Niaz
Physical Therapist
B.S.C (Physiothera..">Mehwish Niaz
Physical Therapist
B.S.C (Physiothera..</option>
	  <option value="Naveed Anwar
Physical Therapist
Ph.D, DPT, MS OMPT">Naveed Anwar
Physical Therapist
Ph.D, DPT, MS OMPT</option>
	   <option value="Waseem Sarwar
Physical Therapist
DPT">Waseem Sarwar
Physical Therapist
DPT</option>
	  <option value="Hafiz zohaib
Physical Therapist
DPT, MS (Neurology)">Hafiz zohaib
Physical Therapist
DPT, MS (Neurology)</option>
	  <option value="Dr Ali Raza
Physical Therapist
BSPT, MSPT Scholar">Dr Ali Raza
Physical Therapist
BSPT, MSPT Scholar</option>
	  <option value="Waqar Ahmad
Physical Therapist
DPT, MA (Special E..">Waqar Ahmad
Physical Therapist
DPT, MA (Special E..</option>
	  <option value="Marriam Zakria
Physical Therapist
DPT, MS OMPT">Marriam Zakria
Physical Therapist
DPT, MS OMPT</option>
	  <option value="Waqar Ahmad
Physical Therapist
DPT, MA (Special E..">Waqar Ahmad
Physical Therapist
DPT, MA (Special E..</option>
	  <option value="Marriam Zakria
Physical Therapist
DPT, MS OMPT">Marriam Zakria
Physical Therapist
DPT, MS OMPT</option>
	  <option value="Tehmina Irfan
Physical Therapist
DPT, MS (Orthopedic)">Tehmina Irfan
Physical Therapist
DPT, MS (Orthopedic)</option>
	  <option value="Khalid Saeed Khan
Physical Therapist
BSC (Physiotherapy..">Khalid Saeed Khan
Physical Therapist
BSC (Physiotherapy..</option>
	  <option value="Salik Nadeem
Physical Therapist
BSPT, PPDPT">Salik Nadeem
Physical Therapist
BSPT, PPDPT</option>
	   <option value="Ayesha Javed
Physical Therapist
DPT">Ayesha Javed
Physical Therapist
DPT</option>
	  <option value="Hira Idrees
Physical Therapist
DPT(Pak)">Hira Idrees
Physical Therapist
DPT(Pak)</option>
	  <option value="Waseem
Physical Therapist
MPhil. ppdpt. pgd ..">Waseem
Physical Therapist
MPhil. ppdpt. pgd ..</option>
	  <option value="Dr Ata ur Rehman
Physical Therapist
BSPT, DMPT,MBA*">Dr Ata ur Rehman
Physical Therapist
BSPT, DMPT,MBA*</option>
	  <option value="Dr Baria Rizwan
Physical Therapist
Doctor of Physioth..">Dr Baria Rizwan
Physical Therapist
Doctor of Physioth.. </option>
	   <option value="Dr Muhammad Asrar Yousaf
Physical Therapist
B.S.P.T (UHS) DPT,..">Dr Muhammad Asrar Yousaf
Physical Therapist
B.S.P.T (UHS) DPT,..</option>
	  <option value="Dr Saad Ali
Physical Therapist
DPT(SMC)">Dr Saad Ali
Physical Therapist
DPT(SMC)</option>
	  <option value="Dr Saad Ali
Physical Therapist
DPT( SMC)">Dr Saad Ali
Physical Therapist
DPT( SMC)</option>
	  <option value="Ali Raza
Physical Therapist
Doctor of Physical..">Ali Raza
Physical Therapist
Doctor of Physical..</option>
	  <option value="Dr. Sang Maiin
Physical Therapist
DPT, MBBS, FCPS">Dr. Sang Maiin
Physical Therapist
DPT, MBBS, FCPS</option>
	   <option value="Dr Saqlain Hayat
Physical Therapist">Dr Saqlain Hayat
Physical Therapist</option>
	  <option value="Dr. Sohaib Hassan
Physical Therapist
MBBS - Physical Th..">Dr. Sohaib Hassan
Physical Therapist
MBBS - Physical Th..</option>
	  <option value="Dr. Sajid Qayyum
Physical Therapist
MBBS - Physical Th..">Dr. Sajid Qayyum
Physical Therapist
MBBS - Physical Th..</option>
	  <option value="Dr. Hafiz Muhammad Mobeen
Physical Therapist
MBBS - Physical Th..">Dr. Hafiz Muhammad Mobeen
Physical Therapist
MBBS - Physical Th..</option>
	  <option value="Dr. Tahira
Physical Therapist
MBBS - Physical Th..">Dr. Tahira
Physical Therapist
MBBS - Physical Th..</option>
	   <option value="Raheem Akram
Physical Therapist
DPT">Raheem Akram
Physical Therapist
DPT</option>
	  <option value="Adnan Ikram
Physical Therapist
DPT">Adnan Ikram
Physical Therapist
DPT</option>
	  <option value="Najma Khan
Physical Therapist
BSPT ,MA(special E..">Najma Khan
Physical Therapist
BSPT ,MA(special E..</option>
	  <option value="Adnan Afzal
Physical Therapist
RPT,DPT,CLT,">Adnan Afzal
Physical Therapist
RPT,DPT,CLT,</option>
	  <option value="Omer Rashid
Physical Therapist
DPT, Certified Kin..">Omer Rashid
Physical Therapist
DPT, Certified Kin..</option>
	   <option value="AUDIOLOGIST IN HOSPITALS"><b>AUDIOLOGIST IN HOSPITALS</b></option>
	  <option value="Shumaila Malik
Audiologist
Bs.(Hon's) Audiolo..">Shumaila Malik
Audiologist
Bs.(Hon's) Audiolo..</option>
	  <option value="Hina Saeed Ch
Audiologist
BSC (HONS) Audiology">Hina Saeed Ch
Audiologist
BSC (HONS) Audiology</option>
	  <option value="Maha Afzaal Butt
Audiologist
MPhil. Audiology(I..">Maha Afzaal Butt
Audiologist
MPhil. Audiology(I..</option>
	  <option value="Dr Wajeeha Zaib
Audiologist
Bs(audiology)MSSLH..">Dr Wajeeha Zaib
Audiologist
Bs(audiology)MSSLH..</option>
	   <option value="Dr. Nadeem Mukhtar
Audiologist">Dr. Nadeem Mukhtar
Audiologist</option>
	  <option value="Dr Asim Khan
Audiologist
MSC Audiology">Dr Asim Khan
Audiologist
MSC Audiology</option>
<option value="CANCER SPECIALIST IN HOSPITALS"><b>CANCER SPECIALIST IN HOSPITALS</b></option>
	  <option value="Dr. Amjad S K Durrani
Cancer Specialist">Dr. Amjad S K Durrani
Cancer Specialist</option>
	  <option value="Dr. Abubakar Shahid
Cancer Specialist">Dr. Abubakar Shahid
Cancer Specialist</option>
	  <option value="Dr. Lt. Col. (R) Ghulam..
Cancer Specialist">Dr. Lt. Col. (R) Ghulam..
Cancer Specialist</option>
	   <option value="Dr. Misbah Masood
Cancer Specialist
DMRT; FCPS.">Dr. Misbah Masood
Cancer Specialist
DMRT; FCPS.</option>
	  <option value="Dr. Shaheena Parveen
Cancer Specialist">Dr. Shaheena Parveen
Cancer Specialist</option>
	  <option value="Dr. Shaheena Parveen
Cancer Specialist">Dr. Arzoo Fatima
Cancer Specialist</option>
	  <option value="Dr. Muhammed Sleem
Cancer Specialist">Dr. Muhammed Sleem
Cancer Specialist</option>
	  <option value="Dr. Abu Bakar
Cancer Specialist">Dr. Abu Bakar
Cancer Specialist</option>
	   <option value="Dr. Afaq Ahmed Qureshi
Cancer Specialist">Dr. Afaq Ahmed Qureshi
Cancer Specialist</option>
	  <option value="Dr. Numair
Cancer Specialist">Dr. Numair
Cancer Specialist</option>
	  <option value="Dr. Reena Sajjad
Cancer Specialist">Dr. Reena Sajjad
Cancer Specialist</option>
	  <option value="Dr. Saeeda Asghar
Cancer Specialist">Dr. Saeeda Asghar
Cancer Specialist</option>
	  <option value="Dr. Mumtaz Ahmed
Cancer Specialist">Dr. Mumtaz Ahmed
Cancer Specialist</option>
	   <option value="Dr. Suhail Ahmed Anwar
Cancer Specialist">Dr. Suhail Ahmed Anwar
Cancer Specialist</option>
	  <option value="Dr. Imtiaz Ahmad Ranndh..
Cancer Specialist">Dr. Imtiaz Ahmad Ranndh..
Cancer Specialist</option>
	  <option value="Dr Arif Ch
Cancer Specialist
Diplomate American..">Dr Arif Ch
Cancer Specialist
Diplomate American..</option>
	  <option value="Dr. Nadeem Zia
Cancer Specialist
MBBS(KE)DMRT(UHS)G..">Dr. Nadeem Zia
Cancer Specialist
MBBS(KE)DMRT(UHS)G..</option>
	  <option value="Mansoor Ahmed Mazari
Cancer Specialist
Fcps">Mansoor Ahmed Mazari
Cancer Specialist
Fcps</option>
	   <option value="Dr Tariq Mahmood
Cancer Specialist
mbbs, fcps">Dr Tariq Mahmood
Cancer Specialist
mbbs, fcps</option>
	  <option value="Dr Khalid Shabbir
Cancer Specialist
MBBS, DMRT, FCPS (..">Dr Khalid Shabbir
Cancer Specialist
MBBS, DMRT, FCPS (..</option>
	  <option value="PATHOLOGIST IN HOSPITALS"><b>PATHOLOGIST IN HOSPITALS</b></option>
	  <option value="Dr. Zahid Asgher
Pathologist
MBBS, MD, DAB, FCA..">Dr. Zahid Asgher
Pathologist
MBBS, MD, DAB, FCA..</option>
	  <option value="Dr. Mohammad Naseem You..
Pathologist
MBBS, DCPath - Pat..">Dr. Mohammad Naseem You..
Pathologist
MBBS, DCPath - Pat..</option>
	   <option value="Dr. Ejaz Ahmad
Pathologist
MBBS, DAB. - Patho..">Dr. Ejaz Ahmad
Pathologist
MBBS, DAB. - Patho..</option>
	  <option value="Dr. Muhammad Tariq Mahm..
Pathologist
MBBS, DAB - Pathol..">Dr. Muhammad Tariq Mahm..
Pathologist
MBBS, DAB - Pathol..</option>
	  <option value="Dr. Qasim Ahmad
Pathologist
MBBS, DAB. - Patho..">Dr. Qasim Ahmad
Pathologist
MBBS, DAB. - Patho..</option>
	  <option value="Dr. Rafay Azhar
Pathologist
MBBS, MRC.Path. - ..">Dr. Rafay Azhar
Pathologist
MBBS, MRC.Path. - ..</option>
	  <option value="Dr. Samina Mansoor
Pathologist
MBBS, MSc, DAB. - ..">Dr. Samina Mansoor
Pathologist
MBBS, MSc, DAB. - ..</option>
	   <option value="Dr. Muhammad Sharif
Pathologist
MBBS, BSc, PhD. - ..">Dr. Muhammad Sharif
Pathologist
MBBS, BSc, PhD. - ..</option>
	  <option value="Dr. Millat Sultan
Pathologist
mbbs, mphil - Path..">Dr. Millat Sultan
Pathologist
mbbs, mphil - Path..</option>
	  <option value="Dr. A. Qadir Khan
Pathologist
MSc, PhD. - Pathol..">Dr. A. Qadir Khan
Pathologist
MSc, PhD. - Pathol..</option>
	  <option value="Dr. S. Shah Jahan
Pathologist
MBBS, M.Phil. - Pa..">Dr. S. Shah Jahan
Pathologist
MBBS, M.Phil. - Pa..</option>
	  <option value="Dr. Syed Shoaib Shah
Pathologist
MBBS, DMJ, M.Phil...">Dr. Syed Shoaib Shah
Pathologist
MBBS, DMJ, M.Phil...</option>
	   <option value="Dr. Hafeez Ul Haq
Pathologist
MBBS, M.Phil. - Pa..">Dr. Hafeez Ul Haq
Pathologist
MBBS, M.Phil. - Pa..</option>
	  <option value="Dr. Mohammad Ayub
Pathologist
MBBS, MRCP - Patho..">Dr. Mohammad Ayub
Pathologist
MBBS, MRCP - Patho..</option>
	  <option value="Dr. Mateen Izhar
Pathologist
MBBS, PhD, MRC. - ..">Dr. Mateen Izhar
Pathologist
MBBS, PhD, MRC. - ..</option>
	  <option value="Dr. Nisar Ahmad
Pathologist
MBBS, FCPS. - Path..">Dr. Nisar Ahmad
Pathologist
MBBS, FCPS. - Path..</option>
	  <option value="Dr. Shehzad Qureshi
Pathologist
MBBS, MSc, MRCPath..">Dr. Shehzad Qureshi
Pathologist
MBBS, MSc, MRCPath..</option>
	  
	  <option value="Dr. Khalid Masood Ahmed
Pathologist
MBBS, DPM - Pathol..">Dr. Khalid Masood Ahmed
Pathologist
MBBS, DPM - Pathol..</option>
	  <option value="Dr. M. A. Farooqi
Pathologist
MBBS, MPH, DCS - P..">Dr. M. A. Farooqi
Pathologist
MBBS, MPH, DCS - P..</option>
	  <option value="Dr. Saeed Akhtar
Pathologist
MBBS, M.Phil. - Pa..">Dr. Saeed Akhtar
Pathologist
MBBS, M.Phil. - Pa..</option>
	  <option value="Dr. I. A. Naveed
Pathologist
MBBS, M.Phil - Pat..">Dr. I. A. Naveed
Pathologist
MBBS, M.Phil - Pat..</option>
	  <option value="Dr. Nisar Hussain Khan
Pathologist
MBBS, DCH, DTM&H ,..">Dr. Nisar Hussain Khan
Pathologist
MBBS, DCH, DTM&H ,..</option>
	  <option value="Dr. Shakoor Ahmad
Pathologist
MBBS, DP, MRCP , R..">Dr. Shakoor Ahmad
Pathologist
MBBS, DP, MRCP , R..</option>
	   <option value="Dr. Tariq Mehmood
Pathologist
MBBS, M.Phil, FCPS..">Dr. Tariq Mehmood
Pathologist
MBBS, M.Phil, FCPS..</option>
	  <option value="Dr. Abid Javed Minhas
Pathologist
BSPT, MPPS. - Path..">Dr. Abid Javed Minhas
Pathologist
BSPT, MPPS. - Path..</option>
	  <option value="Dr. M. Latif
Pathologist
MBBS, MCPS - Patho..">Dr. M. Latif
Pathologist
MBBS, MCPS - Patho..</option>
	  <option value="Dr. Altaf Qadir
Pathologist
BSPT, MBBS - Patho..">Dr. Altaf Qadir
Pathologist
BSPT, MBBS - Patho..</option>
	  <option value="Dr. Fakhar Ul Islam
Pathologist
MBBS, DCP - Pathol..">Dr. Fakhar Ul Islam
Pathologist
MBBS, DCP - Pathol..</option>
	   <option value="Dr. Imran Afzal
Pathologist
MBBS, DPM - Pathol..">Dr. Imran Afzal
Pathologist
MBBS, DPM - Pathol..</option>
	  <option value="Dr. Babar Chaudhry
Pathologist
MSc, BSPT - Pathol..">Dr. Babar Chaudhry
Pathologist
MSc, BSPT - Pathol..</option>
	  <option value="Dr. Mehboob Gilani
Pathologist
MBBS, MSc - Pathol..">Dr. Mehboob Gilani
Pathologist
MBBS, MSc - Pathol..</option>
	  <option value="Dr. Muhammad Farooq Alam
Pathologist
MBBS, MCPS - Patho..">Dr. Muhammad Farooq Alam
Pathologist
MBBS, MCPS - Patho..</option>
	  <option value="Dr. Rizwan Akhtar
Pathologist
MBBS, PhD. - Patho..">Dr. Rizwan Akhtar
Pathologist
MBBS, PhD. - Patho..</option>
	   <option value="Dr. Nadeem Mansoor
Pathologist
MBBS, DCP, M.Phil...">Dr. Nadeem Mansoor
Pathologist
MBBS, DCP, M.Phil...</option>
	  <option value="Dr. Sohail Chughtai
Pathologist
MD, DAB. - Patholo..">Dr. Sohail Chughtai
Pathologist
MD, DAB. - Patholo..</option>
	  <option value="Dr. Zahid Asghar
Pathologist
MD, DAB. - Patholo.">Dr. Zahid Asghar
Pathologist
MD, DAB. - Patholo.</option>
	  <option value="ADDICTION SPECIALIST IN HOSPITALS"><b>ADDICTION SPECIALIST IN HOSPITALS</b></option>
	  <option value="Dr M Tarique Arain
Addiction Specialist
FCPS, ATS manageme..">Dr M Tarique Arain
Addiction Specialist
FCPS, ATS manageme..</option>
	   <option value="Dr. Talat Habib
Addiction Specialist
MBBS, ICAP">Dr. Talat Habib
Addiction Specialist
MBBS, ICAP</option>
	  <option value="Muhammad Asim
Addiction Specialist
mbbd">Muhammad Asim
Addiction Specialist
mbbd</option>
	  <option value="Shahid Bangash
Addiction Specialist
MBBS.MD">Shahid Bangash
Addiction Specialist
MBBS.MD</option>
	  <option value="DR.LOHANO (Dr.Heeralal ..
Addiction Specialist
MBBS,EMBA,Masters ..">DR.LOHANO (Dr.Heeralal ..
Addiction Specialist
MBBS,EMBA,Masters ..</option>
	  <option value="Dr Sarfraz Cheema
Addiction Specialist
MBBS.MD.MPH.ICAP3">Dr Sarfraz Cheema
Addiction Specialist
MBBS.MD.MPH.ICAP3</option>
	   <option value="ANAESTHETIST IN HOSPITALS"><b>ANAESTHETIST IN HOSPITALS</b></option>
	  <option value="Syeda ZainabAli Nadeem
Anaesthetist
MBBS,FCPS Resident">Syeda ZainabAli Nadeem
Anaesthetist
MBBS,FCPS Resident</option>
	  <option value="Dr Shahbaz Hussain Bhatti
Anaesthetist
Mbbs,fcps">Dr Shahbaz Hussain Bhatti
Anaesthetist
Mbbs,fcps</option>
	  <option value="Dr. Mushtaq Ahmad
Anaesthetist
MBBS, FCPS - Anaes..">Dr. Mushtaq Ahmad
Anaesthetist
MBBS, FCPS - Anaes..</option>
	  <option value="Dr. Main M.Yaqub
Anaesthetist
MBBS, DA, FFARCS -..">Dr. Main M.Yaqub
Anaesthetist
MBBS, DA, FFARCS -..</option>
	   <option value="Dr. Moin Uddin Malhi
Anaesthetist
MBBS, , FACA, FACP..">Dr. Moin Uddin Malhi
Anaesthetist
MBBS, , FACA, FACP..</option>
	  <option value="Dr. Jameel Sabir
Anaesthetist
MBBS, DIP - Anaest..">Dr. Jameel Sabir
Anaesthetist
MBBS, DIP - Anaest..</option>
	  <option value="Dr. Khalid Iftikhar
Anaesthetist
M.B.B.S , FCPS, - ..">Dr. Khalid Iftikhar
Anaesthetist
M.B.B.S , FCPS, - ..</option>
	  <option value="Dr. Masood -Ur- Rahman
Anaesthetist
MBBS, FCPS - Anaes..">Dr. Masood -Ur- Rahman
Anaesthetist
MBBS, FCPS - Anaes..</option>
	  <option value="Dr. Sajid Usman Kaul
Anaesthetist
MBBS, FRCA (Eng) -..">Dr. Sajid Usman Kaul
Anaesthetist
MBBS, FRCA (Eng) -..</option>
	   <option value="Dr. Hasan Masood Khan
Anaesthetist
MBBS, D.A - Anaest..">Dr. Hasan Masood Khan
Anaesthetist
MBBS, D.A - Anaest..</option>
	  <option value="Dr. Aziz Ul Haq
Anaesthetist
MBBS, FCPS - Anaes.">Dr. Aziz Ul Haq
Anaesthetist
MBBS, FCPS - Anaes.</option>
	  <option value="Dr. Hammad Mehmood Butt
Anaesthetist
MBBS, DPH (pak) D...">Dr. Hammad Mehmood Butt
Anaesthetist
MBBS, DPH (pak) D...</option>
	  <option value="Dr. Naheed Kamal
Anaesthetist
MBBS, D.A (Lond) F..">Dr. Naheed Kamal
Anaesthetist
MBBS, D.A (Lond) F..</option>
	  <option value="Dr. Sikandar Ghafoor
Anaesthetist
MBBS, MCPS - Anaes..">Dr. Sikandar Ghafoor
Anaesthetist
MBBS, MCPS - Anaes..</option>
	   <option value="Dr. Arshad Taqi
Anaesthetist
MBBS, MCPS , FCPS,..">Dr. Arshad Taqi
Anaesthetist
MBBS, MCPS , FCPS,..</option>
	  <option value="Dr. Khalid Bashir
Anaesthetist
MBBS, MCPS FCPS - ..">Dr. Khalid Bashir
Anaesthetist
MBBS, MCPS FCPS - ..</option>
	  <option value="Dr. Shahida Khawaja
Anaesthetist
MBBS, DA.(Lond) FC..">Dr. Shahida Khawaja
Anaesthetist
MBBS, DA.(Lond) FC..</option>
	  <option value="Dr. Kamran Zafar Khan
Anaesthetist
MBBS, MCPS FCPS - ..">Dr. Kamran Zafar Khan
Anaesthetist
MBBS, MCPS FCPS - ..</option>
	  <option value="Dr. Nasrullah Khan
Anaesthetist
MBBS FCPS - Anaes..">Dr. Nasrullah Khan
Anaesthetist
MBBS FCPS - Anaes..</option>
	   <option value="Dr. Zafar-Ul-Haq
Anaesthetist
MBBS, DA - Anaesth.">Dr. Zafar-Ul-Haq
Anaesthetist
MBBS, DA - Anaesth.</option>
	  <option value="Dr. Attiya Sheikh
Anaesthetist
MBBS, DA - Anaesth..">Dr. Attiya Sheikh
Anaesthetist
MBBS, DA - Anaesth..</option>
	  <option value="Dr. Khalid Javed Siddiqi
Anaesthetist
MBBS, FCPS, - Anae..">Dr. Khalid Javed Siddiqi
Anaesthetist
MBBS, FCPS, - Anae..</option>
	  <option value="Dr. Zia-Ur-Rahman Khalid
Anaesthetist
MBBS, DA - Anaesth..">Dr. Zia-Ur-Rahman Khalid
Anaesthetist
MBBS, DA - Anaesth..</option>
	  <option value="Dr. Abdul Jaleel
Anaesthetist
MBBS, DA , FACP - ..">Dr. Abdul Jaleel
Anaesthetist
MBBS, DA , FACP - ..</option>
	   <option value="Dr. Ayesha Asad
Anaesthetist">Dr. Ayesha Asad
Anaesthetist</option>
	  <option value="Dr. Baber Zaheer
Anaesthetist">Dr. Baber Zaheer
Anaesthetist</option>
	  <option value="Dr. Imtiaz Ahmad
Anaesthetist">Dr. Imtiaz Ahmad
Anaesthetist</option>
	  <option value="Dr. Motsim Sheraz
Anaesthetist">Dr. Motsim Sheraz
Anaesthetist</option>
	  <option value="Dr. Muhammad Aslam Ahmeed
Anaesthetist">Dr. Muhammad Aslam Ahmeed
Anaesthetist</option>
	   <option value="Dr. Rehan Amir
Anaesthetist">Dr. Rehan Amir
Anaesthetist</option>
	  <option value="Dr Abdul Naeem Naushad
Anaesthetist
MBBS M.D ( USA )">Dr Abdul Naeem Naushad
Anaesthetist
MBBS M.D ( USA )</option>
	  <option value="Dr.Salman Athar Qureshi
Anaesthetist
MBBS, FCPS">Dr.Salman Athar Qureshi
Anaesthetist
MBBS, FCPS</option>
	  <option value="Dr Sabir Khan
Anaesthetist
Mbbs.fcps">Dr Sabir Khan
Anaesthetist
Mbbs.fcps</option>
	  <option value="PEDIATRICIAN IN HOSPITALS"><b>PEDIATRICIAN IN HOSPITALS</b></option>
	   <option value="Dr Moona Ahmad
Pediatrician
MBBS, FCPS, MRCPCH">Dr Moona Ahmad
Pediatrician
MBBS, FCPS, MRCPCH</option>
	  <option value="Zeeshan Muneer
Pediatrician
MBBS, FCPS (Pediat..">Zeeshan Muneer
Pediatrician
MBBS, FCPS (Pediat..</option>
	  <option value="Muhammad Asif Qureshi
Pediatrician
MBBS, FCPS">Muhammad Asif Qureshi
Pediatrician
MBBS, FCPS</option>
	  <option value="Prof Muhammad Akbar Malik
Pediatrician
MBBS,FCPS, DCH, MC..">Prof Muhammad Akbar Malik
Pediatrician
MBBS,FCPS, DCH, MC..</option>
	  <option value="Prof. Muhammad Rafique
Pediatrician
MBBS, MCPS, FCPS, ..">Prof. Muhammad Rafique
Pediatrician
MBBS, MCPS, FCPS, ..</option>
	   <option value="Naveed Akbar Hotiana
Pediatrician
MBBS, FCPS (Paeds)">Naveed Akbar Hotiana
Pediatrician
MBBS, FCPS (Paeds)</option>
	  <option value="Binish Ali
Pediatrician
MBBS, FCPS (Paedia..">Binish Ali
Pediatrician
MBBS, FCPS (Paedia..</option>
	  <option value="Alia Ahmad
Pediatrician
MBBS, DCH, MRCPCH ..">Alia Ahmad
Pediatrician
MBBS, DCH, MRCPCH ..</option>
	  <option value="Muhammad Sajid
Pediatrician
MBBS, FCPS (Paeds)..">Muhammad Sajid
Pediatrician
MBBS, FCPS (Paeds)..</option>
	  <option value="Rizwan Asad Khan
Pediatrician
MBBS, MCPS, FCPS (..">Rizwan Asad Khan
Pediatrician
MBBS, MCPS, FCPS (..</option>
	  <option value="Abid Rafiq Chaudhry
Pediatrician
MBBS, MRCPCH (UK),..">Abid Rafiq Chaudhry
Pediatrician
MBBS, MRCPCH (UK),..</option>
	  <option value="DR IMTIAZ ZULFIQAR
Pediatrician
MBBS, DCH">DR IMTIAZ ZULFIQAR
Pediatrician
MBBS, DCH</option>
	  <option value="Prof. Tahira S. Izhar
Pediatrician
MBBS - Pediatrician">Prof. Tahira S. Izhar
Pediatrician
MBBS - Pediatrician</option>
	  <option value="Dr. Muhammad Ali Shaikh
Pediatrician">Dr. Muhammad Ali Shaikh
Pediatrician</option>
	  <option value="Dr. Attia Shafiq
Pediatrician">Dr. Attia Shafiq
Pediatrician</option>
	   <option value="Dr. S Tahira Izhar
Pediatrician">Dr. S Tahira Izhar
Pediatrician</option>
	  <option value="Dr. Tahira Izhar-A-Khan
Pediatrician">Dr. Tahira Izhar-A-Khan
Pediatrician</option>
	  <option value="Dr. Muhammad Nasir Rana
Pediatrician">Dr. Muhammad Nasir Rana
Pediatrician</option>
	  <option value="Dr. Nadeem Saquib
Pediatrician">Dr. Nadeem Saquib
Pediatrician</option>
	  <option value="Dr. Humayun Iqbal Khan
Pediatrician">Dr. Humayun Iqbal Khan
Pediatrician</option>
	   <option value="Dr. Mohammad Zia-Ul-Mir..
Pediatrician">Dr. Mohammad Zia-Ul-Mir..
Pediatrician</option>
	  <option value="Dr. Sajjad Rafique
Pediatrician">Dr. Sajjad Rafique
Pediatrician</option>
	  <option value="Dr. Rasheed Khawar
Pediatrician">Dr. Rasheed Khawar
Pediatrician</option>
	  <option value="Dr. Rasid Ayub
Pediatrician">Dr. Rasid Ayub
Pediatrician</option>
	  <option value="Dr. Syed Anwar Ahmed
Pediatrician">Dr. Syed Anwar Ahmed
Pediatrician</option>
	   <option value=""></option>
	  <option value=""></option>
	  <option value=""></option>
	  <option value="Dr. Tariq Zafar
Pediatrician">Dr. Tariq Zafar
Pediatrician</option>
	  <option value="Dr. Muhammad Arif Chaud..
Pediatrician">Dr. Muhammad Arif Chaud..
Pediatrician</option>
	   <option value="Dr. Muhammad Akram
Pediatrician">Dr. Muhammad Akram
Pediatrician</option>
	  <option value="Dr. M.Farooq
Pediatrician">Dr. M.Farooq
Pediatrician</option>
	  <option value="Dr. Waqas Hassan
Pediatrician">Dr. Waqas Hassan
Pediatrician</option>
	  <option value="Dr. Nusrat Yar Khan
Pediatrician">Dr. Nusrat Yar Khan
Pediatrician</option>
	  <option value="Dr. Sheikh Mohammad Iqbal
Pediatrician">Dr. Sheikh Mohammad Iqbal
Pediatrician</option>
	   <option value="Dr. Mohammad Afzal Hayat
Pediatrician">Dr. Mohammad Afzal Hayat
Pediatrician</option>
	  <option value="Dr. Mohammad Arif
Pediatrician">Dr. Mohammad Arif
Pediatrician</option>
	  <option value="Dr. Qamar Zaman
Pediatrician">Dr. Qamar Zaman
Pediatrician</option>
	  <option value="Prof. Dr. Raza Baloch
Pediatrician">Prof. Dr. Raza Baloch
Pediatrician</option>
	  <option value="OPHTHALMOLOGIST IN HOSPITALS"><b>OPHTHALMOLOGIST IN HOSPITALS</b></option>
	   <option value="Dr. Zafar Iqbal Sheikh
Ophthalmologist
Consultant Surgeon">Dr. Zafar Iqbal Sheikh
Ophthalmologist
Consultant Surgeon</option>
	  <option value="Dr. Zia-Ul-Mazhry
Ophthalmologist
FRCS, FCPS">Dr. Zia-Ul-Mazhry
Ophthalmologist
FRCS, FCPS</option>
	  <option value="Dr Muhammad Akram
Ophthalmologist
MBBS, MCPS, DOMS, ..">Dr Muhammad Akram
Ophthalmologist
MBBS, MCPS, DOMS, ..</option>
	  <option value="Dr. Mohammad Tariq Khan
Ophthalmologist">Dr. Mohammad Tariq Khan
Ophthalmologist</option>
	  <option value="Dr. Amanh Tahir Noori
Ophthalmologist">Dr. Amanh Tahir Noori
Ophthalmologist</option>
	   <option value="Dr. Abrar Ilahi Malik
Ophthalmologist">Dr. Abrar Ilahi Malik
Ophthalmologist</option>
	  <option value="Dr. A. Jalil Daula
Ophthalmologist">Dr. A. Jalil Daula
Ophthalmologist</option>
	  <option value="Dr. Irshad Ul Haq
Ophthalmologist">Dr. Irshad Ul Haq
Ophthalmologist</option>
	  <option value="Dr. Shuja-Ud-Din Khan
Ophthalmologist">Dr. Shuja-Ud-Din Khan
Ophthalmologist</option>
	  <option value="Dr. Nadeem Hafeez Butt
Ophthalmologist">Dr. Nadeem Hafeez Butt
Ophthalmologist</option>
	   <option value="Dr. Syed Raza Ali Shah
Ophthalmologist
MBBS, DOMS, CICOph..">Dr. Syed Raza Ali Shah
Ophthalmologist
MBBS, DOMS, CICOph..</option>
	  <option value="Dr. Mohammad Ramzan
Ophthalmologist">Dr. Mohammad Ramzan
Ophthalmologist</option>
	  <option value="Dr. A Jalil Daula
Ophthalmologist">Dr. A Jalil Daula
Ophthalmologist</option>
	  <option value="Dr. Nasira Inayet
Ophthalmologist">Dr. Nasira Inayet
Ophthalmologist</option>
	  <option value="Dr. Sohail Sarwar
Ophthalmologist">Dr. Sohail Sarwar
Ophthalmologist</option>
	   <option value="Dr. M Akhatar Shaheen
Ophthalmologist">Dr. M Akhatar Shaheen
Ophthalmologist</option>
	  <option value="Dr. Khurram Mirza
Ophthalmologist">Dr. Khurram Mirza
Ophthalmologist</option>
	  <option value="M. Sidique Maan
Ophthalmologist
MBBS, FICS, DORCS,..">M. Sidique Maan
Ophthalmologist
MBBS, FICS, DORCS,..</option>
	  <option value="Dr. Nazir Ahmed Aasi
Ophthalmologist
MBBS, DO, FRC - Op.">Dr. Nazir Ahmed Aasi
Ophthalmologist
MBBS, DO, FRC - Op.</option>
	  <option value="Dr. Tariq Saeed
Ophthalmologist
MBBS, DAB - Ophtha..">Dr. Tariq Saeed
Ophthalmologist
MBBS, DAB - Ophtha..</option>
	   <option value="Dr. Ahmad Hussain
Ophthalmologist
MBBS, DOMS - Ophth..">Dr. Ahmad Hussain
Ophthalmologist
MBBS, DOMS - Ophth..</option>
	  <option value="Dr. Edgar Gulzar
Ophthalmologist
MBBS, DOMS, FICS -..">Dr. Edgar Gulzar
Ophthalmologist
MBBS, DOMS, FICS -..</option>
	  <option value="Dr. Khalid Mahmood
Ophthalmologist
MBBS, FCPS, IC, DO..">Dr. Khalid Mahmood
Ophthalmologist
MBBS, FCPS, IC, DO..</option>
	  <option value="Dr. Wajahat Latif
Ophthalmologist
MBBS, FCPS - Ophth..">Dr. Wajahat Latif
Ophthalmologist
MBBS, FCPS - Ophth..</option>
	  <option value="Dr. Mohammad Afzal Sheikh
Ophthalmologist
MBBS, DOMS - Ophth..">Dr. Mohammad Afzal Sheikh
Ophthalmologist
MBBS, DOMS - Ophth..</option>
	   <option value="Dr. S.M. Tahir
Ophthalmologist
MBBS, FRCS - Ophth..">Dr. S.M. Tahir
Ophthalmologist
MBBS, FRCS - Ophth..</option>
	  <option value="Dr. M. H. Ejaz Sandhu
Ophthalmologist
MBBS, DOMS - Ophth..">Dr. M. H. Ejaz Sandhu
Ophthalmologist
MBBS, DOMS - Ophth..</option>
	  <option value="Dr. Zahid Kamal
Ophthalmologist
MBBS, FRCS - Ophth..">Dr. Zahid Kamal
Ophthalmologist
MBBS, FRCS - Ophth..</option>
	  <option value="Dr. Akram Riaz
Ophthalmologist
MBBS, DO, MRCO - O..">Dr. Akram Riaz
Ophthalmologist
MBBS, DO, MRCO - O..</option>
	  <option value="Dr. M. Sidique Maan
Ophthalmologist
MBBS, FICS, DORCS,..">Dr. M. Sidique Maan
Ophthalmologist
MBBS, FICS, DORCS,..</option>
	   <option value="Dr. Mohammad Mateen Amir
Ophthalmologist
MBBS, DMS, FCPS - ..">Dr. Mohammad Mateen Amir
Ophthalmologist
MBBS, DMS, FCPS - ..</option>
	  <option value="Dr. Rizwan Ahmad Cheema
Ophthalmologist
MBBS, FRCS - Ophth..">Dr. Rizwan Ahmad Cheema
Ophthalmologist
MBBS, FRCS - Ophth..</option>
	  <option value="Dr. Zahid Chaudhry
Ophthalmologist
MBBS, MCPS, DOMS, ..">Dr. Zahid Chaudhry
Ophthalmologist
MBBS, MCPS, DOMS, ..</option>
	  <option value="Dr. M. Salim Akhtar
Ophthalmologist
MBBS, FRCS, DO, FR..">Dr. M. Salim Akhtar
Ophthalmologist
MBBS, FRCS, DO, FR..</option>
	  <option value="Dr. Nadeem Riaz
Ophthalmologist
MBBS, FCPS - Ophth.">Dr. Nadeem Riaz
Ophthalmologist
MBBS, FCPS - Ophth.</option>
	   <option value="Dr. Iqbal Ahmad Chaudhry
Ophthalmologist
MBBS, DORCS, DORCP..">Dr. Iqbal Ahmad Chaudhry
Ophthalmologist
MBBS, DORCS, DORCP..</option>
	  <option value="OBSTETRICIAN IN HOSPITALS"><b>OBSTETRICIAN IN HOSPITALS</b></option>
	  <option value="Dr Maria Saeed
Obstetrician
MBBS, MCPS">Dr Maria Saeed
Obstetrician
MBBS, MCPS</option>
	  <option value="Dr Sadia Rashid
Obstetrician
MCPS, FCPS (Obstet..">Dr Sadia Rashid
Obstetrician
MCPS, FCPS (Obstet..</option>
	  <option value="Tasneem Akhtar
Obstetrician
MBBS">Tasneem Akhtar
Obstetrician
MBBS</option>
	  <option value="Dr Maria Saeed
Obstetrician
MBBS, MCPS">Dr Maria Saeed
Obstetrician
MBBS, MCPS</option>
	  <option value="NEUROLOGIST IN HOSPITALS"><b>NEUROLOGIST IN HOSPITALS</b></option>
	  <option value="Muhammad Azeem Ashfaq
Neurologist
MBBS, FCPS, Fellow..">Muhammad Azeem Ashfaq
Neurologist
MBBS, FCPS, Fellow..</option>
	  <option value="Syed Arslan Haider
Neurologist
MBBS, FCPS (Neurol..">Syed Arslan Haider
Neurologist
MBBS, FCPS (Neurol..</option>
	  <option value="Adnan Tariq
Neurologist
MBBS, FCPS (Neurol..">Adnan Tariq
Neurologist
MBBS, FCPS (Neurol..</option>
	   <option value="Adnan Hameed Gill
Neurologist
MBBS, FCPS">Adnan Hameed Gill
Neurologist
MBBS, FCPS</option>
	  <option value="Farrukh Ali Chaudhry
Neurologist
MBBS (KEMC), MD (U..">Farrukh Ali Chaudhry
Neurologist
MBBS (KEMC), MD (U..</option>
	  <option value="Muhammad Zahid Ahmad
Neurologist
MBBS,FCPS">Muhammad Zahid Ahmad
Neurologist
MBBS,FCPS</option>
	  <option value="Dr. Nasir Raza Awan
Neurologist
(FCPS)">Dr. Nasir Raza Awan
Neurologist
(FCPS)</option>
	  <option value="Dr. Sajjad Shahnshah
Neurologist">Dr. Sajjad Shahnshah
Neurologist</option>
	   <option value="Dr. Abdul Hameed
Neurologist
(FCPS)">Dr. Abdul Hameed
Neurologist
(FCPS)</option>
	  <option value="Dr. Naveed Ashraf
Neurologist
(MS)">Dr. Naveed Ashraf
Neurologist
(MS)</option>
	  <option value="Dr. Azam Niaz
Neurologist">Dr. Azam Niaz
Neurologist</option>
	  <option value="Dr. Bashir Ahmed Khan Z..
Neurologist">Dr. Bashir Ahmed Khan Z..
Neurologist</option>
	  <option value="Dr. Hafiz Irfan Jarari
Neurologist">Dr. Hafiz Irfan Jarari
Neurologist</option>
	   <option value="Dr. Fauzia
Neurologist">Dr. Fauzia
Neurologist</option>
	  <option value="Dr. Hammad Malik
Neurologist">Dr. Hammad Malik
Neurologist</option>
	  <option value="Dr. Asma Ghouri
Neurologist">Dr. Asma Ghouri
Neurologist</option>
	  <option value="Dr. Syed Salman Raza Ja..
Neurologist">Dr. Syed Salman Raza Ja..
Neurologist</option>
	  <option value="Dr. Moquit Usman
Neurologist">Dr. Moquit Usman
Neurologist</option>
	   <option value="Dr. Atiq Ur Rehman
Neurologist">Dr. Atiq Ur Rehman
Neurologist</option>
	  <option value="Dr. Naeem Ul Hamid
Neurologist">Dr. Naeem Ul Hamid
Neurologist</option>
	  <option value="Dr. Rafique A Basharat
Neurologist">Dr. Rafique A Basharat
Neurologist</option>
	  <option value="Dr. Ahmad Fawad
Neurologist">Dr. Ahmad Fawad
Neurologist</option>
	  <option value="Dr. Khalid Ch
Neurologist
(FCPS)">Dr. Khalid Ch
Neurologist
(FCPS)</option>
	   <option value="Dr. Brig. Khalid Mahmoo..
Neurologist
(FRCS)">Dr. Brig. Khalid Mahmoo..
Neurologist
(FRCS)</option>
	  <option value="Dr. Amir Ayub
Neurologist">Dr. Amir Ayub
Neurologist</option>
	  <option value="Dr. Abdul Majid
Neurologist
(FCPS)">Dr. Abdul Majid
Neurologist
(FCPS)</option>
	  <option value="Dr. Anwar Chaudhry
Neurologist">Dr. Anwar Chaudhry
Neurologist</option>
	  <option value="Dr. Asif Shabbir
Neurologist">Dr. Asif Shabbir
Neurologist</option>
	   <option value="Dr. Abdul Ghani
Neurologist">Dr. Abdul Ghani
Neurologist</option>
	  <option value="Dr. Muhammad Zafar Iqbal
Neurologist
(FRCS)">Dr. Muhammad Zafar Iqbal
Neurologist
(FRCS)</option>
	  <option value="Dr. Attique-Ur-Rehman
Neurologist">Dr. Attique-Ur-Rehman
Neurologist</option>
	  <option value="Dr. Abdullah Haroon
Neurologist
(FCPS)">Dr. Abdullah Haroon
Neurologist
(FCPS)</option>
	  <option value="Dr. Shahzad Shams
Neurologist
(FRCS)">Dr. Shahzad Shams
Neurologist
(FRCS)</option>
	   <option value="Dr. Kamran Hussain
Neurologist
(FRCS)">Dr. Kamran Hussain
Neurologist
(FRCS)</option>
	  <option value="Dr. Ashraf Iqbal Rana (..
Neurologist">Dr. Ashraf Iqbal Rana (..
Neurologist</option>
	  <option value="Dr. M. Naseem Puri
Neurologist
(FCPS)">Dr. M. Naseem Puri
Neurologist
(FCPS)</option>
	  <option value="NEPHROLOGIST IN HOSPITALS"><b>NEPHROLOGIST IN HOSPITALS</b></option>
	  <option value="Dr Aurangzeb Afzal
Nephrologist
MBBS,MRCP Nephrolo..">Dr Aurangzeb Afzal
Nephrologist
MBBS,MRCP Nephrolo..</option>
	   <option value="Shafiq Cheema
Nephrologist
MD (USA),DABIM (US..">Shafiq Cheema
Nephrologist
MD (USA),DABIM (US..</option>
	  <option value="Muhammad Ahad Qayyum
Nephrologist
MBBS, MRCP(UK), MR..">Muhammad Ahad Qayyum
Nephrologist
MBBS, MRCP(UK), MR..</option>
	  <option value="Hameed Tajamal
Nephrologist
MBBS, MD, FRCPS, M..">Hameed Tajamal
Nephrologist
MBBS, MD, FRCPS, M..</option>
	  <option value="Zahid Rafique
Nephrologist
MBBS, MCPS (Medici..">Zahid Rafique
Nephrologist
MBBS, MCPS (Medici..</option>
	  <option value="Umar Hayat
Nephrologist
MBBS, FCPS (Nephro.">Umar Hayat
Nephrologist
MBBS, FCPS (Nephro.</option>
	   <option value="Azeem Baig
Nephrologist
MBBS, FCPS (Nephro">Azeem Baig
Nephrologist
MBBS, FCPS (Nephro</option>
	  <option value="DR Shafiq Cheema
Nephrologist
MD,DABIM,DABN,FASN..">DR Shafiq Cheema
Nephrologist
MD,DABIM,DABN,FASN..</option>
	  <option value="Ahad Qayyum
Nephrologist
MBBS, MRCP (UK), M..">Ahad Qayyum
Nephrologist
MBBS, MRCP (UK), M..</option>
	  <option value="Dr. Hameed Tajammal Khan
Nephrologist
MBBS, MRCP(UK) FC..">Dr. Hameed Tajammal Khan
Nephrologist
MBBS, MRCP(UK) FC..</option>
	  <option value="Dr Zishan Nasir
Nephrologist
MBBS. FCPS">Dr Zishan Nasir
Nephrologist
MBBS. FCPS</option>
	   <option value="Dr Muhammad Tanzeel Abb..
Nephrologist
M.B;B.S, FCPS">Dr Muhammad Tanzeel Abb..
Nephrologist
M.B;B.S, FCPS</option>
	  <option value="Dr Haroon Ayub
Nephrologist
MBBS, MRCP (UK), F..">Dr Haroon Ayub
Nephrologist
MBBS, MRCP (UK), F..</option>
	  <option value="MEDICAL SPECIALIST IN HOSPITALS"><b>MEDICAL SPECIALIST IN HOSPITALS</b></option>
	  <option value="Dr MUHAMMAD TABISH RAZA
Medical Specialist
M.B.B.S, MD(USA), ..">Dr MUHAMMAD TABISH RAZA
Medical Specialist
M.B.B.S, MD(USA), ..</option>
	  <option value="Dr Aizhu Wang
Medical Specialist
MBBS">Dr Aizhu Wang
Medical Specialist
MBBS</option>
	   <option value="Anaya Ch
Medical Specialist
mbbs,fcps">Anaya Ch
Medical Specialist
mbbs,fcps</option>
	  <option value="Muhammad Ali
Medical Specialist
MBBS,MRCGP UK">Muhammad Ali
Medical Specialist
MBBS,MRCGP UK</option>
	  <option value="Prof. Gulsena Masood Khan
Medical Specialist
MBBS - Medical Spe..">Prof. Gulsena Masood Khan
Medical Specialist
MBBS - Medical Spe..</option>
	  <option value="Prof. Mehmood Ali Malik
Medical Specialist
MBBS - Medical Spe..">Prof. Mehmood Ali Malik
Medical Specialist
MBBS - Medical Spe..</option>
	  <option value="Dr. Mudassar Riaz Warra..
Medical Specialist
M.B.B.S, R.M.P, G.P">Dr. Mudassar Riaz Warra..
Medical Specialist
M.B.B.S, R.M.P, G.P</option>
	   <option value="Dr Kanwar Atiq
Medical Specialist
MBBS,FCPS (U.K)">Dr Kanwar Atiq
Medical Specialist
MBBS,FCPS (U.K)</option>
	  <option value="MATERNAL FETAL MEDICINE SPECIALIST"><b>MATERNAL FETAL MEDICINE SPECIALIST</b></option>
	  <option value="Sohail Ahmad
Maternal Fetal Medicine Specialist
MBBS, FCPS">Sohail Ahmad
Maternal Fetal Medicine Specialist
MBBS, FCPS</option>
	  <option value="LAPAROSCOPIC SURGEON IN HOSPITALS "><b>LAPAROSCOPIC SURGEON IN HOSPITALS </b></option>
	  <option value="Dr. Abdul Majid
Laparoscopic Surgeon
MBBS, FRCS (UK)">Dr. Abdul Majid
Laparoscopic Surgeon
MBBS, FRCS (UK)</option>
	   <option value="Dr Asif Rehman
Laparoscopic Surgeon
MBBS, FCPS (Genera..">Dr Asif Rehman
Laparoscopic Surgeon
MBBS, FCPS (Genera..</option>
	  <option value="Dr Mazher
Laparoscopic Surgeon">Dr Mazher
Laparoscopic Surgeon</option>
	  <option value="DR. ZAFAR IQBAL GONDAL
Laparoscopic Surgeon
MBBS, MRCS, MCPS, ..">DR. ZAFAR IQBAL GONDAL
Laparoscopic Surgeon
MBBS, MRCS, MCPS, ..</option>
	  <option value="Dr. Muhammad Asadullah ..
Laparoscopic Surgeon
MBBS,FCPS,MRCP">Dr. Muhammad Asadullah ..
Laparoscopic Surgeon
MBBS,FCPS,MRCP</option>
	  <option value="Dr. Majeed Chaudhry
Laparoscopic Surgeon
MBBS - Laparoscopi..">Dr. Majeed Chaudhry
Laparoscopic Surgeon
MBBS - Laparoscopi..</option>
	  <option value="Dr. Zafar Ali Chaudhry
Laparoscopic Surgeon
MBBS - Laparoscopi..">Dr. Zafar Ali Chaudhry
Laparoscopic Surgeon
MBBS - Laparoscopi..</option>
	  <option value="Dr. Zahid Niaz
Laparoscopic Surgeon
FCPS, FRCS - Lapar..">Dr. Zahid Niaz
Laparoscopic Surgeon
FCPS, FRCS - Lapar..</option>
	  <option value="Dr. Haroon Dar
Laparoscopic Surgeon
MBBS - Laparoscopi..">Dr. Haroon Dar
Laparoscopic Surgeon
MBBS - Laparoscopi..</option>
	  <option value="Dr. Jawad Ashraf
Laparoscopic Surgeon
MBBS - Laparoscopi..">Dr. Jawad Ashraf
Laparoscopic Surgeon
MBBS - Laparoscopi..</option>
	   <option value="Dr. Sadaqat Ali Khan
Laparoscopic Surgeon
MBBS - Laparoscopi..">Dr. Sadaqat Ali Khan
Laparoscopic Surgeon
MBBS - Laparoscopi..</option>
	  <option value="Dr. Tahir Ahmad Shah
Laparoscopic Surgeon
MBBS - Laparoscopi..">Dr. Tahir Ahmad Shah
Laparoscopic Surgeon
MBBS - Laparoscopi..</option>
	  <option value="Dr. M. H. Randhawa
Laparoscopic Surgeon
MBBS - Laparoscopi..">Dr. M. H. Randhawa
Laparoscopic Surgeon
MBBS - Laparoscopi..</option>
	  <option value="Dr. Zafar Aziz Khan
Laparoscopic Surgeon
MBBS - Laparoscopi..">Dr. Zafar Aziz Khan
Laparoscopic Surgeon
MBBS - Laparoscopi..</option>
	  <option value="Dr. Zahid Akbar
Laparoscopic Surgeon
MBBS - Laparoscopi..">Dr. Zahid Akbar
Laparoscopic Surgeon
MBBS - Laparoscopi..</option>
	   <option value="Dr. Sadaqat Khan
Laparoscopic Surgeon
MBBS - Laparoscopi..">Dr. Sadaqat Khan
Laparoscopic Surgeon
MBBS - Laparoscopi..</option>
	  <option value="Dr. M. Zahid Akbar
Laparoscopic Surgeon
MBBS - Laparoscopi..">Dr. M. Zahid Akbar
Laparoscopic Surgeon
MBBS - Laparoscopi..</option>
	  <option value="Dr Ahsan Nasim
Laparoscopic Surgeon
FCPS">Dr Ahsan Nasim
Laparoscopic Surgeon
FCPS</option>
	  <option value="Dr Khalid Mahmood
Laparoscopic Surgeon
MBBS, FCPS">Dr Khalid Mahmood
Laparoscopic Surgeon
MBBS, FCPS</option>
	  <option value="INTENSIVIST IN HOSPITALS"><b>INTENSIVIST IN HOSPITALS</b></option>
	   <option value="Dr. Shahzad Iqbal
Intensivist
MD - Intensivist">Dr. Shahzad Iqbal
Intensivist
MD - Intensivist</option>
	  <option value="HOMEOPATHIC IN HOSPITALS"><b>HOMEOPATHIC IN HOSPITALS</b></option>
	  <option value="Dr. Aamir Mustafa
Homeopathic
D.H.M.S.">Dr. Aamir Mustafa
Homeopathic
D.H.M.S.</option>
	  <option value="Dr Shahzada Hamid Riaz ..
Homeopathic
DHMS /MD">Dr Shahzada Hamid Riaz ..
Homeopathic
DHMS /MD</option>
	  <option value="Salam Hamid
Homeopathic
D.H.M.S - Homeopat..">Salam Hamid
Homeopathic
D.H.M.S - Homeopat..</option>
	   <option value="Tahir Malik Awan
Homeopathic
D.H.M.S - Homeopat..">Tahir Malik Awan
Homeopathic
D.H.M.S - Homeopat..</option>
	  <option value="Dr. Mohsin Mehmood Shaikh
Homeopathic
DHMS, MD(HOM), DSC..">Dr. Mohsin Mehmood Shaikh
Homeopathic
DHMS, MD(HOM), DSC..</option>
	  <option value="Mian Muhammad Atif
Homeopathic
bsc">Mian Muhammad Atif
Homeopathic
bsc</option>
	  <option value="Dr Yasir Hamid
Homeopathic
F,Sc. DHMS, RHMP, ..">Dr Yasir Hamid
Homeopathic
F,Sc. DHMS, RHMP, ..</option>
	  <option value="Homeopathic Aftab Ranjha
Homeopathic
DHMS">Homeopathic Aftab Ranjha
Homeopathic
DHMS</option>
	   <option value="Dr Zafar Iqbal Chaudhary
Homeopathic
DHMS, SCD, RHMP,MD">Dr Zafar Iqbal Chaudhary
Homeopathic
DHMS, SCD, RHMP,MD</option>
	  <option value="Munir Hussain Sheikh
Homeopathic">Munir Hussain Sheikh
Homeopathic</option>
	  <option value="Prof Dr. Ghulam Mustafa
Homeopathic">Prof Dr. Ghulam Mustafa
Homeopathic</option>
	  <option value="HEPATOLOGIST IN HOSPITALS "><b>HEPATOLOGIST IN HOSPITALS </b></option>
	  <option value="DR. PARA BUTT
Hepatologist
FCF">DR. PARA BUTT
Hepatologist
FCF</option>
	   <option value="Prof,Dr Muhammad Shoaib..
Hepatologist
M.B.B.S,F.C.P.S,">Prof,Dr Muhammad Shoaib..
Hepatologist
M.B.B.S,F.C.P.S,</option>
	  <option value="Dr. Niaz Ahmed Qadri
Hepatologist
MBBS, MCPS, FCPS(M..">Dr. Niaz Ahmed Qadri
Hepatologist
MBBS, MCPS, FCPS(M..</option>
	  <option value="Dr. Omar Anis
Hepatologist
M.B.B.S M.C.P.S M...">Dr. Omar Anis
Hepatologist
M.B.B.S M.C.P.S M...</option>
	  <option value="Dr Prof Nasir Hassan Luck
Hepatologist
MBBS,FCPS med, FCP..">Dr Prof Nasir Hassan Luck
Hepatologist
MBBS,FCPS med, FCP..</option>
	  <option value="Dr. Syed M Raza
Hepatologist
(MBBS, FCPS,Viscer..">Dr. Syed M Raza
Hepatologist
(MBBS, FCPS,Viscer..</option>
	   <option value="HEART SPECIALIST IN HOSPITALS"><b>HEART SPECIALIST IN HOSPITALS</b></option>
	  <option value="Dr. M. Rafique Chaudhry
Heart Specialist">Dr. M. Rafique Chaudhry
Heart Specialist</option>
	  <option value="Dr. Abdul Hafeez Khan
Heart Specialist">Dr. Abdul Hafeez Khan
Heart Specialist</option>
	  <option value="Dr. Dawood Shaukat
Heart Specialist">Dr. Dawood Shaukat
Heart Specialist</option>
	  <option value="Dr. Irfan Bakhsi
Heart Specialist">Dr. Irfan Bakhsi
Heart Specialist</option>
	   <option value="Dr. Masood Ahmed
Heart Specialist">Dr. Masood Ahmed
Heart Specialist</option>
	  <option value="Dr. Shaharyar Ahmad Sha..
Heart Specialist">Dr. Shaharyar Ahmad Sha..
Heart Specialist</option>
	  <option value="Dr. Najam Hyder
Heart Specialist">Dr. Najam Hyder
Heart Specialist</option>
	  <option value="Dr. Najam Ayyub Minhas
Heart Specialist">Dr. Najam Ayyub Minhas
Heart Specialist</option>
	  <option value="Dr. M Rashid Ch
Heart Specialist">Dr. M Rashid Ch
Heart Specialist</option>
	   <option value="Dr. Ashfaque Ahmed Khan
Heart Specialist">Dr. Ashfaque Ahmed Khan
Heart Specialist</option>
	  <option value="Dr. Ismat Khalid
Heart Specialist">Dr. Ismat Khalid
Heart Specialist</option>
	  <option value="Dr. Prof. A. Hafiz Khan
Heart Specialist">Dr. Prof. A. Hafiz Khan
Heart Specialist</option>
	  <option value="Dr. A Jmal Hassan Naqvi
Heart Specialist">Dr. A Jmal Hassan Naqvi
Heart Specialist</option>
	  <option value="Dr. Farooq Taufeeq Sultan
Heart Specialist">Dr. Farooq Taufeeq Sultan
Heart Specialist</option>
	   <option value="Dr. Faiz Ur Rehman
Heart Specialist">Dr. Faiz Ur Rehman
Heart Specialist</option>
	  <option value="Dr. M Aahfaq
Heart Specialist">Dr. M Aahfaq
Heart Specialist</option>
	  <option value="Dr. M Abrar Ch
Heart Specialist">Dr. M Abrar Ch
Heart Specialist</option>
	  <option value="Dr.Haroon Babar
Heart Specialist">Dr.Haroon Babar
Heart Specialist</option>
	  <option value="Dr. Azimuddin Zahid
Heart Specialist">Dr. Azimuddin Zahid
Heart Specialist</option>
	   <option value="Dr. Tariq Mahmood Malik
Heart Specialist">Dr. Tariq Mahmood Malik
Heart Specialist</option>
	  <option value="Dr. Prof Saeed
Heart Specialist">Dr. Prof Saeed
Heart Specialist</option>
	  <option value="Dr. Afaq Ahmed
Heart Specialist">Dr. Afaq Ahmed
Heart Specialist</option>
	  <option value="Dr. Irfan Bakhashi
Heart Specialist">Dr. Irfan Bakhashi
Heart Specialist</option>
	  <option value="Dr Tahmina Sardar
Gynecologist
MBBS, FCPS (Obs & ..">Dr Tahmina Sardar
Gynecologist
MBBS, FCPS (Obs & ..</option>
	   <option value="Sara Ejaz
Gynecologist
MBBS, FCPS, Diplom..">Sara Ejaz
Gynecologist
MBBS, FCPS, Diplom..</option>
	  <option value="Nazli Hameed
Gynecologist
MBBS, FCPS, FRCOG(..">Nazli Hameed
Gynecologist
MBBS, FCPS, FRCOG(..</option>
	  <option value="Maria Imran
Gynecologist
MBBS, FCPS (Obs & ..">Maria Imran
Gynecologist
MBBS, FCPS (Obs & ..</option>
	  <option value="Rehana Amir
Gynecologist
MBBS, FCPS (Obstet..">Rehana Amir
Gynecologist
MBBS, FCPS (Obstet..</option>
	  <option value="Rabia Wajid
Gynecologist
MBBS, FCPS">Rabia Wajid
Gynecologist
MBBS, FCPS</option>
	  
	  <option value="Jamshid Feroze
Gynecologist
MBBS, FCPS (Obs & ..">Jamshid Feroze
Gynecologist
MBBS, FCPS (Obs & ..</option>
	  <option value="Humaira Zulfiqar Saifee
Gynecologist
MBBS, FCPS (Obs & ..">Humaira Zulfiqar Saifee
Gynecologist
MBBS, FCPS (Obs & ..</option>
	  <option value="Syeda Riffat Iqbal
Gynecologist
MBBS, FCPS">Syeda Riffat Iqbal
Gynecologist
MBBS, FCPS</option>
	  <option value="Uzma Hussain
Gynecologist
MBBS, FCPS, MME (G..">Uzma Hussain
Gynecologist
MBBS, FCPS, MME (G..</option>
	  <option value="Misbah Malik
Gynecologist
MBBS, MCPS, FCPS">Misbah Malik
Gynecologist
MBBS, MCPS, FCPS</option>
	  <option value="Shabnam Muhammad Ali
Gynecologist
MBBS,FCPS">Shabnam Muhammad Ali
Gynecologist
MBBS,FCPS</option>
	   <option value="Shysta Shaukat
Gynecologist
MBBS, FCPS (Gyn & ..">Shysta Shaukat
Gynecologist
MBBS, FCPS (Gyn & ..</option>
	  <option value="Saima Zaki
Gynecologist
MBBS, MCPS,FCPS (O..">Saima Zaki
Gynecologist
MBBS, MCPS,FCPS (O..</option>
	  <option value="Umtal Batool
Gynecologist
MBBS, FCPS (Obs & ..">Umtal Batool
Gynecologist
MBBS, FCPS (Obs & ..</option>
	  <option value="Nagina Bibi
Gynecologist
MBBS, MCPS, FCPS, ..">Nagina Bibi
Gynecologist
MBBS, MCPS, FCPS, ..</option>
	  <option value="Tasneem Zia
Gynecologist
MBBS, DGO">Tasneem Zia
Gynecologist
MBBS, DGO</option>
	   <option value="Dr Samina Aman Sindhu
Gynecologist
M.B.B.S, R.M.P, DG..">Dr Samina Aman Sindhu
Gynecologist
M.B.B.S, R.M.P, DG..</option>
	  <option value="Dr Mudassara Rafi
Gynecologist
MBBS, MCPS (Gyne /..">Dr Mudassara Rafi
Gynecologist
MBBS, MCPS (Gyne /..</option>
	  <option value="Dr Faiqa Saleem Baig
Gynecologist
MBBS. MCPS. MRCOG">Dr Faiqa Saleem Baig
Gynecologist
MBBS. MCPS. MRCOG</option>
	  <option value="Dr Amber Qureshi
Gynecologist
MBBS. MCPS">Dr Amber Qureshi
Gynecologist
MBBS. MCPS</option>
	  <option value="Prof. Alia Bashir
Gynecologist
MBBS; DGO; MCPS; F..">Prof. Alia Bashir
Gynecologist
MBBS; DGO; MCPS; F..</option>
	   <option value="Dr. Arshad Chohan
Gynecologist
MBBS, FCPS, MRCOG,..">Dr. Arshad Chohan
Gynecologist
MBBS, FCPS, MRCOG,..</option>
	  <option value="Dr. Balqees Fatima
Gynecologist
MBBS, FCPS, FRCOG ..">Dr. Balqees Fatima
Gynecologist
MBBS, FCPS, FRCOG ..</option>
	  <option value="Dr. Bushra Shahida
Gynecologist
MBBS, DGO - Gyneco..">Dr. Bushra Shahida
Gynecologist
MBBS, DGO - Gyneco..</option>
	  <option value="Dr. Fakhara Mehmood
Gynecologist
MBBS, DGO - Gyneco..">Dr. Fakhara Mehmood
Gynecologist
MBBS, DGO - Gyneco..</option>
	  <option value="Dr. Fozia Munnoo Khan
Gynecologist
MBBS, MRCOG. - Gyn..">Dr. Fozia Munnoo Khan
Gynecologist
MBBS, MRCOG. - Gyn..</option>
	   <option value="Dr. Hajira Hanif
Gynecologist
MBBS, FRCOG - Gyne..">Dr. Hajira Hanif
Gynecologist
MBBS, FRCOG - Gyne..</option>
	  <option value="Dr. Iffat Saleem
Gynecologist
MBBS, MRCOG, DRCOG..">Dr. Iffat Saleem
Gynecologist
MBBS, MRCOG, DRCOG..</option>
	  <option value="Dr. Iqbal Rasheed Mian
Gynecologist
MBBS, FRCOG - Gyne..">Dr. Iqbal Rasheed Mian
Gynecologist
MBBS, FRCOG - Gyne..</option>
	  <option value="Dr. Munawar Zaheen
Gynecologist
MBBS, MRCOG, FRCOG..">Dr. Munawar Zaheen
Gynecologist
MBBS, MRCOG, FRCOG..</option>
	  <option value="Dr. N. A. Seyal
Gynecologist
MBBS, FRCS, FRCOG...">Dr. N. A. Seyal
Gynecologist
MBBS, FRCS, FRCOG...</option>
	   <option value="Dr. Naheed Akhtar
Gynecologist
MBBS, MRCOG. - Gyn..">Dr. Naheed Akhtar
Gynecologist
MBBS, MRCOG. - Gyn..</option>
	  <option value="Dr. Naseem Niaz
Gynecologist
MBBS, MRCOG. - Gyn..">Dr. Naseem Niaz
Gynecologist
MBBS, MRCOG. - Gyn..</option>
	  <option value="Mahham Janjua
Gynecologist
MBBS, FCPS (Obstet..">Mahham Janjua
Gynecologist
MBBS, FCPS (Obstet..</option>
	  <option value="Dr. Farhat Rashid
Gynecologist
MBBS, FCPS (Obs & ..">Dr. Farhat Rashid
Gynecologist
MBBS, FCPS (Obs & ..</option>
	  <option value="GENERAL SURGEON IN HOSPITALS"><b>GENERAL SURGEON IN HOSPITALS</b></option>
	   <option value="Dr. Afsar Ali Bhatti
General Surgeon
M.B.B.S, F.C.P.S.(..">Dr. Afsar Ali Bhatti
General Surgeon
M.B.B.S, F.C.P.S.(..</option>
	  <option value="Dr. Mahmood Mazhar
General Surgeon
MBBS(KE), FRCS(Ed)">Dr. Mahmood Mazhar
General Surgeon
MBBS(KE), FRCS(Ed)</option>
	  <option value="Muhammad Nasir
General Surgeon
MBBS, FCPS">Muhammad Nasir
General Surgeon
MBBS, FCPS</option>
	  <option value="Aamir Jameel
General Surgeon
MBBS, FCPS">Aamir Jameel
General Surgeon
MBBS, FCPS</option>
	  <option value="Hassan Shaukat
General Surgeon
MBBS, FCPS (Surgery)">Hassan Shaukat
General Surgeon
MBBS, FCPS (Surgery)</option>
	   <option value="Sadaqat Ali Khan
General Surgeon
MBBS, MCPS(Gen sur..">Sadaqat Ali Khan
General Surgeon
MBBS, MCPS(Gen sur..</option>
	  <option value="Andleeb Khanam
General Surgeon
MBBS, FCPS (Surgery">Andleeb Khanam
General Surgeon
MBBS, FCPS (Surgery</option>
	  <option value="Shahzad Alam Shah
General Surgeon
MBBS,FCPS">Shahzad Alam Shah
General Surgeon
MBBS,FCPS</option>
	  <option value="Prof Mohsin Gillani
General Surgeon
MBBS,FCPS, Fellows..">Prof Mohsin Gillani
General Surgeon
MBBS,FCPS, Fellows..</option>
	  <option value="Rizwan Khalid
General Surgeon
MBBS, FCPS ( Surge..">Rizwan Khalid
General Surgeon
MBBS, FCPS ( Surge..</option>
	   <option value="Zahid Mahmood
General Surgeon
MBBS, FCPS">Zahid Mahmood
General Surgeon
MBBS, FCPS</option>
	  <option value="Maaz Ul Hassan
General Surgeon
MBBS, FCPS, FLS, B..">Maaz Ul Hassan
General Surgeon
MBBS, FCPS, FLS, B..</option>
	  <option value="Dr.S.Umer Khan
General Surgeon
M.B.B.S,F.C.P.S">Dr.S.Umer Khan
General Surgeon
M.B.B.S,F.C.P.S</option>
	  <option value="Dr Ambreen Khalid Rana
General Surgeon
MBBS">Dr Ambreen Khalid Rana
General Surgeon
MBBS</option>
	  <option value="Sadaf Ishaque
General Surgeon
MBBS,FCPS">Sadaf Ishaque
General Surgeon
MBBS,FCPS</option>
	   <option value="Prof Zahid Mahmood
General Surgeon
MBBS. FCPS">Prof Zahid Mahmood
General Surgeon
MBBS. FCPS</option>
	  <option value="Dr Ch Mohammad Kamran
General Surgeon
MBBS FCPS">Dr Ch Mohammad Kamran
General Surgeon
MBBS FCPS</option>
	  <option value="Dr. Mohammed Farooq Afzal
General Surgeon
MBBS, FCPS">Dr. Mohammed Farooq Afzal
General Surgeon
MBBS, FCPS</option>
	  <option value="Dr Kamran Ali
General Surgeon
MBBS, FCPS">Dr Kamran Ali
General Surgeon
MBBS, FCPS</option>
	  <option value="Dr. Riaz Ahmed Warraich
General Surgeon
MBBS, MDS, MCPS, F..">Dr. Riaz Ahmed Warraich
General Surgeon
MBBS, MDS, MCPS, F..</option>
	   <option value="Dr. Haroon Dar
General Surgeon
MBBS, FCPS - Gener..">Dr. Haroon Dar
General Surgeon
MBBS, FCPS - Gener..</option>
	  <option value="Dr. Jawad Ashraf
General Surgeon
MBBS, FRCS - Gener..">Dr. Jawad Ashraf
General Surgeon
MBBS, FRCS - Gener..</option>
	  <option value="Dr. Rashid Saeed
General Surgeon
MBBS, FCPS, FRCS -..">Dr. Rashid Saeed
General Surgeon
MBBS, FCPS, FRCS -..</option>
	  <option value="Dr. Moeed Iqbal Qureshi
General Surgeon
MBBS, FCPS, FRCS -..">Dr. Moeed Iqbal Qureshi
General Surgeon
MBBS, FCPS, FRCS -..</option>
	  <option value="Dr. Tahir Mehboob Bajwa
General Surgeon
MBBS, FCPS - Gener..">Dr. Tahir Mehboob Bajwa
General Surgeon
MBBS, FCPS - Gener..</option>
	   <option value="Dr. Ashraf Khan Niazi
General Surgeon
MBBS, FRCS - Gener..">Dr. Ashraf Khan Niazi
General Surgeon
MBBS, FRCS - Gener..</option>
	  <option value="Dr. Sajjida Javed
General Surgeon
MBBS, FCPS - Gener..">Dr. Sajjida Javed
General Surgeon
MBBS, FCPS - Gener..</option>
	  <option value="Dr. Khalida Usmani
General Surgeon
MBBS, MD, , FRCS -..">Dr. Khalida Usmani
General Surgeon
MBBS, MD, , FRCS -..</option>
	  <option value="Dr. Salman Zahid
General Surgeon
MBBS, FRCS - Gener..">Dr. Salman Zahid
General Surgeon
MBBS, FRCS - Gener..</option>
	  <option value="Dr. Javaid Iqbal Malik
General Surgeon
MBBS, FCPS, - Gene..">Dr. Javaid Iqbal Malik
General Surgeon
MBBS, FCPS, - Gene..</option>
	   <option value="Shahzad Naveed Jawaid
General Surgeon
MBBS, MS (General ..">Shahzad Naveed Jawaid
General Surgeon
MBBS, MS (General ..</option>
	  <option value="Amna Umar Gill
General Surgeon
MBBS, MRCS, FCPS (..">Amna Umar Gill
General Surgeon
MBBS, MRCS, FCPS (..</option>
	  <option value="Kamran Ali
General Surgeon
MBBS, FCPS">Kamran Ali
General Surgeon
MBBS, FCPS</option>
	  <option value="Zafar Iqbal Gondal
General Surgeon
MBBS, MRCS, MCPS, ..">Zafar Iqbal Gondal
General Surgeon
MBBS, MRCS, MCPS, ..</option>
	  <option value="Dr Ahmad Uzair Qureshi
General Surgeon
MBBS, MCPS, MRCS, ..">Dr Ahmad Uzair Qureshi
General Surgeon
MBBS, MCPS, MRCS, ..</option>
	   <option value="Dr Syed Imran Hussain A..
General Surgeon
MBBS,FCPS (Pak),FR..">Dr Syed Imran Hussain A..
General Surgeon
MBBS,FCPS (Pak),FR..</option>
	  <option value="GASTROENTEROLOGIST IN HOSPITALS"><b>GASTROENTEROLOGIST IN HOSPITALS</b></option>
	  <option value="Waqas Shabbir
Gastroenterologist
MBBS, FCPS (Gastro..">Waqas Shabbir
Gastroenterologist
MBBS, FCPS (Gastro..</option>
	  <option value="Muhammad Awais Abid
Gastroenterologist
MBBS, FCPS (Medici..">Muhammad Awais Abid
Gastroenterologist
MBBS, FCPS (Medici..</option>
	  <option value="Muhammad Bilal Nasir
Gastroenterologist
MBBS, FCPS( Medici..">Muhammad Bilal Nasir
Gastroenterologist
MBBS, FCPS( Medici..</option>
	  <option value="Zafar Iqbal Chaudhary
Gastroenterologist
MBBS, FCPS">Zafar Iqbal Chaudhary
Gastroenterologist
MBBS, FCPS</option>
	  <option value="Asif Mehmood
Gastroenterologist
MBBS, FCPS, MCPS, ..">Asif Mehmood
Gastroenterologist
MBBS, FCPS, MCPS, ..</option>
	  <option value="Mehreen Zaman Niazi
Gastroenterologist
MBBS, FCPS">Mehreen Zaman Niazi
Gastroenterologist
MBBS, FCPS</option>
	  <option value="Imran Khan Farooka
Gastroenterologist
MBBS, FCPS (Medici..">Imran Khan Farooka
Gastroenterologist
MBBS, FCPS (Medici..</option>
	  <option value="Muhammad Adeel Qamar
Gastroenterologist
MBBS(KE), MD(USA),..">Muhammad Adeel Qamar
Gastroenterologist
MBBS(KE), MD(USA),..</option>
	   <option value="Zahid Hussain Shah
Gastroenterologist
MBBS, FCPS, MD (Ga..">Zahid Hussain Shah
Gastroenterologist
MBBS, FCPS, MD (Ga..</option>
	  <option value="Hassan Suleman Malik
Gastroenterologist
MBBS, FCPS(PEDIATR..">Hassan Suleman Malik
Gastroenterologist
MBBS, FCPS(PEDIATR..</option>
	  <option value="Fahad Aman Khan
Gastroenterologist
MBBS,FCPS">Fahad Aman Khan
Gastroenterologist
MBBS,FCPS</option>
	  <option value="Salman Javed
Gastroenterologist
MBBS (Pb), MD (USA..">Salman Javed
Gastroenterologist
MBBS (Pb), MD (USA..</option>
	  <option value="Amtiaz Ahmad
Gastroenterologist
MBBS, MRCP, FCPS (.">Amtiaz Ahmad
Gastroenterologist
MBBS, MRCP, FCPS (.</option>
	   <option value="Ahmad Farooq
Gastroenterologist
MBBS, FCPS, MRCP">Ahmad Farooq
Gastroenterologist
MBBS, FCPS, MRCP</option>
	  <option value="Attique Abou Bakr
Gastroenterologist
MBBS, FCPS, MRCP (..">Attique Abou Bakr
Gastroenterologist
MBBS, FCPS, MRCP (..</option>
	  <option value="Mahmood Ahmad Cheema
Gastroenterologist
MBBS, FCPS (Gastro..">Mahmood Ahmad Cheema
Gastroenterologist
MBBS, FCPS (Gastro..</option>
	  <option value="Dr. Mian Sajid Nisar
Gastroenterologist
MBBS, MRCP - Gasro.">Dr. Mian Sajid Nisar
Gastroenterologist
MBBS, MRCP - Gasro.</option>
	  <option value="Dr Mujtaba Jaffary
Gastroenterologist
MBBS.MRCP(UK).">Dr Mujtaba Jaffary
Gastroenterologist
MBBS.MRCP(UK).</option>
	   <option value="Dr. Khalid Mahmud Khan
Gastroenterologist
MRCP, FCPS">Dr. Khalid Mahmud Khan
Gastroenterologist
MRCP, FCPS</option>
	  <option value="Dr Moeez Kaiser Butt
Gastroenterologist
M.B.B.S FCPS">Dr Moeez Kaiser Butt
Gastroenterologist
M.B.B.S FCPS</option>
	  <option value="Dr Hareem Shahzad Khan
Gastroenterologist
MBBS, MD">Dr Hareem Shahzad Khan
Gastroenterologist
MBBS, MD</option>
	  <option value="Dr. Nusrat Ullah Ch.
Gastroenterologist">Dr. Nusrat Ullah Ch.
Gastroenterologist</option>
	  <option value="Dr. Arif Mahmood Siddiqui
Gastroenterologist">Dr. Arif Mahmood Siddiqui
Gastroenterologist</option>
	   <option value="Dr. S. Asif Raza Shah
Gastroenterologist
MBBS, MCPS(Medicin..">Dr. S. Asif Raza Shah
Gastroenterologist
MBBS, MCPS(Medicin..</option>
	  <option value="Dr. Adeel Qamar
Gastroenterologist
MBBS (K,E), MD (US..">Dr. Adeel Qamar
Gastroenterologist
MBBS (K,E), MD (US..</option>
	  <option value="Dr. Aftab Haider Alvi
Gastroenterologist
M.B.B.S. FCPS medi..">Dr. Aftab Haider Alvi
Gastroenterologist
M.B.B.S. FCPS medi..</option>
	  <option value="Dr.Shahzad Latif
Gastroenterologist
MBBS..MD Gastroent..">Dr.Shahzad Latif
Gastroenterologist
MBBS..MD Gastroent..</option>
	  <option value="Dr Attiya Taeed
Gastroenterologist">Dr Attiya Taeed
Gastroenterologist</option>
	   <option value="Dr. Anwar A. Khan
Gastroenterologist
MD, FACP, FACG, DA..">Dr. Anwar A. Khan
Gastroenterologist
MD, FACP, FACG, DA..</option>
	  <option value="Dr. Zaheer Babar
Gastroenterologist
MD, FACP, FACG, DA..">Dr. Zaheer Babar
Gastroenterologist
MD, FACP, FACG, DA..</option>
	  <option value="Dr. Hamad Raza
Gastroenterologist
MBBS, MD - Gasro-E..">Dr. Hamad Raza
Gastroenterologist
MBBS, MD - Gasro-E..</option>
	  <option value="Dr. Javed Aslam Bhinder
Gastroenterologist
MBBS - Gasro-Enter..">Dr. Javed Aslam Bhinder
Gastroenterologist
MBBS - Gasro-Enter..</option>
	  <option value="Dr. Shahid Raza Khan
Gastroenterologist
MBBS - Gasro-Enter..">Dr. Shahid Raza Khan
Gastroenterologist
MBBS - Gasro-Enter..</option>
	   <option value="Dr. M. Joher Amin Khan
Gastroenterologist
MBBS, FCPS (Gastro..">Dr. M. Joher Amin Khan
Gastroenterologist
MBBS, FCPS (Gastro..</option>
	  <option value="Dr. Altaf Alam
Gastroenterologist
MBBS,MRCP">Dr. Altaf Alam
Gastroenterologist
MBBS,MRCP</option>
	  <option value="Mujahid Israr
Gastroenterologist
MBBS, FCPS (Gastro..">Mujahid Israr
Gastroenterologist
MBBS, FCPS (Gastro..</option>
	  <option value="FAMILY PHYSICIAN IN HOSPITALS"><b>FAMILY PHYSICIAN IN HOSPITALS</b></option>
	  <option value=""></option>
	   <option value=""></option>
	  <option value="Dr. Najam Ul Sehr Butt
Family Physician">Dr. Najam Ul Sehr Butt
Family Physician</option>
	  <option value="Dr. Ali Mohammad Mir Col
Family Physician">Dr. Ali Mohammad Mir Col
Family Physician</option>
	  <option value="Dr. Naseem Ahmed Qureshi
Family Physician">Dr. Naseem Ahmed Qureshi
Family Physician</option>
	  <option value="Dr. Nasir Manzoor
Family Physician">Dr. Nasir Manzoor
Family Physician</option>
	   <option value="Dr. Abdus Sattar Chaudhry
Family Physician">Dr. Abdus Sattar Chaudhry
Family Physician</option>
	  <option value="Dr. Kashif Hafeez
Family Physician">Dr. Kashif Hafeez
Family Physician</option>
	  <option value="Dr. Shahid Ikram
Family Physician">Dr. Shahid Ikram
Family Physician</option>
	  <option value="Dr. Javed Khalil
Family Physician">Dr. Javed Khalil
Family Physician</option>
	  <option value="Dr. Talat Naheed
Family Physician">Dr. Talat Naheed
Family Physician</option>
	   <option value="Dr. Shaheen M. Mufti
Family Physician">Dr. Shaheen M. Mufti
Family Physician</option>
	  <option value="Dr. M. Shafiq
Family Physician">Dr. M. Shafiq
Family Physician</option>
	  <option value="Dr. Sadaqat Ali
Family Physician">Dr. Sadaqat Ali
Family Physician</option>
	  <option value="Dr. Imtiaz Hassan
Family Physician">Dr. Imtiaz Hassan
Family Physician</option>
	  <option value="Dr. Mohammad Rashid Khan
Family Physician">Dr. Mohammad Rashid Khan
Family Physician</option>
	   <option value="Shagufta Feroz Ata-Ul -..
Family Physician">Shagufta Feroz Ata-Ul -..
Family Physician</option>
	  <option value="Dr. M Tariq Azeez
Family Physician">Dr. M Tariq Azeez
Family Physician</option>
	  <option value="Dr. Muhammad Amjad Chau..
Family Physician">Dr. Muhammad Amjad Chau..
Family Physician</option>
	  <option value="Dr. Tauseef Riiaz
Family Physician">Dr. Tauseef Riiaz
Family Physician</option>
	  <option value="Dr. Hamayon Farooq
Family Physician">Dr. Hamayon Farooq
Family Physician</option>
	   <option value="Dr. Humayon Farooq
Family Physician">Dr. Humayon Farooq
Family Physician</option>
	  <option value="Dr. Mohammad Tahir Azam
Family Physician">Dr. Mohammad Tahir Azam
Family Physician</option>
	  <option value="Dr. Capt. Amjed Hussain
Family Physician
">Dr. Capt. Amjed Hussain
Family Physician
</option>
	  <option value="Dr. Muhammad Ibrahim
Family Physician">Dr. Muhammad Ibrahim
Family Physician</option>
	  <option value="Dr. Muhammad Akbar Chau..
Family Physician">Dr. Muhammad Akbar Chau..
Family Physician</option>
	   <option value="Dr. Munawar Ahmad
Family Physician">Dr. Munawar Ahmad
Family Physician</option>
	  <option value="Dr. Ahmad Ijaz Shah
Family Physician">Dr. Ahmad Ijaz Shah
Family Physician</option>
	  <option value="Dr. M. Shahbaz Najam Sh..
Family Physician">Dr. M. Shahbaz Najam Sh..
Family Physician</option>
	  <option value="Dr. Kamran K. Chima
Family Physician">Dr. Kamran K. Chima
Family Physician</option>
	  <option value="Dr. Farooq Rasool
Family Physician">Dr. Farooq Rasool
Family Physician</option>
	   <option value="Dr. Aamer Ghafoor Mufti
Family Physician">Dr. Aamer Ghafoor Mufti
Family Physician</option>
	  <option value="Dr. Nasir Mehmood Malik
Family Physician">Dr. Nasir Mehmood Malik
Family Physician</option>
	  <option value="Dr. Khawaja Sadiq Hussain
Family Physician">Dr. Khawaja Sadiq Hussain
Family Physician</option>
	  <option value="Dr. Abdul Rauf
Family Physician">Dr. Abdul Rauf
Family Physician</option>
	  <option value="Dr. Idris Ahmad Bhatti
Family Physician">Dr. Idris Ahmad Bhatti
Family Physician</option>
	  <option value="Dr. Qamar Mahmood
Family Physician">Dr. Qamar Mahmood
Family Physician</option>
	  <option value="Dr. Fakhar Abbass
Family Physician">Dr. Fakhar Abbass
Family Physician</option>
	  <option value="EYE SPECIALIST IN HOSPITALS"><b>EYE SPECIALIST IN HOSPITALS</b></option>
	  <option value="Dr. Usman Imtiaz
Eye Specialist
MBBS, FCPS, MRCS (..">Dr. Usman Imtiaz
Eye Specialist
MBBS, FCPS, MRCS (..</option>
	  <option value="Farukh Jameel
Eye Specialist
MBBS,FCPS">Farukh Jameel
Eye Specialist
MBBS,FCPS</option>
	   <option value="Dr KHAWAJA KHALID SHOAIB
Eye Specialist
FCPS, FRCS">Dr KHAWAJA KHALID SHOAIB
Eye Specialist
FCPS, FRCS</option>
	  <option value="Dr.Muhammad Akram
Eye Specialist
M.B.B.S,D.O.M.S,M...">Dr.Muhammad Akram
Eye Specialist
M.B.B.S,D.O.M.S,M...</option>
	  <option value="Dr. Ishrat Ali
Eye Specialist
MBBS - Eye Special..">Dr. Ishrat Ali
Eye Specialist
MBBS - Eye Special..</option>
	  <option value="Dr Shamim Ahmed Abbasi
Eye Specialist
MBBS - Eye Special..">Dr Shamim Ahmed Abbasi
Eye Specialist
MBBS - Eye Special..</option>
	  <option value="Dr. Asim Iqbal Khan
Eye Specialist
MBBS - Eye Special..">Dr. Asim Iqbal Khan
Eye Specialist
MBBS - Eye Special..</option>
	   <option value="Dr. Mehmood Ul Hassan J..
Eye Specialist
MBBS - Eye Special..">Dr. Mehmood Ul Hassan J..
Eye Specialist
MBBS - Eye Special..</option>
	  <option value="Dr. Badar - Uz - Zaman
Eye Specialist
MBBS - Eye Special..">Dr. Badar - Uz - Zaman
Eye Specialist
MBBS - Eye Special..</option>
	  <option value="Dr. Muhammad Arshad Mah..
Eye Specialist
MBBS - FCPS Eye Sp..">Dr. Muhammad Arshad Mah..
Eye Specialist
MBBS - FCPS Eye Sp..</option>
	  <option value="Prof Dr. Samina Jehangir
Eye Specialist
MBBS (gold med)- F..">Prof Dr. Samina Jehangir
Eye Specialist
MBBS (gold med)- F..</option>
	  <option value="Dr. Muhammad Zubair
Eye Specialist
MBBS - Eye Special..">Dr. Muhammad Zubair
Eye Specialist
MBBS - Eye Special..</option>
	   <option value="Dr. Maqbool Ashraf
Eye Specialist
MBBS - Eye Special..">Dr. Maqbool Ashraf
Eye Specialist
MBBS - Eye Special..</option>
	  <option value="Dr. Abul Hamid Awan
Eye Specialist
MBBS - Eye Special..">Dr. Abul Hamid Awan
Eye Specialist
MBBS - Eye Special..</option>
	  <option value="Dr. Saqib Sadiq
Eye Specialist
MBBS - Eye Special..">Dr. Saqib Sadiq
Eye Specialist
MBBS - Eye Special..</option>
	  <option value="Dr. Muhammad Ramzan
Eye Specialist">Dr. Muhammad Ramzan
Eye Specialist</option>
	  <option value="Dr. Syed Ali Haider
Eye Specialist">Dr. Syed Ali Haider
Eye Specialist</option>
	   <option value="Dr. Muhammad Munir Khokar
Eye Specialist">Dr. Muhammad Munir Khokar
Eye Specialist</option>
	  <option value="Dr. Asif Mehmood
Eye Specialist">Dr. Asif Mehmood
Eye Specialist</option>
	  <option value="Dr. A. Khawaja
Eye Specialist
">Dr. A. Khawaja
Eye Specialist
</option>
	  <option value="Dr. Nadeem Hafeez Butt
Eye Specialist">Dr. Nadeem Hafeez Butt
Eye Specialist</option>
	  <option value="Dr. Muhammad Tariq Khan
Eye Specialist
MBBS, FCPS RETINA ..">Dr. Muhammad Tariq Khan
Eye Specialist
MBBS, FCPS RETINA ..</option>
	   <option value="Dr. Zaheer - Ud - Din A..
Eye Specialist">Dr. Zaheer - Ud - Din A..
Eye Specialist</option>
	  <option value="Dr. Irshad Ul Haq
Eye Specialist">Dr. Irshad Ul Haq
Eye Specialist</option>
	  <option value="Dr. Muhammad Aslam Noon
Eye Specialist">Dr. Muhammad Aslam Noon
Eye Specialist</option>
	  <option value="Dr. Amanh Tahir Noori
Eye Specialist">Dr. Amanh Tahir Noori
Eye Specialist</option>
	  <option value="Dr. Syed Raza Ali Shah
Eye Specialist">Dr. Syed Raza Ali Shah
Eye Specialist</option>
	   <option value="Dr. Faiz Rasool Ch
Eye Specialist">Dr. Faiz Rasool Ch
Eye Specialist</option>
	  <option value="Dr. FARHAN JAVEED
Eye Specialist
MBBS. FCPS, FRCS">Dr. FARHAN JAVEED
Eye Specialist
MBBS. FCPS, FRCS</option>
	  <option value="Prof. Mohammad Arshad M..
Eye Specialist
FCPS. DOMS">Prof. Mohammad Arshad M..
Eye Specialist
FCPS. DOMS</option>
	  <option value="Muhammad Naeem Awan
Eye Specialist
MBBS , FCPS , FRCS..">Muhammad Naeem Awan
Eye Specialist
MBBS , FCPS , FRCS..</option>
	  <option value="Muhammad Sohail Shehzad
Eye Specialist
fCpS, MCPS, FICO, ..">Muhammad Sohail Shehzad
Eye Specialist
fCpS, MCPS, FICO, ..</option>
	   <option value="Dr. Waqar Ahmad
Eye Specialist
M.B.B.S FCPS Resid..">Dr. Waqar Ahmad
Eye Specialist
M.B.B.S FCPS Resid..</option>
	  <option value="Brigadier(r) Abdul Rafe
Eye Specialist
MBBS, DO, MCPS, FC..">Brigadier(r) Abdul Rafe
Eye Specialist
MBBS, DO, MCPS, FC..</option>
	  <option value="Shaukat Yusuf Khan
Eye Specialist
MBBS - Eye Special..">Shaukat Yusuf Khan
Eye Specialist
MBBS - Eye Special..</option>
	  <option value="Dr. Nazir Ahmed Aasi
Eye Specialist
MBBS - Eye Special..">Dr. Nazir Ahmed Aasi
Eye Specialist
MBBS - Eye Special..</option>
	  <option value="ENT SPECIALIST IN HOSPITALS"><b>ENT SPECIALIST IN HOSPITALS</b></option>
	   <option value="Dr. Sami Mumtaz
ENT Specialist
MBBS, FRCS (ENT) UK">Dr. Sami Mumtaz
ENT Specialist
MBBS, FRCS (ENT) UK</option>
	  <option value="Babar Hussain Khan
ENT Specialist
MBBS,FCPS,MCPS">Babar Hussain Khan
ENT Specialist
MBBS,FCPS,MCPS</option>
	  <option value="Prof. Brig Zubair Ahmed
ENT Specialist
MBBS,FCPS,FICS">Prof. Brig Zubair Ahmed
ENT Specialist
MBBS,FCPS,FICS</option>
	  <option value="BRIG (R) Z M RAAHAT
ENT Specialist
MBBS DLO(AFPGMI)FCPS">BRIG (R) Z M RAAHAT
ENT Specialist
MBBS DLO(AFPGMI)FCPS</option>
	  <option value="Dr. Khursheed Anwar Mian
ENT Specialist
MBBS, DLO, FICS. -..">Dr. Khursheed Anwar Mian
ENT Specialist
MBBS, DLO, FICS. -..</option>
	   <option value="Dr. M. Naeem
ENT Specialist
MBBS, DLO - ENT Sp..">Dr. M. Naeem
ENT Specialist
MBBS, DLO - ENT Sp..</option>
	  <option value="Professor.Dr. Khalid Ch..
ENT Specialist
MBBS, DLO, FCPS - ..">Professor.Dr. Khalid Ch..
ENT Specialist
MBBS, DLO, FCPS - ..</option>
	  <option value="Dr. Sayyad Ahmas Shakeel
ENT Specialist
MBBS, MCPS, M.S. -..">Dr. Sayyad Ahmas Shakeel
ENT Specialist
MBBS, MCPS, M.S. -..</option>
	  <option value="Dr. Muhammad Ameer
ENT Specialist
MBBS, FRCS., DLO -..">Dr. Muhammad Ameer
ENT Specialist
MBBS, FRCS., DLO -..</option>
	  <option value="Dr. Khalid Mehmood
ENT Specialist
MBBS, MCPS - ENT S..">Dr. Khalid Mehmood
ENT Specialist
MBBS, MCPS - ENT S..</option>
	   <option value="Dr. Mohammad Mujeeb
ENT Specialist
MBBS, FRCS, FCPS -..">Dr. Mohammad Mujeeb
ENT Specialist
MBBS, FRCS, FCPS -..</option>
	  <option value="Dr. Naveed Aslam
ENT Specialist
MBBS, FRCS - ENT S..">Dr. Naveed Aslam
ENT Specialist
MBBS, FRCS - ENT S..</option>
	  <option value="Dr. Muhammad Saleem
ENT Specialist
MBBS, DLO, MCPS, F..">Dr. Muhammad Saleem
ENT Specialist
MBBS, DLO, MCPS, F..</option>
	  <option value="Dr. Mian Mohammad Naeem
ENT Specialist
MBBS, FCPS, - ENT ..">Dr. Mian Mohammad Naeem
ENT Specialist
MBBS, FCPS, - ENT ..</option>
	  <option value="Dr. Muhammad Tariq
ENT Specialist
FRCS, DLO - ENT Sp..">Dr. Muhammad Tariq
ENT Specialist
FRCS, DLO - ENT Sp..</option>
	   <option value="Dr. Javed Iqbal
ENT Specialist
MBBS, FCPS, DLO - ..">Dr. Javed Iqbal
ENT Specialist
MBBS, FCPS, DLO - ..</option>
	  <option value="Dr. Ihsan Ali
ENT Specialist
MBBS, FCPS - ENT S..">Dr. Ihsan Ali
ENT Specialist
MBBS, FCPS - ENT S..</option>
	  <option value="Dr. Shahid Imran
ENT Specialist
MBBS, FCPS - ENT S..">Dr. Shahid Imran
ENT Specialist
MBBS, FCPS - ENT S..</option>
	  <option value="Dr. M. B. Pal
ENT Specialist
MBBS, FRCS. - ENT ..">Dr. M. B. Pal
ENT Specialist
MBBS, FRCS. - ENT ..</option>
	  <option value="Dr. Brig.Amanullah Khan
ENT Specialist
MBBS - ENT Special..">Dr. Brig.Amanullah Khan
ENT Specialist
MBBS - ENT Special..</option>
	   <option value="Dr Moazzam Ali
ENT Specialist
MBBS">Dr Moazzam Ali
ENT Specialist
MBBS</option>
	  <option value="Dr Bakht Aziz
ENT Specialist
MBBS, FCPS (ENT), ..">Dr Bakht Aziz
ENT Specialist
MBBS, FCPS (ENT), ..</option>
	  <option value="Prof Dr. Manzoor Ahmad
ENT Specialist
FCPS">Prof Dr. Manzoor Ahmad
ENT Specialist
FCPS</option>
	  <option value="Dr. Nauman Bashir
ENT Specialist
MBBS, FCPS">Dr. Nauman Bashir
ENT Specialist
MBBS, FCPS</option>
	  <option value="Dr. Naseem Abbas
ENT Specialist
MBBS, FCPS - ENT S..">Dr. Naseem Abbas
ENT Specialist
MBBS, FCPS - ENT S..</option>
	   <option value="Dr. Khalid Shafqat Cheema
ENT Specialist
B.Sc, MBBS, DLO, F..">Dr. Khalid Shafqat Cheema
ENT Specialist
B.Sc, MBBS, DLO, F..</option>
	  <option value="Dr. Farrukh Mehmood
ENT Specialist
FCPS.FACS(USA) - E..">Dr. Farrukh Mehmood
ENT Specialist
FCPS.FACS(USA) - E..</option>
	  <option value="Dr. Kashif Iqbal Malik
ENT Specialist
MBBS, MCPS, FCPS -..">Dr. Kashif Iqbal Malik
ENT Specialist
MBBS, MCPS, FCPS -..</option>
	  <option value="Dr. Asad Ullah Lone
ENT Specialist
MBBS, MS, FCPS, DL..">Dr. Asad Ullah Lone
ENT Specialist
MBBS, MS, FCPS, DL..</option>
	  <option value="Dr. Muhammad Yasoob Ali
ENT Specialist
MBBS - ENT Special..">Dr. Muhammad Yasoob Ali
ENT Specialist
MBBS - ENT Special..</option>
	  <option value="Dr. Najam Ul Hasnain
ENT Specialist
MBBS, FCPS - ENT S..">Dr. Najam Ul Hasnain
ENT Specialist
MBBS, FCPS - ENT S..</option>
	  <option value="Dr. Jawaid N. Butt
ENT Specialist
MBBS, DLO, FICS - ..">Dr. Jawaid N. Butt
ENT Specialist
MBBS, DLO, FICS - ..</option>
	  <option value="Dr. M. Iqbal Butt
ENT Specialist
FRCS (Canada) - EN..">Dr. M. Iqbal Butt
ENT Specialist
FRCS (Canada) - EN..</option>
	  <option value="Prof. Muhammad Iqbal Butt
ENT Specialist
MBBS - ENT Special..">Prof. Muhammad Iqbal Butt
ENT Specialist
MBBS - ENT Special..</option>
	  <option value="Dr. Ahmad Shakeel Rizvi
ENT Specialist
MBBS, M.S. - ENT S..">Dr. Ahmad Shakeel Rizvi
ENT Specialist
MBBS, M.S. - ENT S..</option>
	   <option value="Dr. M. Latif Malik
ENT Specialist
MBBS, MS, FCPS, DL..">Dr. M. Latif Malik
ENT Specialist
MBBS, MS, FCPS, DL..</option>
	  <option value="DIETITIAN IN HOSPITALS "><b>DIETITIAN IN HOSPITALS </b></option>
	  <option value="Sana Qamar
Dietitian
BS (hons), PGD in ..">Sana Qamar
Dietitian
BS (hons), PGD in ..</option>
	  <option value="Rizwan Ahmed
Dietitian
Bachelor ( Arts&Sc..">Rizwan Ahmed
Dietitian
Bachelor ( Arts&Sc..</option>
	  <option value="Dr Irfan Suleheria
Dietitian
B.Sc, B.Pharm, Pha..">Dr Irfan Suleheria
Dietitian
B.Sc, B.Pharm, Pha..</option>
	   <option value="Nimra Mahmood
Dietitian
BS (hons) Food and..">Nimra Mahmood
Dietitian
BS (hons) Food and..</option>
	  <option value="Shehla Javed
Dietitian
MBBS, DTM, H(UK), ..">Shehla Javed
Dietitian
MBBS, DTM, H(UK), ..</option>
	  <option value="Qurat-ul-ain Aleem
Dietitian
M.Phil (Public Hea..">Qurat-ul-ain Aleem
Dietitian
M.Phil (Public Hea..</option>
	  <option value="Yumna Chattha
Dietitian
BS. (Hons.) Food, ">Yumna Chattha
Dietitian
BS. (Hons.) Food, </option>
	  <option value="Sabahat Zubair
Dietitian
BSc (Food & Nutrit..">Sabahat Zubair
Dietitian
BSc (Food & Nutrit..</option>
	   <option value="Mishaal Perwaiz Khan
Dietitian
BSC, MPHILL (Food ..">Mishaal Perwaiz Khan
Dietitian
BSC, MPHILL (Food ..</option>
	  <option value="Amna Sarfraz
Dietitian
Bs(honors) food sc..">Amna Sarfraz
Dietitian
Bs(honors) food sc..</option>
	  <option value="Mahnaz Nasir Khan
Dietitian">Mahnaz Nasir Khan
Dietitian</option>
	  <option value="Shahid Mahmood
Dietitian">Shahid Mahmood
Dietitian</option>
	  <option value="Sadia Khan
Dietitian
MSc Food and Nutri..">Sadia Khan
Dietitian
MSc Food and Nutri..</option>
	   <option value="Ayesha Nasir
Dietitian
M.Sc. Food & Nutri..">Ayesha Nasir
Dietitian
M.Sc. Food & Nutri..</option>
	  <option value="Sidra Imtiaz
Dietitian
Mphil (Nutrition),..">Sidra Imtiaz
Dietitian
Mphil (Nutrition),..</option>
	  <option value="Faseeha Aman
Dietitian
BSc(Hons), MS (Hum..">Faseeha Aman
Dietitian
BSc(Hons), MS (Hum..</option>
	  <option value="Komal Saif
Dietitian
BS (Nutrionist & D..">Komal Saif
Dietitian
BS (Nutrionist & D..</option>
	  <option value="Qurat-ul-Ain Anis
Dietitian
B.S (Hons.) Food a..">Qurat-ul-Ain Anis
Dietitian
B.S (Hons.) Food a..</option>
	   <option value="Samia Khalid
Dietitian
BS(Clinical Nutrit..">Samia Khalid
Dietitian
BS(Clinical Nutrit..</option>
	  <option value="Moeena Baig
Dietitian
BSc (Hons), M.phil..">Moeena Baig
Dietitian
BSc (Hons), M.phil..</option>
	  <option value="DIABETIST IN HOSPITALS "><b>DIABETIST IN HOSPITALS </b></option>
	  <option value="Dr. Javeid Iqbal
Diabetist
MBBS,FCPS, Fellow ..">Dr. Javeid Iqbal
Diabetist
MBBS,FCPS, Fellow ..</option>
	  <option value="Dr. Asif M Kadri
Diabetist
MBBS, MCPS, DDM - ..">Dr. Asif M Kadri
Diabetist
MBBS, MCPS, DDM - ..</option>
	   <option value="DENTIST IN HOSPITALS "><b>DENTIST IN HOSPITALS </b></option>
	  <option value="Ali Murtaza Dawood
Dentist
DDS, Diploma (Impl..">Ali Murtaza Dawood
Dentist
DDS, Diploma (Impl..</option>
	  <option value="Dr Zuhaib Farooq
Dentist
BDS, M.Phil, PhD (..">Dr Zuhaib Farooq
Dentist
BDS, M.Phil, PhD (..</option>
	  <option value="Dr Bilal Habib
Dentist
BDS, RDS, C-Implan.">Dr Bilal Habib
Dentist
BDS, RDS, C-Implan.</option>
	  <option value="Dr Omer Farooq Ahmad
Dentist
BDS, F.I.C.D (USA)..">Dr Omer Farooq Ahmad
Dentist
BDS, F.I.C.D (USA)..</option>
	   <option value="Dr Muhammad Behzad Sala..
Dentist
BDS, MSc (London),..">Dr Muhammad Behzad Sala..
Dentist
BDS, MSc (London),..</option>
	  <option value="Dr. Imran Zia
Dentist
B.D.S (pb), R.D.S,..">Dr. Imran Zia
Dentist
B.D.S (pb), R.D.S,..</option>
	  <option value="Dr Asifa Iqbal
Dentist
BDS,M.Phil Oral Pa..">Dr Asifa Iqbal
Dentist
BDS,M.Phil Oral Pa..</option>
	  <option value="Dr Muhammad Moazzam
Dentist
BDS, FCPS (Operati..">Dr Muhammad Moazzam
Dentist
BDS, FCPS (Operati..</option>
	  <option value="Dr Shoaib Hanif
Dentist
BDS, C.Implants, C..">Dr Shoaib Hanif
Dentist
BDS, C.Implants, C..</option>
	   <option value="M. ShahRukh Lodhi
Dentist
BDS, C-implant, D-..">M. ShahRukh Lodhi
Dentist
BDS, C-implant, D-..</option>
	  <option value="Prof Asif Ali Shah
Dentist
BDS(Pb), MSc(Lon)">Prof Asif Ali Shah
Dentist
BDS(Pb), MSc(Lon)</option>
	  <option value="Dr Zahra Masood
Dentist
BDS, C-Implant">Dr Zahra Masood
Dentist
BDS, C-Implant</option>
	  <option value="Umber Ikram
Dentist
BDS, C-Ortho (Phil..">Umber Ikram
Dentist
BDS, C-Ortho (Phil..</option>
	  <option value="Ehsan Bhatti
Dentist
MBBS, FCPS, MCPS(T..">Ehsan Bhatti
Dentist
MBBS, FCPS, MCPS(T..</option>
	   <option value="Hafiz Umais Ahmed
Dentist
BDS, RDS, C-Ortho,..">Hafiz Umais Ahmed
Dentist
BDS, RDS, C-Ortho,..</option>
	  <option value="Prof Asma Shafique
Dentist
BDS, FCPS">Prof Asma Shafique
Dentist
BDS, FCPS</option>
	  <option value="Waqas Ahmed
Dentist
BDS , RDS , C-Mic..">Waqas Ahmed
Dentist
BDS , RDS , C-Mic..</option>
	  <option value="Dr. Aqib Sohail
Dentist">Dr. Aqib Sohail
Dentist</option>
	  <option value="Dr. Geti Fatima
Dentist
BDS, FRSH, RDS. - ..">Dr. Geti Fatima
Dentist
BDS, FRSH, RDS. - ..</option>
	   <option value="Dr Al Madani Salwa Moha..
Dentist
B.D.S.">Dr Al Madani Salwa Moha..
Dentist
B.D.S.</option>
	  <option value="Dr Junaid Siddique
Dentist
B.D.S.">Dr Junaid Siddique
Dentist
B.D.S.</option>
	  <option value="Dr Khurram Nadeem
Dentist
BDS, MCPS, PGDPH, ..">Dr Khurram Nadeem
Dentist
BDS, MCPS, PGDPH, ..</option>
	  <option value="Dr Edrees Anwar
Dentist
B.D.S">Dr Edrees Anwar
Dentist
B.D.S</option>
	  <option value="Dr Ehsan Rathore
Dentist
B.D.S. M.C.P.S F...">Dr Ehsan Rathore
Dentist
B.D.S. M.C.P.S F...</option>
	   <option value="Dr Ali Waqar Hasan
Dentist
B.D.S , Bsc , FCPS..">Dr Ali Waqar Hasan
Dentist
B.D.S , Bsc , FCPS..</option>
	  <option value="Dr Kausar Mahmood
Dentist
BDS MCPS ( OPERATI..">Dr Kausar Mahmood
Dentist
BDS MCPS ( OPERATI..</option>
	  <option value="Dr Zahra Shafi
Dentist
B.D.S.">Dr Zahra Shafi
Dentist
B.D.S.</option>
	  <option value="Dr Zaid Naveed
Dentist
B.D.S.">Dr Zaid Naveed
Dentist
B.D.S.</option>
	  <option value="Dr Zain Jawed
Dentist
B.D.S.">Dr Zain Jawed
Dentist
B.D.S.</option>
	  <option value="Dr Zainab Abdul Rakeeb ..
Dentist
B.D.S.">Dr Zainab Abdul Rakeeb ..
Dentist
B.D.S.</option>
	  <option value="Dr Zainab Dawood
Dentist
B.D.S.">Dr Zainab Dawood
Dentist
B.D.S.</option>
	  <option value="Zeeshan Haider
Dentist
BDS">Zeeshan Haider
Dentist
BDS</option>
	  <option value="Adeel Rana
Dentist
BDS, C-Implant, MPH">Adeel Rana
Dentist
BDS, C-Implant, MPH</option>
	  <option value="Shehla Saeed
Dentist
BDS">Shehla Saeed
Dentist
BDS</option>
	   <option value="COSMETIC SURGEON IN HOSPITALS"><b>COSMETIC SURGEON IN HOSPITALS</b></option>
	  <option value="Muhammad Sheraz Raza
Cosmetic Surgeon
MBBS, MRCS (EdinBu..">Muhammad Sheraz Raza
Cosmetic Surgeon
MBBS, MRCS (EdinBu..</option>
	  <option value="Dr. Farid Ahmad Khan
Cosmetic Surgeon
FRCS (Ed.), FCPS (..">Dr. Farid Ahmad Khan
Cosmetic Surgeon
FRCS (Ed.), FCPS (..</option>
	  <option value="Nauman Ahmad Gill
Cosmetic Surgeon
M.B.B.S,M.R.C.S(UK..">Nauman Ahmad Gill
Cosmetic Surgeon
M.B.B.S,M.R.C.S(UK..</option>
	  <option value="Dr Sohail
Cosmetic Surgeon
MBBS.DSA. (austria..">Dr Sohail
Cosmetic Surgeon
MBBS.DSA. (austria..</option>
	   <option value="CHEST SPECIALIST IN HOSPITALS"><b>CHEST SPECIALIST IN HOSPITALS</b></option>
	  <option value="Dr. Mansur Javaid
Chest Specialist
MBBS - Chest Speci..">Dr. Mansur Javaid
Chest Specialist
MBBS - Chest Speci..</option>
	  <option value="Dr. Anees Arshad
Chest Specialist
MBBS - Chest Speci..">Dr. Anees Arshad
Chest Specialist
MBBS - Chest Speci..</option>
	  <option value="Dr. Saleem Uz Zaman Adh..
Chest Specialist
MBBS, MRCP - Chest.">Dr. Saleem Uz Zaman Adh..
Chest Specialist
MBBS, MRCP - Chest.</option>
	  <option value="Dr. Muhammad Ameen
Chest Specialist
MBBS - Chest Speci..">Dr. Muhammad Ameen
Chest Specialist
MBBS - Chest Speci..</option>
	   <option value="Dr. Rana Mustafa
Chest Specialist
MBBS - Chest Speci..">Dr. Rana Mustafa
Chest Specialist
MBBS - Chest Speci..</option>
	  <option value="Dr. Rana Mustafa
Chest Specialist
MBBS - Chest Speci..">Dr. Rana Mustafa
Chest Specialist
MBBS - Chest Speci..</option>
	  <option value="Dr. Muhammad Razaq
Chest Specialist
MBBS - Chest Speci..">Dr. Muhammad Razaq
Chest Specialist
MBBS - Chest Speci..</option>
	  <option value="Dr. Muhammad Toseef Razaq
Chest Specialist
MBBS - Chest Speci..">Dr. Muhammad Toseef Razaq
Chest Specialist
MBBS - Chest Speci..</option>
	  <option value="Dr. Saulat Ullah Khan
Chest Specialist
MBBS - Chest Speci..">Dr. Saulat Ullah Khan
Chest Specialist
MBBS - Chest Speci..</option>
	   <option value="Dr. Ayub Latif Khawaja
Chest Specialist
MBBS - Chest Speci..">Dr. Ayub Latif Khawaja
Chest Specialist
MBBS - Chest Speci..</option>
	  <option value="Dr. Muhammad Ihsan Khan
Chest Specialist
MBBS, TDD, FCCP. -..">Dr. Muhammad Ihsan Khan
Chest Specialist
MBBS, TDD, FCCP. -..</option>
	  <option value="Prof. Shabir Haider
Chest Specialist
MBBS - Chest Speci..">Prof. Shabir Haider
Chest Specialist
MBBS - Chest Speci..</option>
	  <option value="Dr. Imtiaz Randhawa
Chest Specialist
MBBS - Chest Speci..">Dr. Imtiaz Randhawa
Chest Specialist
MBBS - Chest Speci..</option>
	  <option value="Dr. Mohammad Javaid Sha..
Chest Specialist
MBBS, DGO, MCPS, M..">Dr. Mohammad Javaid Sha..
Chest Specialist
MBBS, DGO, MCPS, M..</option>
	   <option value="Dr. Rana Sohail
Chest Specialist
MBBS - Chest Speci..">Dr. Rana Sohail
Chest Specialist
MBBS - Chest Speci..</option>
	  <option value="Dr. Tanveer Ul Islam
Chest Specialist
MBBS - Chest Speci..">Dr. Tanveer Ul Islam
Chest Specialist
MBBS - Chest Speci..</option>
	  <option value="Dr. Rana Sohail Ahmed
Chest Specialist
MBBS - Chest Speci..">Dr. Rana Sohail Ahmed
Chest Specialist
MBBS - Chest Speci..</option>
	  <option value="Dr. Saeed Kaleem
Chest Specialist">Dr. Saeed Kaleem
Chest Specialist</option>
	  <option value="Dr. Mohammad Tauseef Ra..
Chest Specialist">Dr. Mohammad Tauseef Ra..
Chest Specialist</option>
	   <option value="Dr. Muhammad Abdul Razzaq
Chest Specialist">Dr. Muhammad Abdul Razzaq
Chest Specialist</option>
	  <option value="Dr. Amir Nazir
Chest Specialist">Dr. Amir Nazir
Chest Specialist</option>
	  <option value="Dr. Mohammad Sohail Gill
Chest Specialist">Dr. Mohammad Sohail Gill
Chest Specialist</option>
	  <option value="Prof Dr. Syed Nazim Hus..
Chest Specialist">Prof Dr. Syed Nazim Hus..
Chest Specialist</option>
	  <option value="Dr. Qamar Uz Zaman
Chest Specialist">Dr. Qamar Uz Zaman
Chest Specialist</option>
	   <option value="Dr. Mohammad Akram
Chest Specialist
MBBS DTCD">Dr. Mohammad Akram
Chest Specialist
MBBS DTCD</option>
	  <option value="Dr. Muhammad Zulfikar K..
Chest Specialist">Dr. Muhammad Zulfikar K..
Chest Specialist</option>
	  <option value="Dr. Iftikhar Ali Mirza
Chest Specialist">Dr. Iftikhar Ali Mirza
Chest Specialist</option>
	  <option value="Dr. Tahir Saeed
Chest Specialist">Dr. Tahir Saeed
Chest Specialist</option>
	  <option value="Dr. Rashid Naeem Siddiqui
Chest Specialist">Dr. Rashid Naeem Siddiqui
Chest Specialist</option>
	   <option value="Dr. Saleem-Uz-Zaman Adh..
Chest Specialist">Dr. Saleem-Uz-Zaman Adh..
Chest Specialist</option>
	  <option value="Dr. Ghazanfar Raza
Chest Specialist">Dr. Ghazanfar Raza
Chest Specialist</option>
	  <option value="Dr Afzaalullah Khan
Chest Specialist
MBBS,DTCD">Dr Afzaalullah Khan
Chest Specialist
MBBS,DTCD</option>
	  <option value="CARDIOLOGIST IN HOSPITALS"><b>CARDIOLOGIST IN HOSPITALS</b></option>
	  <option value="Dr. Muhammad Zarrar Ari..
Cardiologist
MBBS, FCPS (Cardio..">Dr. Muhammad Zarrar Ari..
Cardiologist
MBBS, FCPS (Cardio..</option>
	   <option value="Nauman Zahoor Ahmed
Cardiologist
MBBS, Diplomate Ca..">Nauman Zahoor Ahmed
Cardiologist
MBBS, Diplomate Ca..</option>
	  <option value="Mudassar Qayyum
Cardiologist
MBBS, FCPS (Cardio..">Mudassar Qayyum
Cardiologist
MBBS, FCPS (Cardio..</option>
	  <option value="Muhammad Suleman Khan
Cardiologist
MBBS, FCPS (Cardio..">Muhammad Suleman Khan
Cardiologist
MBBS, FCPS (Cardio..</option>
	  <option value="Junaid Zaffar
Cardiologist
MBBS, FCPS, MCPS, ..">Junaid Zaffar
Cardiologist
MBBS, FCPS, MCPS, ..</option>
	  <option value="Shahnawaz Ahmad
Cardiologist
MBBS">Shahnawaz Ahmad
Cardiologist
MBBS</option>
	   <option value="Ammar Hameed Khan
Cardiologist
MBBS, FRCS, Fellow..">Ammar Hameed Khan
Cardiologist
MBBS, FRCS, Fellow..</option>
	  <option value="Gohar Saeed
Cardiologist
MD, FACC, FSCAI">Gohar Saeed
Cardiologist
MD, FACC, FSCAI</option>
	  <option value="Tayyab Mohyuddin
Cardiologist
MBBS, MD, FACC, FS..">Tayyab Mohyuddin
Cardiologist
MBBS, MD, FACC, FS..</option>
	  <option value="Dr. Aftab Hussain
Cardiologist
MBBS, FCPS (Cardio..">Dr. Aftab Hussain
Cardiologist
MBBS, FCPS (Cardio..</option>
	  <option value="Dr Zameer ul asar
Cardiologist
MBBS，FCPS Cardiology">Dr Zameer ul asar
Cardiologist
MBBS，FCPS Cardiology</option>
	   <option value="Dr MUHAMMAD RAFEEQ SHAH
Cardiologist
m.b.b.s F.C.P.S ..">Dr MUHAMMAD RAFEEQ SHAH
Cardiologist
m.b.b.s F.C.P.S ..</option>
	  <option value="Dr Arsalan Masoud
Cardiologist
MBBS">Dr Arsalan Masoud
Cardiologist
MBBS</option>
	  <option value="Dr Sikander Hayat Raza
Cardiologist
MBBS, MRCP (UK), M..">Dr Sikander Hayat Raza
Cardiologist
MBBS, MRCP (UK), M..</option>
	  <option value="Ali Mustansir
Cardiologist
F.C.P.S.">Ali Mustansir
Cardiologist
F.C.P.S.</option>
	  <option value="Dr. Amanullah
Cardiologist
MBBS, DipCard, MAS..">Dr. Amanullah
Cardiologist
MBBS, DipCard, MAS..</option>
	   <option value="Dr. Liaqat Ali
Cardiologist
MBBS, FCPS, FACP -..">Dr. Liaqat Ali
Cardiologist
MBBS, FCPS, FACP -..</option>
	  <option value="Dr. Shahryar Ahmad Sheikh
Cardiologist
MBBS, MD , FACC - ..">Dr. Shahryar Ahmad Sheikh
Cardiologist
MBBS, MD , FACC - ..</option>
	  <option value="Dr. Sheharyar Hassan Khan
Cardiologist
MBBS, FCPS, MRCP">Dr. Sheharyar Hassan Khan
Cardiologist
MBBS, FCPS, MRCP</option>
	  <option value="Dr. Ghulam Abbass
Cardiologist">Dr. Ghulam Abbass
Cardiologist</option>
	  <option value="Dr. Amir Khan
Cardiologist">Dr. Amir Khan
Cardiologist</option>
	   <option value="Mohiuddin
Cardiologist
MBBS,FRCP">Mohiuddin
Cardiologist
MBBS,FRCP</option>
	  <option value="Dr Noor Dastgir
Cardiologist
MBBS, FCPS">Dr Noor Dastgir
Cardiologist
MBBS, FCPS</option>
	  <option value="Dr Omar Aziz Rana
Cardiologist
MBBS, DM, MRCP (UK..">Dr Omar Aziz Rana
Cardiologist
MBBS, DM, MRCP (UK..</option>
	  <option value="VASCULAR SURGEON IN HOSPITALS"><b>VASCULAR SURGEON IN HOSPITALS</b></option>
	  <option value="Dr Rashid Usman
Vascular Surgeon
MBBS (KEMU), MRCS ..">Dr Rashid Usman
Vascular Surgeon
MBBS (KEMU), MRCS ..</option>
	  
	  <option value="Ilyas Sadiq
Vascular Surgeon
MBBS, FCPS-I, FRCS..">Ilyas Sadiq
Vascular Surgeon
MBBS, FCPS-I, FRCS..</option>
	  <option value="Dr. Aasim Malik
Vascular Surgeon">Dr. Aasim Malik
Vascular Surgeon</option>
	  <option value="Prof. Ilyas Sadiq
Vascular Surgeon">Prof. Ilyas Sadiq
Vascular Surgeon</option>
	  <option value="UROLOGIC ONCOLOGIST IN HOSPITALS "><b>UROLOGIC ONCOLOGIST IN HOSPITALS </b></option>
	  <option value="Awais Amjad Malik
Urologic Oncologist
MBBS, FCPS (Genera..">Awais Amjad Malik
Urologic Oncologist
MBBS, FCPS (Genera..</option>
	  <option value="THORACIC SURGEON IN HOSPITALS"><b>THORACIC SURGEON IN HOSPITALS</b></option>
	   <option value="Dr. Muhammad Shoaib Nabi
Thoracic Surgeon
MBBS - Thoracic Su..">Dr. Muhammad Shoaib Nabi
Thoracic Surgeon
MBBS - Thoracic Su..</option>
	  <option value="Dr Syed Muhammad Raza
Thoracic Surgeon
MBBS, MS Thoracic ..">Dr Syed Muhammad Raza
Thoracic Surgeon
MBBS, MS Thoracic ..</option>
	  <option value="SONOLOGIST IN HOSPITALS"><b>SONOLOGIST IN HOSPITALS</b></option>
	  <option value="Robina Anwar
Sonologist
MBBS - Sonologist">Robina Anwar
Sonologist
MBBS - Sonologist</option>
	  <option value="SEXOLOGIST IN HOSPITALS"><b>SEXOLOGIST IN HOSPITALS</b></option>
	   <option value="Dr Muhammad Haris Burki
Sexologist
MBBS, FECSM, PHD, ..">Dr Muhammad Haris Burki
Sexologist
MBBS, FECSM, PHD, ..</option>
	  <option value="Dr.Ashfaq Hamza
Sexologist
MBBS, FCPS,">Dr.Ashfaq Hamza
Sexologist
MBBS, FCPS,</option>
	  <option value="Dr. Akram Khan
Sexologist">Dr. Akram Khan
Sexologist</option>
	  <option value="Dr. M. Aslam Naveed
Sexologist">Dr. M. Aslam Naveed
Sexologist</option>
	  <option value="Prof Dr. Ijaz Haider
Sexologist">Prof Dr. Ijaz Haider
Sexologist</option>
	   <option value="Dr. Kamran
Sexologist
MBBS">Dr. Kamran
Sexologist
MBBS</option>
	  <option value="Dr. Imran T Hashmi
Sexologist">Dr. Imran T Hashmi
Sexologist</option>
	  <option value="Dr. Usman Amin Hotiana
Sexologist">Dr. Usman Amin Hotiana
Sexologist</option>
	  <option value="Dr. Bushra Jabeen
Sexologist">Dr. Bushra Jabeen
Sexologist</option>
	  <option value="Dr. Zubair Bhatti
Sexologist">Dr. Zubair Bhatti
Sexologist</option>
	   <option value="Khaliq Ul Rehman
Sexologist">Khaliq Ul Rehman
Sexologist</option>
	  <option value="Dr. Shahida Malik
Sexologist">Dr. Shahida Malik
Sexologist</option>
	  <option value="Muhammad Haris Burki
Sexologist
MBBS,PhD,FECSM sex..">Muhammad Haris Burki
Sexologist
MBBS,PhD,FECSM sex..</option>
	  <option value="REHABILITATION MEDICINE IN HOSPITALS"><b>REHABILITATION MEDICINE IN HOSPITALS</b></option>
	  <option value="Dr. Arbab Afzal
Rehabilitation Medicine
MBBS, MD (Medicine)">Dr. Arbab Afzal
Rehabilitation Medicine
MBBS, MD (Medicine)</option>
	   <option value="PULMONOLOGIST IN HOSPITALS"><b>PULMONOLOGIST IN HOSPITALS</b></option>
	  <option value="Muhammad Hussain
Pulmonologist
MBBS, FCPS, MACP">Muhammad Hussain
Pulmonologist
MBBS, FCPS, MACP</option>
	  <option value="Prof Shamshad Rasul Awan
Pulmonologist
MBBS, MCPS, FCPS, ..">Prof Shamshad Rasul Awan
Pulmonologist
MBBS, MCPS, FCPS, ..</option>
	  <option value="Khawar Abbas
Pulmonologist
MBBS, MD,MRCP(Uk),..">Khawar Abbas
Pulmonologist
MBBS, MD,MRCP(Uk),..</option>
	  <option value="Kamran Hameed
Pulmonologist
MBBS, MRCP (UK), F..">Kamran Hameed
Pulmonologist
MBBS, MRCP (UK), F..</option>
	   <option value="Atif Mahmood
Pulmonologist
MBBS, FMGMS, USA, ..">Atif Mahmood
Pulmonologist
MBBS, FMGMS, USA, ..</option>
	  <option value="DR. KHAWAR ABBAS
Pulmonologist
MBBS, MD,MRCP(Uk),..">DR. KHAWAR ABBAS
Pulmonologist
MBBS, MD,MRCP(Uk),..</option>
	  <option value="PROF. DR. SHAMSHAD RASU..
Pulmonologist
MBBS, MCPS, FCPS, ..">PROF. DR. SHAMSHAD RASU..
Pulmonologist
MBBS, MCPS, FCPS, ..</option>
	  <option value="DR. KAMRAN HAMEED
Pulmonologist
MBBS, MCPS, FCPS, ..">DR. KAMRAN HAMEED
Pulmonologist
MBBS, MCPS, FCPS, ..</option>
	  <option value="PROF. DR. SHOAIB ALAM
Pulmonologist
MBBS, MCPS, FCPS, ..">PROF. DR. SHOAIB ALAM
Pulmonologist
MBBS, MCPS, FCPS, ..</option>
	   <option value="Nazim Bukhari
Pulmonologist
M.D, FCCP - Pulmon..">Nazim Bukhari
Pulmonologist
M.D, FCCP - Pulmon..</option>
	  <option value="Mohammad Ihsan Khan
Pulmonologist
MBBS, TDD, FCCP - ..">Mohammad Ihsan Khan
Pulmonologist
MBBS, TDD, FCCP - ..</option>
	  <option value="Dr. Mansur Javaid
Pulmonologist
MBBS, FCCP, DABIM ..">Dr. Mansur Javaid
Pulmonologist
MBBS, FCCP, DABIM ..</option>
	  <option value="Dr. Mohammad Ameen
Pulmonologist
MBBS, DTCD - Pulmo..">Dr. Mohammad Ameen
Pulmonologist
MBBS, DTCD - Pulmo..</option>
	  <option value="Dr. Anees Arshad
Pulmonologist
MBBS, MD, DAB - Pu..">Dr. Anees Arshad
Pulmonologist
MBBS, MD, DAB - Pu..</option>
	   <option value="Dr. Muhammad Toseef Razaq
Pulmonologist
MBBS, MD, FACA, FC..">Dr. Muhammad Toseef Razaq
Pulmonologist
MBBS, MD, FACA, FC..</option>
	  <option value="Dr. Saulat Ullah Khan
Pulmonologist
MBBS, DTCD, MCPS, ..">Dr. Saulat Ullah Khan
Pulmonologist
MBBS, DTCD, MCPS, ..</option>
	  <option value="Dr. Shamshad Rasool Awan
Pulmonologist
MBBS, MCPS, FCPS, .">Dr. Shamshad Rasool Awan
Pulmonologist
MBBS, MCPS, FCPS, .</option>
	  <option value="Dr. Nazim Bukhari
Pulmonologist
M.D, FCCP - Pulmon..">Dr. Nazim Bukhari
Pulmonologist
M.D, FCCP - Pulmon..</option>
	  <option value="Dr. Humanyyun Ihsan
Pulmonologist
MBBS, MCPS, DTCD -..">Dr. Humanyyun Ihsan
Pulmonologist
MBBS, MCPS, DTCD -..</option>
	   <option value="Dr. Mohammad Ihsan Khan
Pulmonologist
MBBS, TDD, FCCP - ..">Dr. Mohammad Ihsan Khan
Pulmonologist
MBBS, TDD, FCCP - ..</option>
	  <option value="Dr. Mohammad Ihsan Khan
Pulmonologist
MBBS, TDD, FCCP - ..">Dr. Mohammad Ihsan Khan
Pulmonologist
MBBS, TDD, FCCP - ..</option>
	  <option value="Dr. Rana Sohail
Pulmonologist
MBBS, DTCD, MACCP ..">Dr. Rana Sohail
Pulmonologist
MBBS, DTCD, MACCP ..</option>
	  <option value="Dr. Rana Sohail Ahmed
Pulmonologist
MBBS, DTCD, MACCP ..">Dr. Rana Sohail Ahmed
Pulmonologist
MBBS, DTCD, MACCP ..</option>
	  <option value="Dr. Tanveer Ul Islam
Pulmonologist
MBBS, MACP, DABIM ..">Dr. Tanveer Ul Islam
Pulmonologist
MBBS, MACP, DABIM ..</option>
	   <option value="Dr. M Irfan Malik
Pulmonologist
M.B.B.S, F.C.P.S(P..">Dr. M Irfan Malik
Pulmonologist
M.B.B.S, F.C.P.S(P..</option>
	  <option value="Dr. Talha Mahmud
Pulmonologist
FCPS (Medicine), M..">Dr. Talha Mahmud
Pulmonologist
FCPS (Medicine), M..</option>
	  <option value="Dr. Kamran Chima
Pulmonologist">Dr. Kamran Chima
Pulmonologist</option>
	  <option value="Dr.Haroon Ihsan
Pulmonologist">Dr.Haroon Ihsan
Pulmonologist</option>
	  <option value="PSYCHIATRIST IN HOSPITALS"><b>PSYCHIATRIST IN HOSPITALS</b></option>
	   <option value="Ayesha Naveed
Psychiatrist
MBBS, MRCP (Psych)..">Ayesha Naveed
Psychiatrist
MBBS, MRCP (Psych)..</option>
	  <option value="Qambar Murtaza Bokhari
Psychiatrist
MBBS, FCPS (Psych)..">Qambar Murtaza Bokhari
Psychiatrist
MBBS, FCPS (Psych)..</option>
	  <option value="Naeem Aftab
Psychiatrist
MBBS, DIPLOMAT Ame..">Naeem Aftab
Psychiatrist
MBBS, DIPLOMAT Ame..</option>
	  <option value="Muhammad Mujtaba
Psychiatrist
MBBS, FCPS,MCPS">Muhammad Mujtaba
Psychiatrist
MBBS, FCPS,MCPS</option>
	  <option value="Ismail Tariq
Psychiatrist
MBBS, DPM, MCPS, F..">Ismail Tariq
Psychiatrist
MBBS, DPM, MCPS, F..</option>
	   <option value="Syed Kamran Haider Bukh..
Psychiatrist">Syed Kamran Haider Bukh..
Psychiatrist</option>
	  <option value="Aysha Butt
Psychiatrist
MBBS, FCPS (Psychi..">Aysha Butt
Psychiatrist
MBBS, FCPS (Psychi..</option>
	  <option value="Naseem Chaudhry
Psychiatrist
MBBS, American Dip.">Naseem Chaudhry
Psychiatrist
MBBS, American Dip.</option>
	  <option value="Usman Amin Hotiana
Psychiatrist
MBBS, FCPS (Psych)">Usman Amin Hotiana
Psychiatrist
MBBS, FCPS (Psych)</option>
	  <option value="Dr Munir Ahmad Khan
Psychiatrist
MBBS, DPM">Dr Munir Ahmad Khan
Psychiatrist
MBBS, DPM</option>
	   <option value="Muhammad Haris Khan
Psychiatrist
WPA-CME, PhDHe has..">Muhammad Haris Khan
Psychiatrist
WPA-CME, PhDHe has..</option>
	  <option value="Mian Niaz Ahmed
Psychiatrist
Medical">Mian Niaz Ahmed
Psychiatrist
Medical</option>
	  <option value="Dr. Arslan Butt
Psychiatrist
MBBS - Psychiatrist">Dr. Arslan Butt
Psychiatrist
MBBS - Psychiatrist</option>
	  <option value="Dr. Muhammad Nasir Saee..
Psychiatrist
MBBS - Physiatrist"></option>
	  <option value="Dr. Muhammad Waseem
Psychiatrist
M.B.B.S(K.E),DPM">Dr. Muhammad Waseem
Psychiatrist
M.B.B.S(K.E),DPM</option>
	  <option value="Dr Muhammad Ismail Tariq
Psychiatrist
MBBS,DPM,MCPS,FCPS..">Dr Muhammad Ismail Tariq
Psychiatrist
MBBS,DPM,MCPS,FCPS..</option>
	  <option value="Dr. Capt. Liaqat Ali
Psychiatrist">Dr. Capt. Liaqat Ali
Psychiatrist</option>
	  <option value="Dr. Imran Hashmi
Psychiatrist">Dr. Imran Hashmi
Psychiatrist</option>
	  <option value="Dr. Aftab Asif
Psychiatrist">Dr. Aftab Asif
Psychiatrist</option>
	  <option value="Dr. Mohsin Saqib
Psychiatrist
MRCP (Psych)">Dr. Mohsin Saqib
Psychiatrist
MRCP (Psych)</option>
	   <option value="Dr RANA QASIM HASSAN
Psychiatrist
MBBS, DPP.(UK),MAA..">Dr RANA QASIM HASSAN
Psychiatrist
MBBS, DPP.(UK),MAA..</option>
	  <option value="Dr Muhammad Imran Afzal
Psychiatrist
M.b.b.s D.P.M.">Dr Muhammad Imran Afzal
Psychiatrist
M.b.b.s D.P.M.</option>
	  <option value="Dr. Col. Masood Ahmad
Psychiatrist
MBBS, DIP-Psych, M..">Dr. Col. Masood Ahmad
Psychiatrist
MBBS, DIP-Psych, M..</option>
	  <option value="Dr Shahbaz Noor
Psychiatrist
MBBS, MRCPsych (UK)">Dr Shahbaz Noor
Psychiatrist
MBBS, MRCPsych (UK)</option>
	  <option value="PHYSICIAN IN HOSPITALS"><b>PHYSICIAN IN HOSPITALS</b></option>
	   <option value="Dr Muhammad Awais Abid
Physician
Fcps(medicine ), F..">Dr Muhammad Awais Abid
Physician
Fcps(medicine ), F..</option>
	  <option value="Dr Malik Shamoon Hussain
Physician
M.D Pharmacist">Dr Malik Shamoon Hussain
Physician
M.D Pharmacist</option>
	  <option value="Dr Zar Khan
Physician
MBBS">Dr Zar Khan
Physician
MBBS</option>
	  <option value="Sleem uz zaman Adhmi
Physician
MBBS, MRCP - Physi..">Sleem uz zaman Adhmi
Physician
MBBS, MRCP - Physi..</option>
	  <option value="Rohi Nadeem
Physician
MBBS, MIDC - Physi..">Rohi Nadeem
Physician
MBBS, MIDC - Physi..</option>
	   <option value="Dr. Farrukh Iqbal
Physician
MBBS, MRCP, FRCP -..">Dr. Farrukh Iqbal
Physician
MBBS, MRCP, FRCP -..</option>
	  <option value="Dr. Haroon Khan Babar
Physician
MBBS, DTM, MRCP, M..">Dr. Haroon Khan Babar
Physician
MBBS, DTM, MRCP, M..</option>
	  <option value="Dr. Sajid Abdullah
Physician
MBBS, FCPS - Physi..">Dr. Sajid Abdullah
Physician
MBBS, FCPS - Physi..</option>
	  <option value="Dr. Maria Arora
Physician
MBBS, DTCD, MCPS, ..">Dr. Maria Arora
Physician
MBBS, DTCD, MCPS, ..</option>
	  <option value="Dr. Imtiaz Ali
Physician
BS.c, MBBS(Pb) RMP..">Dr. Imtiaz Ali
Physician
BS.c, MBBS(Pb) RMP..</option>
	   <option value="Dr. Asma Nazir
Physician
MBBS, FCPS - Physi..">Dr. Asma Nazir
Physician
MBBS, FCPS - Physi..</option>
	  <option value="Dr. Nusrum Iqbal
Physician
MBBS (PB), MD (USA..">Dr. Nusrum Iqbal
Physician
MBBS (PB), MD (USA..</option>
	  <option value="Dr. Sohail Malik
Physician
MBBS (Pb), PMDC, (..">Dr. Sohail Malik
Physician
MBBS (Pb), PMDC, (..</option>
	  <option value="Dr. Samee Ullah Sheikh
Physician
MBBS, DPH, FCGP. -..">Dr. Samee Ullah Sheikh
Physician
MBBS, DPH, FCGP. -..</option>
	  <option value="Dr. Moeen Ul Haq
Physician
MBBS MRCP - Physic..">Dr. Moeen Ul Haq
Physician
MBBS MRCP - Physic..</option>
	   <option value="Dr. Faisal Sultan
Physician
MBBS, DABIM. - Phy..">Dr. Faisal Sultan
Physician
MBBS, DABIM. - Phy..</option>
	  <option value="Dr. Rashid Ahmed
Physician
MBBS, MD - Physician">Dr. Rashid Ahmed
Physician
MBBS, MD - Physician</option>
	  <option value="Dr. Najma Pervaiz
Physician
MBBS - Physician">Dr. Najma Pervaiz
Physician
MBBS - Physician</option>
	  <option value="Dr. Mohammad Akhtar Khan
Physician
MBBS, FCPS, FRCP -..">Dr. Mohammad Akhtar Khan
Physician
MBBS, FCPS, FRCP -..</option>
	  <option value="Dr. Muhammad Haroon Yusuf
Physician
MBBS, FCPS - Physi..">Dr. Muhammad Haroon Yusuf
Physician
MBBS, FCPS - Physi..</option>
	   <option value="Dr. Rashid Abbas
Physician
MBBS - Physician">Dr. Rashid Abbas
Physician
MBBS - Physician</option>
	  <option value="Dr. Sleem Uz Zaman Adhmi
Physician
MBBS, MRCP - Physi..">Dr. Sleem Uz Zaman Adhmi
Physician
MBBS, MRCP - Physi..</option>
	  <option value="Dr. Naveed Ilyas Awan
Physician
MD - Physician">Dr. Naveed Ilyas Awan
Physician
MD - Physician</option>
	  <option value="Dr. Mustab Ahmed
Physician
MBBS, MD, MRCP - P..">Dr. Mustab Ahmed
Physician
MBBS, MD, MRCP - P..</option>
	  <option value="Dr. Shamail Zafar
Physician
MBBS FCPS - Physic..">Dr. Shamail Zafar
Physician
MBBS FCPS - Physic..</option>
	   <option value="Dr. Fawad Shafiq
Physician
MBBS, MACP, MRCP -..">Dr. Fawad Shafiq
Physician
MBBS, MACP, MRCP -..</option>
	  <option value="Dr. Sheikh Muhammad Meh..
Physician
MBBS, MRCP - Physi..">Dr. Sheikh Muhammad Meh..
Physician
MBBS, MRCP - Physi..</option>
	  <option value="Dr. M.Aslam Shahid
Physician
MBBS, FCPS - Physi..">Dr. M.Aslam Shahid
Physician
MBBS, FCPS - Physi..</option>
	  <option value="Dr. Tanveer Ahmed Bhatti
Physician
MBBS, MD, FCPS - P..">Dr. Tanveer Ahmed Bhatti
Physician
MBBS, MD, FCPS - P..</option>
	  <option value="Dr. Muhammad Ahmed Saeed
Physician
MBBS - Physician">Dr. Muhammad Ahmed Saeed
Physician
MBBS - Physician</option>
	   <option value="Dr. Muhammad Yousaf
Physician
MBBS, MRCP, MRCS, ..">Dr. Muhammad Yousaf
Physician
MBBS, MRCP, MRCS, ..</option>
	  <option value="Dr. Sajid Mehmood Rana
Physician
MBBS, FCPS - Physi..">Dr. Sajid Mehmood Rana
Physician
MBBS, FCPS - Physi..</option>
	  <option value="Dr. Wasim Amir
Physician
MBBS, FCPS - Physi..">Dr. Wasim Amir
Physician
MBBS, FCPS - Physi..</option>
	  <option value="Dr. Salim Chaudhry
Physician
MBBS, MRCP, FRCP -..">Dr. Salim Chaudhry
Physician
MBBS, MRCP, FRCP -..</option>
	  <option value="Dr. Inayat Ullah Niazi
Physician
MBBS, MRCP, FRCP, ..">Dr. Inayat Ullah Niazi
Physician
MBBS, MRCP, FRCP, ..</option>
	   <option value="Dr. Irshad Ahmed Qureshi
Physician
MBBS, FCPS, MD - P..">Dr. Irshad Ahmed Qureshi
Physician
MBBS, FCPS, MD - P..</option>
	  <option value="PHYSIATRIST IN HOSPITALS"><b>PHYSIATRIST IN HOSPITALS</b></option>
	  <option value="Junaid Rasool
Physiatrist
MBBS, FCPS (Psychi..">Junaid Rasool
Physiatrist
MBBS, FCPS (Psychi..</option>
	  <option value="Prof. Dr. I.A.K Tareen
Physiatrist">Prof. Dr. I.A.K Tareen
Physiatrist</option>
	  <option value="PEDIATRIC ORTHOPEDIC SURGEON IN HOSPITALS"><b>PEDIATRIC ORTHOPEDIC SURGEON IN HOSPITALS</b></option>
	   <option value="Dr Shaila Ali
Pediatric Orthopedic Surgeon
MBBS, FCPS">Dr Shaila Ali
Pediatric Orthopedic Surgeon
MBBS, FCPS</option>
	  <option value="PAIN MANAGEMENT SPECIALIST IN HOSPITALS"><b>PAIN MANAGEMENT SPECIALIST IN HOSPITALS</b></option>
	  <option value="Dr Muhammad Jawad Alam
Pain Management Specialist
BSPT (KEMU) TDPT/M..">Dr Muhammad Jawad Alam
Pain Management Specialist
BSPT (KEMU) TDPT/M..</option>
	  <option value="Waqas A. Chaudhary,M.D.
Pain Management Specialist
MBBS, MD, Dip.Pain..">Waqas A. Chaudhary,M.D.
Pain Management Specialist
MBBS, MD, Dip.Pain..</option>
	  <option value="Dr Waqas A Chaudhary
Pain Management Specialist
MB, MD, MSc Pain M..">Dr Waqas A Chaudhary
Pain Management Specialist
MB, MD, MSc Pain M..</option>
	   <option value="Muhammad Akbar Zahid
Pain Management Specialist
M.D.. DC..D.A.AP.M..">Muhammad Akbar Zahid
Pain Management Specialist
M.D.. DC..D.A.AP.M..</option>
	  <option value="Syed Mehmood Ali
Pain Management Specialist
MBBS, FCPS, M.Sc (..">Syed Mehmood Ali
Pain Management Specialist
MBBS, FCPS, M.Sc (..</option>
	  <option value="Muhammad Azhar
Pain Management Specialist
MBBS (KEMU), MCPS ..">Muhammad Azhar
Pain Management Specialist
MBBS (KEMU), MCPS ..</option>
	  <option value="Muhammad Jamil Sabit
Pain Management Specialist
MBBS, MSC (Pain Me..">Muhammad Jamil Sabit
Pain Management Specialist
MBBS, MSC (Pain Me..</option>
	  <option value="Dr Ateeq Ur Rehman Ghaf..
Pain Management Specialist
MBBS, MRCS, FCAI, ..">Dr Ateeq Ur Rehman Ghaf..
Pain Management Specialist
MBBS, MRCS, FCAI, ..</option>
	   <option value="Dr Muhammad Zafar Khan
Pain Management Specialist
MBBS; FCARCSI">Dr Muhammad Zafar Khan
Pain Management Specialist
MBBS; FCARCSI</option>
	  <option value="Dr. Jawed Akhtar
Pain Management Specialist
MBBS, FRCS (Irela..">Dr. Jawed Akhtar
Pain Management Specialist
MBBS, FRCS (Irela..</option>
	  <option value="Prof. Dr. Waseem Ismat ..
Pain Management Specialist
MBBS, FCPS, Diplom..">Prof. Dr. Waseem Ismat ..
Pain Management Specialist
MBBS, FCPS, Diplom..</option>
	  <option value="PAEDIATRIC RADIOLOGIST IN HOSPITALS"><b>PAEDIATRIC RADIOLOGIST IN HOSPITALS</b></option>
	  <option value="Mahfooz ur Rehman Khan
Paediatric Radiologist
MBBS, DRMD">Mahfooz ur Rehman Khan
Paediatric Radiologist
MBBS, DRMD</option>
	   <option value="Dr Shahzad Karim Bhatti
Paediatric Radiologist
MBBS, MCPS, FCPS">Dr Shahzad Karim Bhatti
Paediatric Radiologist
MBBS, MCPS, FCPS</option>
	  <option value="ORTHOPEDIST IN HOSPITALS ">ORTHOPEDIST IN HOSPITALS </option>
	  <option value="Dr. Muhammad Ashraf Niz..
Orthopedist
MD, FRCOS, Ph.D. -..">Dr. Muhammad Ashraf Niz..
Orthopedist
MD, FRCOS, Ph.D. -..</option>
	  <option value="Dr. Shafique Ahmad Shafaq
Orthopedist
MBBS, FCPS - Ortho..">Dr. Shafique Ahmad Shafaq
Orthopedist
MBBS, FCPS - Ortho..</option>
	  <option value="Dr. Abdul Latif Samee
Orthopedist
MBBS, FRCS - Ortho..">Dr. Abdul Latif Samee
Orthopedist
MBBS, FRCS - Ortho..</option>
	  <option value="Dr. Ghulam Murtaza Cheema
Orthopedist
MBBS, FRCS, FCPS -..">Dr. Ghulam Murtaza Cheema
Orthopedist
MBBS, FRCS, FCPS -..</option>
	  <option value="Dr. Asif Chaudhry
Orthopedist
MBBS, FRCS - Ortho..">Dr. Asif Chaudhry
Orthopedist
MBBS, FRCS - Ortho..</option>
	  <option value="Dr. Mohammad Naeed
Orthopedist
MBBS, FCPS, MS - O..">Dr. Mohammad Naeed
Orthopedist
MBBS, FCPS, MS - O..</option>
	  <option value="Dr. Mohammad Saleem
Orthopedist
MBBS, FRCS, FRCS, ..">Dr. Mohammad Saleem
Orthopedist
MBBS, FRCS, FRCS, ..</option>
	  <option value="Dr. Ashraf Awais
Orthopedist
MBBS, FRCS - Ortho..">Dr. Ashraf Awais
Orthopedist
MBBS, FRCS - Ortho..</option>
	   <option value="Dr. Javed Iqbal Khan
Orthopedist
MBBS, FCPS - Ortho..">Dr. Javed Iqbal Khan
Orthopedist
MBBS, FCPS - Ortho..</option>
	  <option value="Dr. Syed Basharat Ali
Orthopedist
MBBS, FCPS - Ortho..">Dr. Syed Basharat Ali
Orthopedist
MBBS, FCPS - Ortho..</option>
	  <option value="Dr. Khalid Tanveer Ahmed
Orthopedist
MBBS, MS - Orthope..">Dr. Khalid Tanveer Ahmed
Orthopedist
MBBS, MS - Orthope..</option>
	  <option value="Dr. Javed Iqbal
Orthopedist
MBBS, FRCS - Ortho..">Dr. Javed Iqbal
Orthopedist
MBBS, FRCS - Ortho..</option>
	  <option value="Dr. Munir Hussain Col.(R)
Orthopedist
MBBS, FRCS, FICS -.">Dr. Munir Hussain Col.(R)
Orthopedist
MBBS, FRCS, FICS -.</option>
	   <option value="Dr. Aftab Ahmed
Orthopedist
MBBS, FRCS - Ortho..">Dr. Aftab Ahmed
Orthopedist
MBBS, FRCS - Ortho..</option>
	  <option value="Dr. Hasan Aftab Ahmed
Orthopedist
MBBS, FRCS - Ortho..">Dr. Hasan Aftab Ahmed
Orthopedist
MBBS, FRCS - Ortho..</option>
	  <option value="Dr. Naseer Akhtar
Orthopedist
MBBS, FRCS - Ortho..">Dr. Naseer Akhtar
Orthopedist
MBBS, FRCS - Ortho..</option>
	  <option value="Dr. Rizwan Naseer
Orthopedist
MBBS, MS, FAOI, FI..">Dr. Rizwan Naseer
Orthopedist
MBBS, MS, FAOI, FI..</option>
	  <option value="Dr. Ijaz Goraya
Orthopedist
MBBS - Orthopedist">Dr. Ijaz Goraya
Orthopedist
MBBS - Orthopedist</option>
	   <option value="Dr. Mohammad Ashraf Owais
Orthopedist
MBBS, FRCS - Ortho..">Dr. Mohammad Ashraf Owais
Orthopedist
MBBS, FRCS - Ortho..</option>
	  <option value="Dr. M. Arif Hassan Khan
Orthopedist
MBBS, FRCS, MCH. -..">Dr. M. Arif Hassan Khan
Orthopedist
MBBS, FRCS, MCH. -..</option>
	  <option value="Dr. Naseer Mehmood
Orthopedist
MBBS, FRCS - Ortho..">Dr. Naseer Mehmood
Orthopedist
MBBS, FRCS - Ortho..</option>
	  <option value="Dr. Rana Ikmal Khan
Orthopedist
MBBS, MD, FRCS - O..">Dr. Rana Ikmal Khan
Orthopedist
MBBS, MD, FRCS - O..</option>
	  <option value="Dr. Pervaiz Iqbal
Orthopedist
MBBS, FCPS - Ortho..">Dr. Pervaiz Iqbal
Orthopedist
MBBS, FCPS - Ortho..</option>
	   <option value="Dr. Afzal Hussain
Orthopedist
MBBS, FCPS - Ortho..">Dr. Afzal Hussain
Orthopedist
MBBS, FCPS - Ortho..</option>
	  <option value="Dr. Muneer Hussain
Orthopedist
MBBS, MS, FRCS, FR..">Dr. Muneer Hussain
Orthopedist
MBBS, MS, FRCS, FR..</option>
	  <option value="Dr. Kamaran Ahmed
Orthopedist
MBBS, FRCS - Ortho..">Dr. Kamaran Ahmed
Orthopedist
MBBS, FRCS - Ortho..</option>
	  <option value="Dr. Javed Iqbal
Orthopedist
MBBS, FRCS - Ortho..">Dr. Javed Iqbal
Orthopedist
MBBS, FRCS - Ortho..</option>
	  <option value="Dr. Dilawaize Nadeem
Orthopedist
MBBS, FRCS, MCH, F..">Dr. Dilawaize Nadeem
Orthopedist
MBBS, FRCS, MCH, F..</option>
	   <option value="Dr. Khurram Saadat
Orthopedist
MBBS, FRCS - Ortho..">Dr. Khurram Saadat
Orthopedist
MBBS, FRCS - Ortho..</option>
	  <option value="Dr. S.M. Hussain Andarabi
Orthopedist
MBBS, MCPS, FCPS, ..">Dr. S.M. Hussain Andarabi
Orthopedist
MBBS, MCPS, FCPS, ..</option>
	  <option value="Dr. Samiullah Bajwa
Orthopedist
FRCS Edin-U.K, M.S..">Dr. Samiullah Bajwa
Orthopedist
FRCS Edin-U.K, M.S..</option>
	  <option value="Dr. Iqbal Bhutta
Orthopedist
MBBS, MS - Orthope..">Dr. Iqbal Bhutta
Orthopedist
MBBS, MS - Orthope..</option>
	  <option value="Dr. Ahsan Shamim
Orthopedist
MBBS, FRCS - Ortho..">Dr. Ahsan Shamim
Orthopedist
MBBS, FRCS - Ortho..</option>
	   <option value="Dr. Ghazanfar Ali Shah
Orthopedist
MD, FRCS, FACS, FI..">Dr. Ghazanfar Ali Shah
Orthopedist
MD, FRCS, FACS, FI..</option>
	  <option value="Dr. Dr Saba
Orthopedist
MBBS - Orthopedist">Dr. Dr Saba
Orthopedist
MBBS - Orthopedist</option>
	  <option value="Dr. Mohammad Masood Ehsan
Orthopedist
MBBS, FRCS - Ortho..">Dr. Mohammad Masood Ehsan
Orthopedist
MBBS, FRCS - Ortho..</option>
	  <option value="ORTHODONTIST IN HOSPITALS"><b>ORTHODONTIST IN HOSPITALS</b></option>
	  <option value="Dr Ammar Pasha Siddiqui
Orthodontist
FCPS">Dr Ammar Pasha Siddiqui
Orthodontist
FCPS</option>
	   <option value="Waqar Jeelani
Orthodontist
BDS, FCPS">Waqar Jeelani
Orthodontist
BDS, FCPS</option>
	  <option value="Dr Awais Afridi
Orthodontist
BDS (RDS)">Dr Awais Afridi
Orthodontist
BDS (RDS)</option>
	  <option value="Waheed Ullah Khan
Orthodontist
FCPS">Waheed Ullah Khan
Orthodontist
FCPS</option>
	  
	  
   </div>
  </select>
	 <br />
	 <!--
	
     <label>Check the Dr. Info</label>
	
     
	 <div class="input-group">
	   <select name="gender" id="gender" class="form-control">
	   <span class="input-group-addon" id="inputGroupPrepend"><i class="fa fa-question-circle"></i></span>
     
      
     <input type="text" name="Dr_Info" id="Dr_Info" class="form-control" />
	 <option value="Male">Male</option>  
      <option value="Female">Female</option>
	 </select>
     </div>
  
	 <br />
	 -->
	 
	 <label>Choose Speciality</label>
	 
     <select name="Dr_Info" id="Dr_Info" class="form-control">
	 <option value="">Choose Speciality</option>
	 
      <option value="Allergy Speciality">Allergy Speciality</option>  
      <option value="Andrologist">Andrologist</option>
	  <option value="Anesthethist">Anesthethist</option>
	  <option value="Audiologist">Audiologist</option>
	  <option value="Bone Mero">Bone Mero</option>
	  <option value="Cardiac Surgeon">Cardiac Surgeon</option>
	    <option value="Cardiologist">Cardiologist</option>
	  <option value="Chiropractor">Chiropractor</option>
	  <option value="Cosmetic Surgeon">Cosmetic Surgeon</option>
	  <option value="Dentist">Dentist</option>
	    <option value="Dermatologist">Dermatologist</option>
	  <option value="Dietitian/Nutritionist">Dietitian/Nutritionist</option>
	  <option value="Edocrinologist">Edocrinologist</option>
	  <option value="Endourologist">Endourologist</option>
	  
	    <option value="Ent Surgeon">Ent Surgeon</option>
	  <option value="Ent Specialist">Ent Specialist</option>
	  <option value="Ent Surgeon">Ent Surgeon</option>
	  <option value="Eye Specialist">Eye Specialist</option>
	  <option value="Gastroenterologist">Gastroenterologist</option>
	   <option value="General Surgeon">General Surgeon</option>
	    <option value="Geneticist">Geneticist</option>
		 <option value="Gynecologist">Gynecologist</option>
	   <option value="Hematologist">Hematologist</option>
	    <option value="Hijama Specialist">Hijama Specialist</option>
		 <option value="Hemoopath">Hemoopath</option>
	   <option value="Infectious Diseases">Infectious Diseases</option>
	    <option value="Inter Medicine">Inter Medicine</option>
		 <option value="Interventional Cardiologist">Interventional Cardiologist</option>
	   <option value="Laproscopic Surgeon">Laproscopic Surgeon</option>
	    <option value="Liver Specialist">Liver Specialist</option>
		<option value="Lung Surgeon">Lung Surgeon</option>
			<option value="Nephrologist">Nephrologist</option>
				<option value="Neuro Surgeon">Neuro Surgeon</option>
					<option value="Oncologist">Oncologist</option>
					<option value="Oral And Maxillofacial Surgeon">Oral And Maxillofacial Surgeon</option>
			<option value="Orthopedic Surgeon">Orthopedic Surgeon</option>
				<option value="Paediatric Radiologist">Paediatric Radiologist</option>
					<option value="Pain Specialist">Pain Specialist</option>
					<option value="Pathologist">Pathologist</option>
			<option value="Pediatric Cardiologist">Pediatric Cardiologist</option>
				<option value="Paediatric Cardiac Surgeon">Paediatric Cardiac Surgeon</option>
					<option value="Pediatrician">Pediatrician</option>
					<option value="Physical Therapist">Physical Therapist</option>
					<option value="Physiotherapist">Physiotherapist</option>
					<option value="Plastic Surgeon">Plastic Surgeon</option>
					<option value="Psychiatrist">Psychiatrist</option>
					<option value="Psychologist">Psychologist</option>
					<option value="Rehabilition Medicine">Rehabilition Medicine</option>
					<option value="Sexologist">Sexologist</option>
					<option value="Speech Therapist">Speech Therapist</option>
					<option value="Urologic">Urologic</option>
					<option value="Urologist ">Urologist</option>
					<option value="Vascular Surgeon">Vascular Surgeon</option>
					
	  
	  
     </select>
        
    
     <label>Get Appointment Here </label>
	 <div class="input-group col-ml-12">
	   <span class="input-group-addon" id="inputGroupPrepend"><i class="fa fa-stethoscope"></i></span>
        
     <input type="text" name="Get_Appointment" id="Get_Appointment" class="form-control" />
     </div>

	 
	 
     <input type="submit" name="insert" id="insert" value="Insert" class="btn btn-success" />

    </form>
   </div>
   <div class="modal-footer">
    <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
   </div>
  </div>
 </div>
</div>

 

<div id="dataModal" class="modal fade">
 <div class="modal-dialog">
  <div class="modal-content">
   <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">&times;</button>
    <h4 class="modal-title">Doctor Details</h4>
   </div>
   <div class="modal-body" id="doctors_detail">
    
   </div>
   <div class="modal-footer">
    <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
   </div>
  </div>
 </div>
</div>

<script>  
$(document).ready(function(){
 $('#insert_form').on("submit", function(event){  
  event.preventDefault();  
  if($('#Dr_Info').val() == "")  
  {  
   alert("Check the doctor info");  
  }  
  else if($('#Get_Appointment').val() == '')  
  {  
   alert("Get Appointment here ");  
  }  
  
  else if($('#Enter_Name').val() == '')  
  {  
   alert("Enter_Name ");  
  }  
  
   
  else  
  {  
   $.ajax({  
    url:"insert_doctor.php",  
    method:"POST",  
    data:$('#insert_form').serialize(),  
    beforeSend:function(){  
     $('#insert').val("Inserting");  
    },  
    success:function(data){  
     $('#insert_form')[0].reset();  
     $('#add_data_Modal').modal('hide');  
     $('#doctors_table').html(data);  
    }  
   });  
  }  
 });




 $(document).on('click', '.view_data', function(){
  //$('#dataModal').modal();
  var user_id = $(this).attr("id");
  $.ajax({
   url:"select_doctor.php",
   method:"POST",
   data:{user_id:user_id},
   success:function(data){
    $('#doctors_detail').html(data);
    $('#dataModal').modal('show');
   }
  });
 });
});  
 </script>



