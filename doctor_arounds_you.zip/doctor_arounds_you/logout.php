<?php
session_start();
include("includes/db.php");


header('location:admin.php');


session_destroy();
echo "<script>window.open('index.php','_self')</script>";
?>


