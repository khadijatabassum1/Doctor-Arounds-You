<?php
include("includes/db.php");
$query = "SELECT * FROM users ORDER BY id DESC";
$result = mysqli_query($con, $query);

?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Doctor Arounds You</title>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-T8Gy5hrqNKT+hzMclPo118YTQO6cYprQmhrYwIiQ/3axmI1hQomh7Ud2hPOy8SP1" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">






	
	</head>
<body>
<div class="bgimg">
<div class="header">
<nav class="navbar navbar-expand-md bg-dark navbar-dark fixed-top">
<div class="container">
<a href="home1.php" class="navbar-brand text-danger font-weight-bold"  ><h2><b>Doctor Arounds You</h2></b></a>

<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsenavber">
<span class="navbar-toggler-icon">
</span>
 </button>
 <div class="collapse navbar-collapse text-center " id="collapsenavber">
 <!-- ml-auto means margin left auto-->
 <ul class="navbar-nav ml-auto">
  <li class="nav-item">
 <a href="home1.php" class="nav-link text-white">Home</a>
 </li>
 
   <li class="nav-item">
 <a href="about_us.php" class="nav-link text-white">About Us</a>
 </li>
 <li class="nav-item">
 <a href="admin.php" class="nav-link text-white">Admin</a>
 </li>
 <li class="nav-item">
 <a href="doctor.php" class="nav-link text-white">Doctor</a>
 </li>
 <li class="nav-item">
 <a href="contact_us.php" class="nav-link text-white">Contact Us</a>
 </li>
  
 
   <li class="nav-item">
 <a href="user.php" class="nav-link text-white">User</a>
 <ul> <a href="contact_us.php" >Contact Us</a>
 </ul>
 </li>
  <li class="nav-item">
 <a href="index.php" class="nav-link text-white">Logout</a>
 </li>
 
 </ul>
 </div>
</div>
</div>

</nav>



<br /><br />  
  <div class="container" style="width:700px;">  
   <br>
   <br /> 
 <br>
   <br /> 
 <br>
   <br />    
   <div class="table-responsive">
    <div align="right">
     <button type="button" name="age" id="age" data-toggle="modal" data-target="#add_data_Modal" class="btn btn-warning">Add</button>
    </div>
    <br />
    <div id="users_table">
     <table class="table table-bordered">
      <tr>
       <th width="70%">User Name</th>  
       <th width="30%">View</th>
      </tr>
      <?php
	
      while($row = mysqli_fetch_array($result))
      {
      ?>
      <tr>
       <td><?php echo $row["Enter_Name"]; ?></td>
       <td><input type="button" name="view" value="view" id="<?php echo $row["id"]; ?>" class="btn btn-info btn-xs view_data" /></td>
      </tr>
      <?php
      }
      ?>
     </table>
    </div>
   </div>  
  </div>

<br /><br /> 
<br /><br />
<br /><br />
<br /><br />
<br /><br />
<br /><br /> 
<br /><br />
<br /><br />
<br /><br />
<br /><br />
<br /><br />
<br /><br />
<br /><br />
<br /><br />
<br /><br />





<!--fixed footer-->
<div class="navbar navbar-inverse navbar-fixed-bottom" role="navigation">
<div class="container">
<div class="navbar-text pull-left">


<h6 class="text-center">&copy; 2019, Design by Khadija Tabassum</h6>
 </div>
 <div class="navbar-text pull-right">
 <a href="https://www.facebook.com/"><i class="fa fa-facebook-square fa-2x"></i></a>
 <a href="https://twitter.com/Twitter"><i class="fa fa-twitter fa-2x"></i></a>
<a href="https://plus.google.com/discover"><i class="fa fa-google-plus fa-2x"></i></a>
</div>
</div>
</div>





</body>
</html>


<div id="add_data_Modal" class="modal fade">
 <div class="modal-dialog" >
  <div class="modal-content">
   <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">&times;</button>
	<br>
<br>
<br>
<br>
<br>
<br>
<br>

   
   </div>
   <br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
   
   <div class="row">
<div class="container">
    <div class="row vertical-offset-100">
	<div class = "col-md-4 col-ml-auto" >
		
	</div>

<div class="col-md-4 ">
    		<div class="panel panel-default" >
			  	<div class="panel-heading">
			    	<b><h2 class="panel-title " style="color:pink;">User</b></h2>
			 	</div>
				
   <div class="modal-body">
    <form method="post" id="insert_form" width="100%">
	
	<div class="row">
	 <label>Enter User Name</label>
	 <div class="input-group ">
	   <span class="input-group-addon" id="inputGroupPrepend"><i class="glyphicon glyphicon-user"></i></span>
      
     <input type="text" name="Enter_Name" id="Enter_Name" class="form-control" />
     </div>
	 </div>
  
	 <br />
     
	<div class="row">
     <label>Give Feed_back</label>
	 <div class="input-group col-ml-12">
	   <span class="input-group-addon" id="inputGroupPrepend"><i class="fa fa-comments-o"></i></span>
      
     <input type="text" name="Feed_back" id="Feed_back" class="form-control" />
     
	  </div>
	 <!--For feedback-->
  <span class="fa fa-star checked" onmouseover="starmark(this)" onclick=""starmark(this) id="1one" style="font-size:40px;courser:pointer;" ></span> 
  <span class="fa fa-star checked" onmouseover="starmark(this)" onclick=""starmark(this) id="2one" style="font-size:30px;courser:pointer;" ></span> 
  <span class="fa fa-star checked" onmouseover="starmark(this)" onclick=""starmark(this) id="3one" style="font-size:20px;courser:pointer;" ></span> 
  <span class="fa fa-star checked" onmouseover="starmark(this)" onclick=""starmark(this) id="4one" style="font-size:10px;courser:pointer;" ></span> 
  </div>
	 <br />
     

 <div class="row">
	<label>Change Location</label>
	
     <select name="Change_Location" id="Change_Location" 	 class="form-control" >
	 <option value="">Select Location</option>
	 <option value="Ravi">Ravi</option>
	  <option value="Kot Begum (UC 1)">Kot Begum (UC 1)</option>
	   <option value="Kot Mohibbu (UC 2)">Kot Mohibbu (UC 2)</option>
	    <option value="Azizabad (UC 3)">Azizabad (UC 3)</option>
		 <option value="Faisal Bagh (UC 4)">Faisal Bagh (UC 4)</option>
		  <option value="Qaiser (UC 5)">Qaiser (UC 5)</option>
	  <option value="Dhair (UC 6)">Dhair (UC 6)</option>
	   <option value="Shahdara Bagh (UC 7)">Shahdara Bagh (UC 7)</option>
	    <option value="Jia Musa (UC 8)">Jia Musa (UC 8)</option>
		 <option value="Qila Lachhman Singh (UC 9)">Qila Lachhman Singh (UC 9)</option>
		  <option value="Palmandi (UC 10)">Palmandi (UC 10)</option>
	  <option value="Siddiquepura (UC 11)">Siddiquepura (UC 11)</option>
	   <option value="Bangali Bagh (UC 12)">Bangali Bagh (UC 12)</option>
	    <option value="Siddiqia (UC 13)">Siddiqia (UC 13)</option>
		 <option value="Bhamman (UC 14)">Bhamman (UC 14)</option>
		  <option value="Shalamar">Shalamar</option>
	  <option value="Bhaghatpura (UC 15)">Bhaghatpura (UC 15)</option>
	   <option value="Gujjarpura (UC 16)">Gujjarpura (UC 16)</option>
	    <option value="Rehmatpura (UC 17)">Rehmatpura (UC 17)</option>
		 <option value="Begampura (UC 18)">Begampura (UC 18)</option>
		  <option value="Chah Miran (UC 19)">Chah Miran (UC 19)</option>
	  <option value="Bilal Bagh (UC 20)">Bilal Bagh (UC 20)</option>
	   <option value="Makhanpura (UC 21)">Makhanpura (UC 21)</option>
	    <option value="Kot Khawaja Saeed (UC 22)">Kot Khawaja Saeed (UC 22)</option>
		 <option value="Shad Bagh (UC 23)">Shad Bagh (UC 23)</option>
		  <option value="Wassanpura (UC 24)">Wassanpura (UC 24)</option>
	  <option value="Faiz Bagh (UC 25)">Faiz Bagh (UC 25)</option>
	   <option value="Farooqganj (UC 26)">Farooqganj (UC 26)</option>
	    <option value="Crown Park (UC 33)">Crown Park (UC 33)</option>
		 <option value="Madhu Lal Hussain (UC 34)">Madhu Lal Hussain (UC 34)</option>
		  <option value="Muhammad (UC 35)">Muhammad (UC 35)</option>
	  <option value="Baghbanpura (UC 36)">Baghbanpura (UC 36)</option>
	   <option value="Angori Bagh (UC 46)">Angori Bagh (UC 46)</option>
	    <option value="Mujahidabad (UC 47)">Mujahidabad (UC 47)</option>
		 <option value="Daroghawala (UC 42)">Daroghawala (UC 42)</option>
		  <option value="Muhammad (UC 37)">Muhammad (UC 37)</option>
	  <option value="Sultan Mehmood (UC 38)">Sultan Mehmood (UC 38)</option>
	   <option value="Dograi Kalan (UC 51)">Dograi Kalan (UC 51)</option>
	    <option value="Muslimabad (UC 39)">Muslimabad (UC 39)</option>
		 <option value="Salamatpura (UC 40)">Salamatpura (UC 40)</option>
		  <option value="Lakhodher (UC 49)">Lakhodher (UC 49)</option>
	  <option value="Bhaseen (UC 50: Batapur)">Bhaseen (UC 50: Batapur)</option>
	   <option value="Minhala (UC 53)">Minhala (UC 53)</option>
	    <option value="Barki (UC 62)">Barki (UC 62)</option>
		 <option value="Hadiara (UC 65: Ghurki)">Hadiara (UC 65: Ghurki)</option>
		  <option value="Aziz Bhatti">Aziz Bhatti</option>
	  <option value="Harbanspura (UC 41)">Harbanspura (UC 41)</option>
	   <option value="Rashidpura (UC 43)">Rashidpura (UC 43)</option>
	    <option value="Fatehgarh (UC 44)">Fatehgarh (UC 44)</option>
		 <option value="Nabipura (UC 45)">Nabipura (UC 45)</option>
		  <option value="Mughalpura (UC 48)">Mughalpura (UC 48)</option>
	  <option value="Mian Meer (UC 54)">Mian Meer (UC 54)</option>
	   <option value="Mustafabad (UC 55)">Mustafabad (UC 55)</option>
	    <option value="Ghaziabad (UC 56)">Ghaziabad (UC 56)</option>
		 <option value="Tajbagh (UC 57)">Tajbagh (UC 57)</option>
		  <option value="Tajpura (UC 58)">Tajpura (UC 58)</option>
	  <option value="Al Faisal (UC 59)">Al Faisal (UC 59)</option>
	   <option value="Guldasht (UC 60)">Guldasht (UC 60)</option>
	    <option value="Bhangali (UC 61)">Bhangali (UC 61)</option>
		 <option value="Kasurpura (UC 67)">Kasurpura (UC 67)</option>
		 <option value="Ameenpura (UC 68)">Ameenpura (UC 68)</option>
	   <option value="Kareem Bagh (UC 69)">Kareem Bagh (UC 69)</option>
	    <option value="Ganj Kalan (UC 70)">Ganj Kalan (UC 70)</option>
		 <option value="Bilalganj (UC 71)">Bilalganj (UC 71)</option>
		 <option value="Anarkali (UC 72)">Anarkali (UC 72)</option>
	   <option value="Gawalmandi (UC 73)">Gawalmandi (UC 73)</option>
	    <option value="Sare Sultan (UC 74)">Sare Sultan (UC 74)</option>
		 <option value="Qila Gujar Singh (UC 77)">Qila Gujar Singh (UC 77)</option>
		 <option value="Race Course Park (UC 78)">Race Course Park (UC 78)</option>
	   <option value="Mozang (UC 79)">Mozang (UC 79)</option>
	    <option value="Jinnah Hall (UC 80: Islampura, Krishan Nagar)
">Jinnah Hall (UC 80: Islampura, Krishan Nagar)</option>
		 <option value="Rizwan Bagh (UC 81)">Rizwan Bagh (UC 81</option>
		 <option value="Islam Pura (UC 82)">Islam Pura (UC 82)</option>
	   <option value="Chohan Bagh (UC 83)">Chohan Bagh (UC 83)</option>
	    <option value="Sanda (UC 85)">Sanda (UC 85)</option>
		 <option value="Sanda Khurd (UC 86)">Sanda Khurd (UC 86)</option>
		 <option value="Shadman (UC 94)">Shadman (UC 94</option>
	   <option value="Railway Colony (UC 31)">Railway Colony (UC 31)</option>
	    <option value="Daras Barey Mian (UC 32)">Daras Barey Mian (UC 32)</option>
		 <option value="Bibi Pak Daman (UC 75)">Bibi Pak Daman (UC 75)"</option>
		 <option value="Garhi Shahu (UC 76)">Garhi Shahu (UC 76)</option>
	   <option value="Al Hamra (UC 95)">Al Hamra (UC 95)</option>
	    <option value="Zaman Park (UC 96: Mayo Gardens)">Zaman Park (UC 96: Mayo Gardens)</option>
		 <option value="Gulberg (UC 97)">Gulberg (UC 97)</option>
		 <option value="Makkah (UC 98)">Makkah (UC 98)</option>
	   <option value="Naseerabad (UC 99)">Naseerabad (UC 99)</option>
	    <option value="Garden Town (UC 126)">Garden Town (UC 126)</option>
		 <option value="Model Town (UC 127)">Model Town (UC 127)</option>
		 <option value="Faisal Town (UC 128: Mochi Pura)">Faisal Town (UC 128: Mochi Pura)</option>
	   <option value="Liaqatabad (UC 129)">Liaqatabad (UC 129)</option>
	    <option value="Kot Lakhpat (UC 130)">Kot Lakhpat (UC 130)</option>
		 <option value="Pindi Rajputan (UC 131)">Pindi Rajputan (UC 131)</option>
		 <option value="Samanabad">Samanabad</option>
	   <option value="Abu Bakar Siddique (UC 84)">Abu Bakar Siddique (UC 84)</option>
	    <option value="Shamnagar (UC 87)">Shamnagar (UC 87)</option>
		 <option value="Gulgasht (UC 88)">Gulgasht (UC 88)</option>
		 <option value="Gulshan-e-Ravi (UC 89)">Gulshan-e-Ravi (UC 89)</option>
	   <option value="Babu Sabu (UC 90)">Babu Sabu (UC 90)</option>
	    <option value="Rizwan Park (UC 91)">Rizwan Park (UC 91)</option>
		 <option value="Sodiwal (UC 92)">Sodiwal (UC 92)</option>
		 <option value="Bahawalpur (UC 93: Islamia Park)">Bahawalpur (UC 93: Islamia Park)</option>
	   <option value="Ichhra (UC 100)">Ichhra (UC 100)</option>
	    <option value="Naya Samanabad (UC 101)">Naya Samanabad (UC 101)</option>
		 <option value="Shah Jamal (UC 102)">Shah Jamal (UC 102)</option>
		 <option value="Pakki Thatti (UC 103)">Pakki Thatti (UC 103)</option>
	   <option value="Gulshan-e-Iqbal (UC 108)">Gulshan-e-Iqbal (UC 108)</option>
	    <option value="Kashmir (UC 104)">Kashmir (UC 104)</option>
		 <option value="Rehmanpura (UC 107)">Rehmanpura (UC 107)</option>
		 <option value="Nawan Kot (UC 105)">Nawan Kot (UC 105)</option>
	   <option value="Samanabad (UC 106)">Samanabad (UC 106)</option>
	    <option value="Muslim Town (UC 115)">Muslim Town (UC 115)</option>
		 <option value="Iqbal">	Iqbal</option>
		 <option value="Awan Town (UC 110: Hassan Town)">Awan Town (UC 110: Hassan Town)</option>
	   <option value="Saidpur (UC 111)">Saidpur (UC 111)</option>
	    <option value="Sabzazar (UC 112)">Sabzazar (UC 112)</option>
		 <option value="Canal (UC 113)">Canal (UC 113)</option>
		 <option value="Bakar Mandi (UC 114)">Bakar Mandi (UC 114)</option>
	   <option value="Johar Town (UC 116)">Johar Town (UC 116)</option>
	    <option value="Hanjarwal (UC 117: Mansoorah,">Hanjarwal (UC 117: Mansoorah,Education Town)</option>
		 <option value="Niaz Beg (UC 118)">Niaz Beg (UC 118)</option>
		 <option value="Shahpur (UC 119)">Shahpur (UC 119)</option>
	   <option value="Ali Raza Abad (UC 120: ACHS, Wapda)">Ali Raza Abad (UC 120: ACHS, Wapda)</option>
	    <option value="Chung (UC 121)">Chung (UC 121)</option>
		 <option value="Maraka (UC 122: Bahria Town, Sukh Chayn Gardens)">Maraka (UC 122: Bahria Town, Sukh Chayn Gardens)</option>
		 <option value="Shamke Bhattian (UC 123)">Shamke Bhattian (UC 123)</option>
	   <option value="Sultanke (UC 124: Jati Umra)">Sultanke (UC 124: Jati Umra)</option>
	    <option value="Manga (UC 125)">Manga (UC 125)</option>
		 <option value="Township (UC 132, UC 133)">Township (UC 132, UC 133)</option>
		 <option value="Paji (UC 148)">Paji (UC 148)</option>
	   <option value="Dholanwal (UC 149: Raiwind)">Dholanwal (UC 149: Raiwind)</option>
	    <option value="Kamahan (UC 63)">Kamahan (UC 63)</option>
		 <option value="Hair (UC 64)">Hair (UC 64)</option>
		 <option value="Dhaloke (UC 66)">Dhaloke (UC 66)</option>
	   <option value="Bostan (UC 134)">Bostan (UC 134)</option>
	    <option value="Ismailnagar (UC 135)">Ismailnagar (UC 135)</option>
		 <option value="Sitara (UC 136)">Sitara (UC 136)</option>
		 <option value="Farid (UC 137)">Farid (UC 137)</option>
	   <option value="Keer Kalan (UC 138)">Keer Kalan (UC 138)</option>
	    <option value="Green Town (UC 139)">Green Town (UC 139)</option>
		 <option value="Maryam (UC 140)">Maryam (UC 140)</option>
		 <option value="Attari Saroba (UC 141)">Attari Saroba (UC 141)</option>
	   <option value="Dullo Khurd Kalan (UC 142)">Dullo Khurd Kalan (UC 142)</option>
	    <option value="Chandrai (UC 143)">Chandrai (UC 143)</option>
		 <option value="Haloke (UC 144: Valencia, NFCHS)">Haloke (UC 144: Valencia, NFCHS)</option>
		 <option value="Gajju Matta (UC 145)">Gajju Matta (UC 145)</option>
	   <option value="Kahna Nau (UC 146)">Kahna Nau (UC 146)</option>
	    <option value="Jia Bagga (UC 147)">Jia Bagga (UC 147)</option>
		 <option value="Pandoke (UC 150: Ladheke)">Pandoke (UC 150: Ladheke)</option>
		 <option value="Punjab Society Near Dha">Punjab Society Near Dha</option>
	   <option value="DHA 1">DHA 1</option>
	    <option value="DHA 4">DHA 4</option>
		 <option value="DHA 7">DHA 7</option>
		 <option value="DHA 2">	DHA 2</option>
	   <option value="Askrai Villa 1">Askrai Villa 1</option>
	    <option value="Askrai Villa 2">Askrai Villa 2</option>
		 <option value="Askrai Villa 3">Askrai Villa 3</option>
		 <option value="Askrai Villa 4">Askrai Villa 4</option>
	   <option value="Askrai Villa 5">Askrai Villa 5</option>
	    <option value="Askrai Villa 6">Askrai Villa 6</option>
		 <option value="Askrai Villa 7">Askrai Villa 7</option>
		 <option value="Askrai Villa 8">Askrai Villa 8</option>
	   <option value="Askrai Villa 9">Askrai Villa 9</option>
	    <option value="Askrai Villa 10">Askrai Villa 10</option>
		 <option value="LUMS">LUMS</option>
		 <option value="Cantt">Cantt</option>
	   <option value="Gulberg 1">Gulberg 1</option>
	    <option value="Gulberg 2">Gulberg 2</option>
		 <option value="Gulberg 3">Gulberg 3</option>
		 <option value="Gor I">Gor I</option>
	   <option value="Gor II">Gor II</option>
	    <option value="Gor III">Gor III</option>
		 <option value="Gor IV">Gor IV</option>
		 <option value="Gor V">Gor V</option>
	   <option value="Jubli Town">Jubli Town</option>
	    <option value="Saddar">Saddar</option>
		 <option value="Khursheed Alam Road">Khursheed Alam Road</option>
		 <option value="Hamdard Chowk">Hamdard Chowk</option>
	   <option value="Samia Town">Samia Town</option>

	
</div>
	 </select>
	 

     
     
	 <br />  
<!--
	 <div class="row">
	<label>Change Location</label>
	<select name="Enter_Name" id="Enter_Name" class="form-control">
	
      <option value=""></option>
	  <option value=""></option>
	  <option value=""></option>
	  <option value=""></option>
	  <option value=""></option>
	  
   </div>
  </select>
	 <br />
	 	 -->
	 <label>Select Hospital</label>
	
     <select name="Hospitals" id="Hospitals" 	 class="form-control" >
	 <option value="">Types</option>
		 <b><option value="General Hospital">General Hospital</b></option>
		 <option value="	
Al - Shafi Hospital">	
Al - Shafi Hospital</option>
		 	 <option value="
Ammar Medical Complex">
Ammar Medical Complex</option>
			 	 <option value="
Avicenna Medical College & Hospital">
Avicenna Medical College & Hospital</option>
				 	 <option value="	
Bajwa Hospital">	
Bajwa Hospital</option>
					 	 <option value="	
Bodevolution Aesthetic Clinic">	
Bodevolution Aesthetic Clinic</option>
						 	 <option value="Cavalry Hospital">Cavalry Hospital
</option>
							 		 <option value=""></option>
		 	 <option value="
Chaudhry Rehmat Ali Memorial Trust Hospital">
Chaudhry Rehmat Ali Memorial Trust Hospital</option>
			 	 <option value="
Combined Military Hospital">
Combined Military Hospital</option>
				 	 <option value="	
ConfiDental">	
ConfiDental</option>
					 	 <option value="	
Contours">	
Contours</option>
						 	 <option value="	
De Dental Pro">	
De Dental Pro</option>
							 		 <option value="Dental & Medical Curatives - Dental Implant Center">Dental & Medical Curatives - Dental Implant Center</option>
		 	 <option value="
Dental Art">
Dental Art</option>
			 	 <option value="
Dental Hub
Clinic">
Dental Hub
Clinic</option>
				 	 <option value="	
Dental Services">	
Dental Services</option>
					 	 <option value="	
Dental Square">	
Dental Square</option>
						 	 <option value="Dental Works">Dental Works</option>
							 		 <option value="Dr. Zafar & Associates Dental Practice, Saadan Hospital">Dr. Zafar & Associates Dental Practice, Saadan Hospital</option>
		 	 <option value="Family Hospital">Family Hospital</option>
			 	 <option value="	
Fatima Memorial Hospital">	
Fatima Memorial Hospital</option>
				 	 <option value="Farooq Hospital">Farooq Hospital</option>
					 	 <option value="
Fatima Memorial Hospital">
Fatima Memorial Hospital</option>
						 	 <option value="Fauji Foundation Hospital">Fauji Foundation Hospital</option>
							 <option value="Ganga Ram Hospital">Ganga Ram Hospital</option>
				 	 <option value="Genesis Healthcare Consultants">Genesis Healthcare Consultants</option>
					 	 <option value="Ghurki Hospital">Ghurki Hospital</option>
						 	 <option value="Hameed Latif Hospital">Hameed Latif Hospital</option>
							 <option value="Hamza Hospital">Hamza Hospital</option>
				 	 <option value="	
Heart Medical & Dental Hospital Clinic">	
Heart Medical & Dental Hospital Clinic</option>
					 	 <option value="	
Hijaz Hospital">	
Horizon Hospital</option>
						 	 <option value=""></option>
							 <option value=""></option>
				 	 <option value=""></option>
					 	 <option value=""></option>
						 	 <option value=""></option>
	 
	 </div>
	 </select>
	
	

	 <br /> 
	 
	
	  <label> Set Your Appointment. </label>
	 <div class="input-group  ">
	   <span class="input-group-addon" id="inputGroupPrepend"><i class="fa fa-cog"></i></span>
        
     <input type="text" name="Appointment_Setting" id="Appointment_Setting" class="form-control" />
     </div>


	 <br />  
	
	   
     
	 
     <input type="submit" name="insert" id="insert" value="Insert" class="btn btn-success" />
	 

    </form>
   </div>
   <div class="modal-footer">
    <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
   </div>
  </div>
 </div>
</div>

 

<div id="dataModal" class="modal fade">
 <div class="modal-dialog">
  <div class="modal-content">
   <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">&times;</button>
    <h4 class="modal-title">User Details</h4>
   </div>
   <div class="modal-body" id="users_detail">
    
   </div>
   <div class="modal-footer">
    <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
   </div>
  </div>
 </div>
</div>

</div>
<!--For Rating App-->
<script type="text/javascript">
var rating="";
function starmark(item)
{
	var count=item.id[0];
	rating=count;
	var subid=item.id.substring(1);
	for(var i=0;i<5;i++)
		{
		if(i<count)
		{
              document.getElementById((i+1)+subid).style.color="orange";
		}
else
{
document.getElementById((i+1) +subid).style.color="black";

    }	
  }
	
 }
 
 function showRating()
 {
	 
	 alert(rating);
 }


</script>


<script>  
$(document).ready(function(){
 $('#insert_form').on("submit", function(event){  
  event.preventDefault();  
  if($('#Enter_Name').val() == "")  
  {  
   alert("Name is required");  
  }  
  else if($('#Change_Location').val() == '')  
  {  
   alert("Change your location");  
  }  
  else if($('#Hospitals').val() == '')
  {  
   alert("Check your Hospitals");  
  }
  else if($('#Appointment_Setting').val() == '')
  {  
   alert("Set your Appointment");  
  }
   
  else  
  {  
   $.ajax({  
    url:"insert_user.php",  
    method:"POST",  
    data:$('#insert_form').serialize(),  
    beforeSend:function(){  
     $('#insert').val("Inserting");  
    },  
    success:function(data){  
     $('#insert_form')[0].reset();  
     $('#add_data_Modal').modal('hide');  
     $('#users_table').html(data);  
    }  
   });  
  }  
 });




 $(document).on('click', '.view_data', function(){
  //$('#dataModal').modal();
  var user_id = $(this).attr("id");
  $.ajax({
   url:"select_user.php",
   method:"POST",
   data:{user_id:user_id},
   success:function(data){
    $('#users_detail').html(data);
    $('#dataModal').modal('show');
   }
  });
 });
});  
 </script>
