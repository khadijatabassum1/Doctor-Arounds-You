<?php
class Database
{
	private $host="localhost";
	private  $username="root";
	private   $password="";
	private $db_name="doctor_arounds_you";
	public $con;
	
	//get the database connection
	public function getConnection()
	{
		$this->con==null;
		try{
			
			
			$this->con=new PDO("mysql:host=". $this->host.  ";dbname=" . $this->db_name, $this->username, $this->password);
            $this->con->exec("set names utf8");
}
catch(PDOException $exception)
{
	echo "connection error:" . $exception->getMessage();
}

return $this->con;
    }
}
$con=mysqli_connect("localhost","root","","doctor_arounds_you");



?>