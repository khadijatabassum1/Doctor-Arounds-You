
<?php

session_start();
include("includes/db.php");

	$query = "SELECT * FROM comments ORDER BY id DESC";
$result = mysqli_query($con, $query);





?>



<!DOCTYPE html>
<html lang="en">
<head>
  <title>Doctor Arounds You</title>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-T8Gy5hrqNKT+hzMclPo118YTQO6cYprQmhrYwIiQ/3axmI1hQomh7Ud2hPOy8SP1" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">

	
	</head>
<body style="background-color:#f5f5f5;">

<div class="header">
<nav class="navbar navbar-expand-md bg-dark navbar-dark fixed-top">
<div class="container">
<a href="home1.php" class="navbar-brand text-danger font-weight-bold"  ><h2><b>Doctor Arounds You</h2></b></a>

<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsenavber">
<span class="navbar-toggler-icon">
</span>
 </button>
 <div class="collapse navbar-collapse text-center " id="collapsenavber">
 <!-- ml-auto means margin left auto-->
 <ul class="navbar-nav ml-auto">
  <li class="nav-item">
 <a href="home1.php" class="nav-link text-white">Home</a>
 </li>
 
  
 
   <li class="nav-item">
  
 <a href="about_us.php" class="nav-link text-white">About Us</a>

 
 </li>
 <li class="nav-item">
 <a href="admin.php" class="nav-link text-white">Admin</a>
 </li>
 <li class="nav-item">

 <a href="doctor.php" class="nav-link text-white">Doctor</a>
  <ul> <a href="doctors_lists.php" >Doctor List</a>
   
 </ul>
 </li>
 <li class="nav-item">
 <a href="contact_us.php" class="nav-link text-white">Contact Us</a>
 </li>
  
 
   <li class="nav-item">
 <a href="user.php" class="nav-link text-white">User</a>
 </li>
  <li class="nav-item">
 <a href="index.php" class="nav-link text-white">Logout</a>
 </li>
 
 </ul>
 </div>
</div>
</div>
</nav>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<div class="container">
  <div class="row">
 
    <div class="col-sm">
   
	  <div class="btn-group col-ml-12" >
  <button type="button" class="btn btn-lg btn-danger">Acupuncturist</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr.Mohammed Mohsin
Acupuncturist
M.B.B.S, M.D(U.S.A..</a>
	<a class="dropdown-item " href="#">Dr. Saima Naeem
Acupuncturist
Acupuncturist Cons..</a>
	<a class="dropdown-item " href="#">Prof. Dr. Rifat Hashmi
Acupuncturist
M.D(M.A); M.D(Hom)..</a>
	<a class="dropdown-item " href="#">Abul Samad Khan Kakar
Acupuncturist</a>
	<a class="dropdown-item " href="#">Dr. Jaffry Zameer Hussain
Acupuncturist</a>
	<a class="dropdown-item " href="#">Dr. Nighat Tahira
Acupuncturist</a>
	<a class="dropdown-item " href="#">Dr. Rehana Usman Khan
Acupuncturist</a>
	<a class="dropdown-item " href="#">Dr. Muhammad Shafique
Acupuncturist</a>
	<a class="dropdown-item " href="#">Dr. S. Kaniz Abidi
Acupuncturist</a>
	<a class="dropdown-item " href="#">Dr Khalil
Acupuncturist
consultant acupunc</a>
<a class="dropdown-item" href="#">Sulman Ali
Acupuncturist</a>
 <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="doctor_specility.php">Comments Here</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item " href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
  </div>
    
	
  
	</div>
	
    <div class="col-sm">
     
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">Chest Physician</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Zaheer Akhtar Prof.
Chest Physician
FCPS, FCCP, USA</a>
 <div class="dropdown-divider"></div>
	
    <a class="dropdown-item active" href="doctor_specility.php">Comments Here</a>
    
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
   </div>
    </div>
	
	
	
	
    <div class="col-sm">
    
	  
	  <div class="btn-group ">
  <button type="button" class="btn btn-lg btn-danger">Allergist</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr. Asif Ali Imam
Allergist M.B.B.S.</a>
	 <div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="doctor_specility.php">Comments Here</a>
   
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
    </div>
	 </div>
  </div>
</div>

<br>
<br>
<br>

<div class="container">
  <div class="row">
 
    <div class="col-sm">
   
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">Andrologist</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr. Tanveer Ahmad
Breast Surgeon
MBBS</a>
	<a class="dropdown-item " href="#">Dr. Andleeb Khanam
Breast Surgeon
MBBS,FCPS</a>
	<a class="dropdown-item " href="#">Saeed Afridi
Cardiac Surgeon
MBBS, MD, MS, FACS</a>
	<a class="dropdown-item " href="#">Dr. Imran Khan
Cardiac Surgeon
MBBS, FCPS (cardia..</a>
	<a class="dropdown-item " href="#">Dr. Naeem Shah
Cardiac Surgeon
MBBS, MD (Rom) - C..</a>
	<a class="dropdown-item " href="#">Dr. Fayyaz Haidar Hashmi
Cardiac Surgeon
MD, FACS - Cardiac..</a>
	<a class="dropdown-item " href="#">Dr. Khalid Hameed
Cardiac Surgeon
MBBS, FRCS - Cardi..</a>
	<a class="dropdown-item " href="#">Dr. Mohammad Abdullah Jan
Cardiac Surgeon
MD , DAB - Cardiac..</a>
	<a class="dropdown-item " href="#">Dr. Mohammad Sarwar
Cardiac Surgeon
MBBS, M ACP. FACC ..</a>
	<a class="dropdown-item " href="#">Dr. Mubashar A.Chaudhry
Cardiac Surgeon
MD, FACC , DAB(Car..</a>
    <a class="dropdown-item" href="#">Dr. Rehan Mehmood
Cardiac Surgeon
MBBS, MD DAB - Car..</a>
<a class="dropdown-item " href="#">Prof. Ashraf A.Khan
Cardiac Surgeon
MD, FACC , DAB - C..</a>
	<a class="dropdown-item " href="#">Dr. Nasir Iqbal Butt
Cardiac Surgeon
MB, Dip Card , MAS..</a>
	<a class="dropdown-item " href="#">Dr. Mohsin Nazir
Cardiac Surgeon
MBBS, FCPS, (Card)..</a>
	<a class="dropdown-item " href="#">Dr. Irshad Hussain
Cardiac Surgeon
MBBS, FCPS - Cardi..</a>
	<a class="dropdown-item " href="#">Dr. Shahid Malik
Cardiac Surgeon
MBBS, FRCS - Cardi..</a>
	<a class="dropdown-item " href="#">Dr. Bilal Zakariah Khan
Cardiac Surgeon
MBBS, MRCP(UK) - C..</a>
	<a class="dropdown-item " href="#">Dr. M. Ashraf
Cardiac Surgeon
MBBS, MCPS, M.Sc -..</a>
	<a class="dropdown-item " href="#">Dr. Mukhtar Ahmad
Cardiac Surgeon
MBBS, FRCS - Cardi..</a>
	<a class="dropdown-item " href="#">Dr. Saulat Siddique
Cardiac Surgeon
MBBS, MRCP. (UK) -..</a>
	<a class="dropdown-item " href="#">Dr. Najam Ayub Minhas
Cardiac Surgeon
MBBS, Dip, Card FI..</a>
    <a class="dropdown-item" href="#">Dr. Ismat Khan
Cardiac Surgeon
MBBS, D.Card , DTM..</a>
	<a class="dropdown-item " href="#">Dr. Zarar Hussain Shah
Cardiac Surgeon
MBBS, Dip Card , M..</a>
	<a class="dropdown-item " href="#">Dr. Shahbaz Sarwar
Cardiac Surgeon
MBBS, Dip Card (pk..</a>
	<a class="dropdown-item " href="#">Dr. Ansar Haider
Cardiac Surgeon
MBBS, Dip Card , F..</a>
	<a class="dropdown-item " href="#">Dr. Ajmal Hassan
Cardiac Surgeon</a>
	<a class="dropdown-item " href="#">"Dr. Abdul Waheed
Cardiac Surgeon
MBBS, FCPS, - Card..</a>
	<a class="dropdown-item " href="#">Dr. Liaqat Ali
Cardiac Surgeon
MBBS, FCPS, - Card..</a>
	<a class="dropdown-item " href="#">Dr. M.A Cheema
Cardiac Surgeon
MBBS, FRCS , FCPS,..</a>
	<a class="dropdown-item " href="#">Dr. Mohammad Ayub
Cardiac Surgeon
MBBS, FCPS, - Card..</a>
	<a class="dropdown-item " href="#">"Dr. A. Hafeez Khan
Cardiac Surgeon
MBBS, FRCS , FCPS,..</a>
	<a class="dropdown-item " href="#">Dr. Mohammad Yahya
Cardiac Surgeon
MBBS, FRCS (Edin)D..</a>
    <a class="dropdown-item" href="#">Dr. Raja Pervaiz Akhtar
Cardiac Surgeon
MBBS, FRCS - Cardi..</a>
	<a class="dropdown-item" href="#">Dr. Afzal Najeeb
Cardiac Surgeon
MBBS, FRCP - Cardi.</a>
	<a class="dropdown-item" href="#">Dr. Guhlam Shabir Yazdani
Cardiac Surgeon
MBBS, Dip, Card - ..
	</a><a class="dropdown-item" href="#">Dr. Mushtaq Shahid
Cardiac Surgeon
MBBS, FCPS, , Dip ..
	</a><a class="dropdown-item" href="#">Dr. Nasir Butt
Cardiac Surgeon
MBBS, Dip Card - C..</a>
	<a class="dropdown-item" href="#"></a>
    <a class="dropdown-item" href="doctor_specility.php">Comments Here</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item " href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
  </div>
    
	
  
	</div>
	
    <div class="col-sm">
     
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">Child Specialist</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Major (retd) Dr Suneel ..
Child Specialist
M.B.B.S,D.C.H,PGPN</a>
	 <a class="dropdown-item " href="#">Dr Waseem Pasha
Child Specialist
MBBS, DCH, PGPN (U..</a>
	   <a class="dropdown-item " href="#">Dr Rahat Malik
Child Specialist
M.B.B.S (fmc), M.C..</a>
	 <a class="dropdown-item " href="#">Dr Muhammad Faheem CH
Child Specialist
MBBS, DCH</a>
	   <a class="dropdown-item " href="#">Dr Irshad Hasan Khan
Child Specialist
MBBS, DCH</a>
	 <a class="dropdown-item " href="#">Dr. Abid Faryad
Child Specialist
MBBS,FCPS</a>
 <div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="doctor_specility.php">Comments Here</a>

    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
   </div>
    </div>
	
	
	
	
    <div class="col-sm">
    
	  
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">Dental Surgeon</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr Aqib Mudassar
Dental Surgeon
DDS</a>
	 <a class="dropdown-item " href="#">Dr.Tauqir Warsi
Dental Surgeon
Mbbs.England Speci..</a>
	 <a class="dropdown-item " href="#">Dr Tauqir Kamboh
Dental Surgeon
M.bb.s Canada brom..</a>
	 <a class="dropdown-item " href="#">Dr Mahwish Mumtaz
Dental Surgeon
doctor of dental s.</a>
	 <a class="dropdown-item " href="#">Dr Naureen Sarwar
Dental Surgeon
MDS, MPhil, Diplom..</a>
	 <a class="dropdown-item " href="#">Dr Rashid Javaid
Dental Surgeon
B.D.S, M.Phil</a>
	 <a class="dropdown-item " href="#">Dr. Shoaib A. Kazi
Dental Surgeon
B.D.S, B.Sc, FCPS</a>
	 <a class="dropdown-item " href="#">Dr. Zahid Subhani
Dental Surgeon
BDS</a>
	 <a class="dropdown-item " href="#">Dr Zaheer Iqbal
Dental Surgeon
B.D.S</a>
	 <a class="dropdown-item " href="#">Dr Fahad Bajwa
Dental Surgeon
BDS,RDS,MHA</a>
 <div class="dropdown-divider"></div>
	
    <a class="dropdown-item active" href="doctor_specility.php">Coments Here</a>
   
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
    </div>
	 </div>
  </div>
</div>
<br>
<br>
<br>

<div class="container">
  <div class="row">
 
    <div class="col-sm">
   
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">DERMATOLOGIST </button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr. Sabrina Sohail
Dermatologist</a>
	<a class="dropdown-item " href="#">Dr Sayed Jawad Afzal
Dermatologist
MBBS,MCPS</a>
	<a class="dropdown-item " href="#">Dr. Iram Ashraf
Dermatologist
M.B.B.S, Dip Derm ..</a>
	<a class="dropdown-item " href="#">Dr. Muhammad Khawar Nazir
Dermatologist
MBBS, MS Dermatolo..</a>
	<a class="dropdown-item " href="#">Tariq Niaz Butt
Dermatologist
MBBS, D. Derm (UK)..</a>
	<a class="dropdown-item " href="#">Zarqa Taimor Suharwardy
Dermatologist
MBBS,FCPS</a>
	<a class="dropdown-item " href="#">Umer Mushtaq
Dermatologist
MBBS, FCPS (Dermat..</a>
	<a class="dropdown-item " href="#">Sehrish Ashraf
Dermatologist
MBBS, FCPS (Dermat..</a>
	<a class="dropdown-item " href="#">Uzma Akbar Mirza
Dermatologist
MBBS, Dip. DERM</a>
	<a class="dropdown-item " href="#">Zafar Ullah Khan
Dermatologist
MBBS, FCPS, CAAAAM..</a>
    <a class="dropdown-item" href="#">Usman Amiruddin
Dermatologist
MBBS, FCPS (Plasti..</a>
<a class="dropdown-item" href="">Saleha Zeeshan
Dermatologist
MBBS, MCPS</a>
<a class="dropdown-item " href="#">Qurat-ul-ain Sajida
Dermatologist
MBBS, MCPS (Dermat..</a>
	<a class="dropdown-item " href="#">"Dr. Faria Asad
Dermatologist
MBBS,FCPS</a>
	<a class="dropdown-item " href="#">DR. BURHAN ASHRAF
Dermatologist
MBBS</a>
	<a class="dropdown-item " href="#">Samina Kausar
Dermatologist
MBBS, MCPS</a>
	<a class="dropdown-item " href="#">Dr. Arif Rahim
Dermatologist</a>
	<a class="dropdown-item " href="#">Dr. Aly Feroze
Dermatologist</a>
	<a class="dropdown-item " href="#">Dr. Muhammad Luqman Ahmed
Dermatologist</a>
	<a class="dropdown-item " href="#">Dr. Maryam Rafat
Dermatologist</a>
	<a class="dropdown-item " href="#">Dr. Nabila Yusuf
Dermatologist</a>
	<a class="dropdown-item " href="#">Dr. Zahid Shahzad
Dermatologist</a>
    <a class="dropdown-item" href="#">Dr. A.Rafi Masood
Dermatologist</a>
	<a class="dropdown-item " href="#">Dr. Faryal Athar
Dermatologist
dip derm UK. membe..</a>
    <a class="dropdown-item" href="#">Dr. Attiya Mahboob
Dermatologist</a>
    <a class="dropdown-item" href="#">Dr. Khawar Khursheed
Dermatologist</a>
    <a class="dropdown-item" href="#">Dr. Naveed Shehzad Mrs
Dermatologist</a>
<a class="dropdown-item " href="#">Dr. Sohail Sheikh
Dermatologist</a>
	<a class="dropdown-item " href="#">Dr. Omar H.Shaikh
Dermatologist</a>
	<a class="dropdown-item " href="#">Dr. Haseeb Sajjad
Dermatologist</a>
	<a class="dropdown-item " href="#">Dr. Atif Kazami
Dermatologist</a>
	<a class="dropdown-item " href="#">Dr. Agha Nasrullah Khan
Dermatologist
MBBS .D. Derm - De..</a>
	<a class="dropdown-item " href="#">Dr. Khalid Mehmood
Dermatologist
MBBS D.D.V (Austri..</a>
	<a class="dropdown-item " href="#">Dr. Laquman Ahmad
Dermatologist
MBBS, FCPS - Derma..</a>
	<a class="dropdown-item " href="#">Dr. Muhammd Faisal Nawaz
Dermatologist
BSc, MBBS - Dermat..</a>
	<a class="dropdown-item " href="#">Dr. Ghazanfar Ilahi
Dermatologist
MBBS , D.Derm , M...</a>
	
	 <div class="dropdown-divider"></div>

    <a class="dropdown-item" href="doctor_specility.php">Comments Here</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item " href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
  </div>
    
	
  
	</div>
	
    <div class="col-sm">
     
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">DIABETOLOGISTS</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr. Asad Saeed
Diabetologists
MBBS, DABIM</a>
	<a class="dropdown-item " href="#">Dr. Tahir H.Malik
Diabetologists
MBBS, MRCP, DGM</a>
	<a class="dropdown-item " href="#">Dr. Raheel Akbar
Diabetologists</a>
	<a class="dropdown-item " href="#">Prof Zaheer Akhtar
Diabetologists
FCPS FCCP USA</a>
	<a class="dropdown-item " href="#">Jamal Bukhari
Diabetologists
Bsc, mbbs, fcps</a>
 <div class="dropdown-divider"></div>
	
    <a class="dropdown-item active" href="doctor_specility.php">Comments Here</a>
  
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
   </div>
    </div>
	
	
	
	
    <div class="col-sm">
    
	  
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">ENDOCRINOLOGIST </button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr. Zaar
Endocrinologist
MBBS, MD, PhD, FRC..</a>
	<a class="dropdown-item " href="#">Dr Fawad Ahmad Randhawa
Endocrinologist
MBBS, FCPS (Endocr..</a>
	<a class="dropdown-item " href="#">Maliha Hameed
Endocrinologist
MBBS, FCPS (Medici..</a>
	<a class="dropdown-item " href="#">Jaida Manzoor
Endocrinologist
MBBS, FCPS</a>
	<a class="dropdown-item " href="#">Amena Moazzam Baig
Endocrinologist
MBBS, MRCP, FCPS (..</a>
	<a class="dropdown-item " href="#">Gulshad Hasan
Endocrinologist
MBBS, MRCP (UK), F..</a>
	<a class="dropdown-item " href="#">Shehzad Ul Haq
Endocrinologist
MD, FACE, Diplomat..</a>
	<a class="dropdown-item " href="#">Dr. Raees Ahsan Mushtaq
Endocrinologist
MBBS,DIPLOMA IN DI..</a>
	<a class="dropdown-item " href="#">Dr. Imran Abdullah
Endocrinologist
M.B.BS. MS NUCLEAR..</a>
	<a class="dropdown-item " href="#">Dr.Syed Abbass Raza
Endocrinologist
MBBS - Endocrinolo..</a>
	<a class="dropdown-item " href="#">Dr.Muhammad Javaid Shah
Endocrinologist
M.B.B.S,M.SC,M.C.P.S</a>
    <a class="dropdown-item" href="#">Awais Masood
Endocrinologist
MBBS, Diplomate Am..</a>
<a class="dropdown-item " href="#">Muhammad Tabish Raza
Endocrinologist
MBBS,MD,(USA), FCP..</a>

 <div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="doctor_specility.php">Comments Here </a>
    
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
    </div>
	 </div>
  </div>
</div>

<br>
<br>
<br>

<div class="container">
  <div class="row">
 
    <div class="col-sm">
   
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">ENT SURGEON</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Ramzan Ali
ENT Surgeon
MD, FCPS (ENT)</a>
	<a class="dropdown-item " href="#">Ijaz Nazir
ENT Surgeon
MBBS, DLO</a>
	<a class="dropdown-item " href="#">Shahid Ghafoor Malik
ENT Surgeon
MBBS, FCPS</a>
	<a class="dropdown-item " href="#">Khurshid Alam
ENT Surgeon
F.R.C.S. ORL (UK)...</a>
	<a class="dropdown-item " href="#">Nasir Riaz
ENT Surgeon
MBBS, FCPS</a>
	<a class="dropdown-item " href="#">Taimoor Latif Malik
ENT Surgeon
MBBS, FCPS (ENT)</a>
	<a class="dropdown-item " href="#">Muhammad Awais Amin
ENT Surgeon
BSC, MBBS, FCPS (E..</a>
	<a class="dropdown-item " href="#">Dr. Ayub Ahmad Khan
ENT Surgeon
MBBS, MCPS (ENT), ..</a>
	<a class="dropdown-item " href="#">Dr Rashid Hameed
ENT Surgeon
MBBS,MCPS ,MS</a>
	<a class="dropdown-item " href="#">DR MUHAMMAD ARSHAD CHOH..
ENT Surgeon
MBBS-DLO</a>
    <a class="dropdown-item" href="#">Dr. Rashid Zia
ENT Surgeon
ENT CONSULTANT</a>
<a class="dropdown-item " href="#">Dr Mazhar Iftikhar
ENT Surgeon
MBBS,FCPS</a>
	<a class="dropdown-item " href="#">Dr Muhammad Ali Raza
ENT Surgeon
M.B;B.S. M.C.P.S (..</a>
	<a class="dropdown-item " href="#">Prof Zubair Ahmed
ENT Surgeon
MBBS, DLO.RCS (Lon..</a>
	<a class="dropdown-item " href="#">Dr Aqsa
ENT Surgeon</a>
	 <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="doctor_specility.php">Comments Here</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item " href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
  </div>
    
	
  
	</div>
	
    <div class="col-sm">
     
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">EYE SURGEON</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Muhammad Sufyan Aneeq A..
Eye Surgeon
MBBS, FCPS
	</a>
	<a class="dropdown-item " href="#">Syed Abdullah Mazhar
Eye Surgeon
MBBS, FCPS, MRCS</a>
	<a class="dropdown-item " href="#">Adeel Randhawa
Eye Surgeon
MBBS,MCPS, FCPS, (..</a>
	<a class="dropdown-item " href="#">Rashid Nawaz
Eye Surgeon
MBBS, MRCS (Optha ..</a>
	<a class="dropdown-item " href="#">Prof Huma Kayani
Eye Surgeon
MBBS, FCPS, FRCS (..</a>
	<a class="dropdown-item " href="#">Abdul Rauf
Eye Surgeon
MBBS, FCPS</a>
	<a class="dropdown-item " href="#">Waseem Iqbal
Eye Surgeon
MBBS, FCPS (ophth)..</a>
	<a class="dropdown-item " href="#">Dr Shamshad Ali
Eye Surgeon
MBBS, FCPS OPHTHA..</a>

    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="doctor_specility.php">Comments Here</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
   </div>
    </div>
	
	
	
	
    <div class="col-sm">
    
	  
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">FERTILITY SPECIALIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr. Mujahid Hussain
Fertility Specialist
MD PH D MISID (USA..</a>
	<a class="dropdown-item " href="#">Dr. Rashid Latief Khan
Fertility Specialist</a>
 <div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="doctor_specility.php">Comments Here </a>
    
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
    </div>
	 </div>
  </div>
</div>
<br>
<br>
<br>

<div class="container">
  <div class="row">
 
    <div class="col-sm">
   
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">GENERAL PHYSICIAN </button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr Shahzad Khurram Durr..
General Physician
MBBS</a>
	<a class="dropdown-item " href="#">Dr Ashfaq Naru
General Physician
MBBS</a>
	<a class="dropdown-item " href="#">Dr Mohammad Asif Hashmi
General Physician
MBBS</a>
	<a class="dropdown-item " href="#">Somia Iqtadar
General Physician
MBBS, FCPS (Medici..</a>
	<a class="dropdown-item " href="#">Nasir Siddique
General Physician
MBBS, MRCP (UK), F..</a>
	<a class="dropdown-item " href="#">Muhammad Ali
General Physician
MBBS, MRCGPS</a>
	<a class="dropdown-item " href="#">Fatima Hamdani
General Physician
MBBS, FCPS, MRCP(UK)</a>
	<a class="dropdown-item " href="#">Khizer Mehmood
General Physician
MBBS,MRCGP,PLAB (G..</a>
	<a class="dropdown-item " href="#">Atif Masood
General Physician
MBBS, FCPS (Medici..</a>
	<a class="dropdown-item " href="#">Farheen Kayani
General Physician
MBBS, MRCGP</a>
    <a class="dropdown-item" href="#">Prof Javed Akram
General Physician
MRCP (UK), FRCP (L..</a>
	<a class="dropdown-item" href="#">Waqas Cheema
General Physician
MBBS, FCPS</a>
	 <a class="dropdown-item" href="#">Ahmad Malik
General Physician
MBBS, MD (USA)</a>
	<a class="dropdown-item" href="#">Aisha Sheikh
General Physician
MBBS, MPhiL (Chemi..</a>
	<a class="dropdown-item" href="#">Dr Qurban Hussain
General Physician
MBBS, MRCP, FCPS (..</a>
	<a class="dropdown-item" href="#">Naeem Ashraf
General Physician
MBBS, MCPS ( Famil..</a>
	 <a class="dropdown-item " href="#">Dr Muhammad Jasra Bhatti
General Physician
MBBS FCPS BSc Assi..</a>
	  <a class="dropdown-item " href="#">Dr SYED ATA UL HALEEM
General Physician
M.B.B.S.</a>
	  <a class="dropdown-item " href="#">Dr Amjad Ali Parvez
General Physician</a>
	  <a class="dropdown-item " href="#">Dr Tariq Butt
General Physician</a>
	  <a class="dropdown-item " href="#">Anjum Saeed
General Physician</a>
	  <a class="dropdown-item " href="#">Dr.Syed Niaz Muhammad H..
General Physician</a>
	  <a class="dropdown-item " href="#">Dr ZAHID NISAR
General Physician
MBBS</a>
	  <a class="dropdown-item " href="#">Umair Saleem
General Physician
MBBS</a>
	  <a class="dropdown-item " href="#">Dr. Fouad Aslam
General Physician
BSc, MBBS</a>
	  <a class="dropdown-item " href="#">Dr. Azam Yousaf
General Physician</a>
	  <a class="dropdown-item " href="#">Dr. Yousaf Latif Khan
General Physician</a>
	  <a class="dropdown-item " href="#">Dr. Adil Iqbal
General Physician</a>
	  <a class="dropdown-item " href="#">Nadia Raj
General Physician</a>
	  <a class="dropdown-item " href="#">Dr. Syeda Mahida Ali
General Physician
MBBS</a>
	  <a class="dropdown-item " href="#">Dr. Rashid Iqbal
General Physician</a>
	  <a class="dropdown-item " href="#">Dr. Rehana Kanwal Mohal
General Physician</a>
	  <a class="dropdown-item " href="#">Dr. Madiha Kamal
General Physician
MBBS</a>
	  <a class="dropdown-item " href="#">Dr WAQAS AHMAD
General Physician
M.B.B.S.</a>
	  <a class="dropdown-item " href="#">DR. RAI M. AMMAR MADNI
General Physician
MBBS</a>
	  <a class="dropdown-item " href="#">Dr Rabia Atta Mohyuddin
General Physician
M.B.B.S.</a>
	  
	   <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="doctor_specility.php">Comments Here</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item " href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
  </div>
    
	
  
	</div>
	
    <div class="col-sm">
     
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">GENETICIST </button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Munir Ahmad Bhinder
Geneticist
MPHILL, PHD (Molec..</a>
 <div class="dropdown-divider"></div>
	 
    <a class="dropdown-item active" href="doctor_specility.php">Comments Here</a>
 
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
   </div>
    </div>
	
	
	
	
    <div class="col-sm">
    
	  
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">HAIR TRANSPLANT</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr. Azim Jahangir Khan
Hair Transplant</a>
 <div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="doctor_specility.php">Comments Here</a>
   
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
    </div>
	 </div>
  </div>
</div>

<br>
<br>
<br>

<div class="container">
  <div class="row">
 
    <div class="col-sm">
   
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">HEMATOLOGIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Ali Raza
Hematologist
MBBS. MPhil</a>
	<a class="dropdown-item " href="#">Dr. Nadia Sajid
Hematologist
MBBS,FCPS</a>
	<a class="dropdown-item " href="#">Dr. Abdul Hameed
Hematologist
MBBS, MRCP (UK), M..</a>
	<a class="dropdown-item " href="#">Dr Mona Aziz
Hematologist
MBBS.FCPS</a>
	<a class="dropdown-item " href="#">Dr. Abdul Hayae
Hematologist</a>
	
	 <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="doctor_specility.php">Comments Here</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item " href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
  </div>
    
	
  
	</div>
	
    <div class="col-sm">
     
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">HERBALIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr Muhammad Rizwan Arshad
Herbalist
Consultant Herbal</a>
	 <div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="doctor_specility.php">Comments Here </a>
   
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
   </div>
    </div>
	
	
	
	
    <div class="col-sm">
    
	  
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">INFECTIOUS DISEASE</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr. Naveed Rashid
Infectious Disease Specialist
MBBS, FCPS (Intern..</a>
	 <a class="dropdown-item " href="#">DR MUHAMMAD TAUSEEF JAVED
Infectious Disease Specialist
MBBS. DPH. PHil. F..</a>
	 <div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="doctor_specility.php">Comments Here</a>

    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
    </div>
	 </div>
  </div>
</div>

<br>
<br>
<br>

<div class="container">
  <div class="row">
 
    <div class="col-sm">
   
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">INTERNAL MEDICINE</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr. Nisar Haider Anjum
Internal Medicine
MBBS, FCPS</a>
	<a class="dropdown-item " href="#">Dr. Zeeshan Akhtar Wali
Internal Medicine
MBBS,FCPS (medicine)</a>
	<a class="dropdown-item " href="#">Dr. Sajid Mahmood Rana
Internal Medicine
MBBS, FCPS</a>
	<a class="dropdown-item " href="#">Dr Faisal Amin Baig
Internal Medicine
MBBS, FCPS</a>
	<a class="dropdown-item " href="#">Uzair Akbar Ali
Internal Medicine
MBBS, MRCP (Ireland)</a>
	<a class="dropdown-item " href="#">Sami Ullah Mumtaz
Internal Medicine
MBBS, FCPS (Medici..</a>
	<a class="dropdown-item " href="#">Tahir Islam
Internal Medicine
MBBS, MCPS, DTCD (..</a>
	<a class="dropdown-item " href="#">Dr. Altaf A Cheema
Internal Medicine</a>
	<a class="dropdown-item " href="#">Dr. Mazhar Ul Islam
Internal Medicine</a>
	<a class="dropdown-item " href="#">Dr. Ahmed Nadeem
Internal Medicine</a>
    <a class="dropdown-item" href="#">Dr Bilal Azeem Butt
Internal Medicine
FCPS</a>
 <a class="dropdown-item " href="#">Dr MUBASHAR SULTAN HASHMI
Internal Medicine
Fcps medicine</a>
	<a class="dropdown-item " href="#">Dr Asad Ullah Ijaz
Internal Medicine
MBBS, FCPS</a>
	<a class="dropdown-item " href="#">Dr Atiq Rehman
Internal Medicine
MRCP UK</a>
	<a class="dropdown-item " href="#">Zahabia Manzoor
Internal Medicine
mbbs, fcps</a>
	<a class="dropdown-item " href="#">Dr. Amir Aziz
Internal Medicine
MBBS, FRCS, FCPS -..</a>
	
    <a class="dropdown-item" href="doctor_specility.php">Comments Here</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item " href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
  </div>
    
	
  
	</div>
	
    <div class="col-sm">
     
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">NEONATOLOGIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr Muhammad Anwar
Neonatologist
MBBS, DCH, FCPS (P..</a>
	<a class="dropdown-item " href="#">Abdul Rehman
Neonatologist</a>
	<a class="dropdown-item " href="#">Prof Dr Zareen Fasih
Neonatologist
F.C.P.S. M.B.B.S. ..</a>
	<a class="dropdown-item " href="#">Dr. Farooq Khan
Neonatologist
(Physician) MBBS, ..</a>
	<a class="dropdown-item " href="#">Dr Ahmed Wali
Neonatologist
FCPS (Neurology), ..</a>
	
    <a class="dropdown-item active" href="doctor_specility.php">Comments Here</a>
 
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
   </div>
    </div>
	
	
	
	
    <div class="col-sm">
    
	  
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">NEURO PHYSICIAN</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr Rashid Imran
Neuro Physician
MBBS, FCPS (Neurol..</a>
	<a class="dropdown-item " href="#">Dr Rashid Imran
Neuro Physician
MBBS, FCPS (Neurol..</a>
	<a class="dropdown-item " href="#">Dr Muhammad Akbar Malik
Neuro Physician
MBBS, DCH, MCPS, F..</a>
	<a class="dropdown-item " href="#">Dr. Faheem Saeed
Neuro Physician
M.B.B.S.(K.E.), F...</a>
	<a class="dropdown-item " href="#">Dr MUHAMMAD ATHAR JAVED
Neuro Physician
M.B.B.S.</a>
	<a class="dropdown-item " href="#">Dr. Shahid Mukhtar
Neuro Physician
MBBS (KE) FCPS neu..</a>
	<a class="dropdown-item " href="#">Dr. Abubakar Siddique
Neuro Physician
MBBS. FCPS (Neurol..</a>
	 <div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="doctor_specility.php">Comments Here</a>
   
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
    </div>
	 </div>
  </div>
</div>

<br>
<br>
<br>

<div class="container">
  <div class="row">
 
    <div class="col-sm">
   
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">NEUROSURGEON</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Usman Ahmad Kamboh
Neurosurgeon
MBBS, FCPS (Neuro ..</a>
	<a class="dropdown-item " href="#">MUHAMMAD ADIL AMIN
Neurosurgeon
FCPS</a>
	<a class="dropdown-item " href="#">Prof Khalid Mehmood
Neurosurgeon
FRCS (Glasg) FRCS ..</a>
	<a class="dropdown-item " href="#">Professor Dr. Khalid Ma..
Neurosurgeon
FRCS, FRCS(SN)Glasg</a>
	<a class="dropdown-item " href="#">Dr Waqas Mehdi
Neurosurgeon
M.B.B.S, B.Sc, FCP..</a>
	<a class="dropdown-item " href="#">Dr. Yaser Uddin
Neurosurgeon
MBBS(PAK), M.D(USA..</a>
	<a class="dropdown-item " href="#">Dr Zahid Ullah Safi
Neurosurgeon
MD MS</a>
	<a class="dropdown-item " href="#">Dr. Asif Bashir
Neurosurgeon
MD, FACS, FAANS, A..</a>
	<a class="dropdown-item " href="#">Prof Dr Sabir H Bhatti ..
Neurosurgeon
MBBS, FCPS(Neurosu.</a>
	<a class="dropdown-item " href="#">Dr. Nazir Ahmed
Neurosurgeon
MBBS, MS. - Neuros..</a>
    <a class="dropdown-item" href="#">Prof. Shahzad Shams
Neurosurgeon
BSc, MBBS, FRCS, F..</a>
	<a class="dropdown-item " href="#">Dr. Atiq - Ur - Rehman ..
Neurosurgeon
MBBS, MD, DAB. - N..</a>
	<a class="dropdown-item " href="#">Dr. Shahzad Shams
Neurosurgeon
BSc, MBBS, FRCS, F..</a>
    <a class="dropdown-item" href="#">Dr. Naeem Ul Hameed
Neurosurgeon
MBBS, FRCP. - Neur..</a>
	<a class="dropdown-item " href="#">Dr. Naveed Ashraf
Neurosurgeon
MBBS, MS. - Neuros..</a>
	<a class="dropdown-item " href="#">Dr. Muhammad Zafar Iqbal
Neurosurgeon
MBBS, FCPS., FRCS ..</a>
    <a class="dropdown-item" href="#">Dr. Saeed A. Bajwa
Neurosurgeon
MD, FACS, DAB. - N..</a>
	<a class="dropdown-item " href="#">Dr. Rizwan Masood Butt
Neurosurgeon
MBBS, MD, FRCS, FC..</a>
	<a class="dropdown-item " href="#">Dr. Salman Asghar
Neurosurgeon
MBBS, FRCS - Neuro..</a>
    <a class="dropdown-item" href="#">Dr. Rizwan Masood Butt
Neurosurgeon
MBBS, MD, FRCS - N..</a>
	<a class="dropdown-item " href="#">Dr. M. Shahid Sial
Neurosurgeon
MBBS, MCPS. - Neur..</a>
	<a class="dropdown-item " href="#">Prof Dr Rizwan M Butt
Neurosurgeon
MBBS, MD, FCPS, FR..</a>
    <a class="dropdown-item" href="#">Dr. Nazir Ahmad
Neurosurgeon</a>
<a class="dropdown-item " href="#">Dr. Abdullah Haroon
Neurosurgeon
MBBS, FCPS. - Neur..</a>
	<a class="dropdown-item " href="#">Dr. Khalid Mehmood Butt
Neurosurgeon
MBBS, FRCS, - Neur..</a>
	<a class="dropdown-item " href="#">Dr. Kamran Hussain
Neurosurgeon
MBBS, FRCS - Neuro..</a>
	<a class="dropdown-item " href="#">Dr. Amer Ikram
Neurosurgeon
MBBS, DAB. - Neuro..</a>
	<a class="dropdown-item " href="#">"Dr. Khalid Hussain Abbas
Neurosurgeon
MBBS, FRCS - Neuro..</a>
	<a class="dropdown-item " href="#">Dr. Shahzad Shams
Neurosurgeon
MBBS - Neurosurgeon</a>
	<a class="dropdown-item " href="#">Dr. Javed Majeed Mian
Neurosurgeon
MBBS, MCPS, MS. - ..</a>
	<a class="dropdown-item " href="#">Dr. Shahzad Yousaf
Neurosurgeon</a>
	<a class="dropdown-item " href="#">Dr. Imran Masood
Neurosurgeon</a>
	<a class="dropdown-item " href="#">Dr. Iftikhar Ali Raja
Neurosurgeon
(FRCS) (late</a>
    <a class="dropdown-item" href="#">Dr. Malik Muhammad Nade..
Neurosurgeon
Consultant Pediatr..</a>

    <a class="dropdown-item " href="#">Dr. Khalid H. Abbas
Neurosurgeon
MBBS, FRCS - Neuro..</a>
	<a class="dropdown-item " href="#">Dr Amjad Ali
Neurosurgeon
M.B.B.S,FCPS</a>
	 <div class="dropdown-divider"></div>

    <a class="dropdown-item" href="doctor_specility.php">Comments Here</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item " href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
  </div>
    
	
  
	</div>
	
    <div class="col-sm">
     
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">ONCOLOGIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Najam Ul Hasan
Oncologist
MD, DICOR</a>
    <a class="dropdown-item " href="#">Syed Nasir Abbas Bukhari
Oncologist
MBBS(Pb).FCPS.DH(U..</a>
	<a class="dropdown-item " href="#">Amjad Shahbaz khan Durr..
Oncologist
MBBS,DMRT,AFSA</a>
	<a class="dropdown-item " href="#">Dr Muhammad Arif Ch.
Oncologist
Diplomate American..</a>
	<a class="dropdown-item " href="#">Dr. Rehan Abdullah
Oncologist
M.B.B.S. M.S. F.C...</a>
	<a class="dropdown-item " href="#">"Prof. Ghulam Sarwar
Oncologist</a>
	<a class="dropdown-item " href="#">Dr. Adeeba Quddus
Oncologist
MBBS, DAB - Oncolo..</a>
	<a class="dropdown-item " href="#">Dr. Akram Muslim
Oncologist
MBBS, DAB.I.M. - O..</a>
	<a class="dropdown-item " href="#">Dr. Alia Zaidi
Oncologist
MBBS, MRCP - Oncol..</a>
	<a class="dropdown-item " href="#">Dr. Mazhar Ali Shah
Oncologist
MBBS, DMRT - Oncol..</a>
	<a class="dropdown-item " href="#">Dr. Shahid Hameed
Oncologist
MBBS, DAB - Oncolo..</a>
    <a class="dropdown-item" href="#">Dr. Shakeeb Yunus
Oncologist
MBBS, DABIM - Onco..</a>
	<a class="dropdown-item " href="#">Dr. Rab Nawaz Maken
Oncologist
MBBS, MSc, FCPS - .</a>
    <a class="dropdown-item" href="#">Dr. Sheharyar
Oncologist
MBBS, MCPS, DMRT, ..</a>
    <a class="dropdown-item" href="#">Dr. Zeba Aziz
Oncologist
MBBS, MCPS, DMRT, ..</a>
    <a class="dropdown-item" href="#">Dr. Imtiaz Randhawa
Oncologist
MBBS, DMRT, GTC - ..</a>
    <a class="dropdown-item" href="#">Dr. Shahina Parveen
Oncologist
MBBS, MD, DMRT - O..</a>
    <a class="dropdown-item" href="#">Dr. Ghulam Sarwar
Oncologist
MBBS, DMRT, FICS -..</a>
    <a class="dropdown-item" href="#">Dr. Abdul Sami Qazi
Oncologist
MBBS, DMRT, MCPS, ..</a>
 <div class="dropdown-divider"></div>
   
    <div class="dropdown-divider" href="doctor_specility.php">Comments Here</div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
   </div>
    </div>
	
	
	
	
    <div class="col-sm">
    
	  
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">OPTOMETRIST </button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Rashid Asghar khan
Optometrist
BS in vision scien..</a>
	<a class="dropdown-item " href="#">Syed Waqas Naqvi
Optometrist
Doctor of Optometry</a>
	<a class="dropdown-item " href="#">Dr. Nasir Farid Sandila
Optometrist
Doctor of Optometry</a>
	<a class="dropdown-item " href="#">Dr Farman Barki
Optometrist
Doctor of optometry</a>
 <div class="dropdown-divider"></div>
	
    <a class="dropdown-item active" href="doctor_specility.php">Comments Here</a>
  
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
    </div>
	 </div>
  </div>
</div>

<br>
<br>
<br>

<div class="container">
  <div class="row">
 
    <div class="col-sm">
   
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">ORTHOPEDIC SURGEON</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Saeed Taj
Orthopedic Surgeon
FCPS</a>
	<a class="dropdown-item " href="#">Dr Mehdi Ali Mehdavi
Orthopedic Surgeon
M.B.B.S. FCPS(orth..</a>
	<a class="dropdown-item " href="#">Dr. Muhammad Abdul Basit
Orthopedic Surgeon
MBBS. Master of Su..</a>
	<a class="dropdown-item " href="#">Dr Umair Abu Bakar Siddiq
Orthopedic Surgeon
M.B;B.S (KEMU), FC..</a>
	<a class="dropdown-item " href="#">Dr Kamran Butt
Orthopedic Surgeon
MBBS,FRCS,DSM,RCP&..</a>
	<a class="dropdown-item " href="#">Dr. Atiq Durrani
Orthopedic Surgeon
MD, FAAOS, FACS, F..</a>
	<a class="dropdown-item " href="#">Mr Ahsan Alam
Orthopedic Surgeon
FRCSEd, FRCSI, FRC..</a>
	<a class="dropdown-item " href="#">Ahsan Alam
Orthopedic Surgeon
MBBS, FRCSEd, FRCS..</a>
	<a class="dropdown-item " href="#">Prof Dr M A Wajid
Orthopedic Surgeon
FRCS, FRCS(Tr & Or..</a>
	<a class="dropdown-item " href="#">Dr. Ghulam Abbas
Orthopedic Surgeon
F.R.C.S (UK). M.I...</a>
    <a class="dropdown-item" href="#">Dr. Imran Nausher
Orthopedic Surgeon
MBBS, FCPS</a>
<a class="dropdown-item " href="#">Dr Muhammad Bilal
Orthopedic Surgeon
MBBS, FCPS, FRCS (..</a>
	<a class="dropdown-item " href="#">Mohammad Bilal Raza
Orthopedic Surgeon
MBBS, FCPS, A.O. T..</a>
	<a class="dropdown-item " href="#">Usman Ahmed
Orthopedic Surgeon
MBBS, MS(ortho)</a>
	<a class="dropdown-item " href="#">Muhammad Noman raza
Orthopedic Surgeon
MBBS, FCPS (Tr & O..</a>
	<a class="dropdown-item " href="#">Syed Wasif Ali Shah
Orthopedic Surgeon
MBBS, FCPS (Orthop..</a>
	<a class="dropdown-item " href="#">Prof M A Wajid
Orthopedic Surgeon
FRCS(Tr & Orth) UK..</a>
	<a class="dropdown-item " href="#">Tariq Sohail
Orthopedic Surgeon
MBBS, M.ch.(Ortho)..</a>
	<a class="dropdown-item " href="#">Dr Rashid Saeed
Orthopedic Surgeon
MBBS, FCPS, FRCS</a>
	<a class="dropdown-item " href="#">Dr. Dilavaiz Nadeem
Orthopedic Surgeon</a>
	<a class="dropdown-item " href="#">Professor Aasim Malik
Orthopedic Surgeon</a>
    <a class="dropdown-item" href="#">Dr. (Maj Gen) S M H And..
Orthopedic Surgeon</a>
	<a class="dropdown-item " href="#">Dr. Abdullah Farooq Khan
Orthopedic Surgeon</a>
	<a class="dropdown-item " href="#">Prof. Dr.Naseer Mehmood..
Orthopedic Surgeon</a>
	<a class="dropdown-item " href="#">Dr Shafqat Waseem Chaud..
Orthopedic Surgeon
MBBS Fcps MD usa</a>
	<a class="dropdown-item " href="#">Dr. Shoaib Anwar
Orthopedic Surgeon
MBBS, FCPS</a>
	<a class="dropdown-item " href="#">"Dr. Talha Khan Niazi
Orthopedic Surgeon
MBBS, FCPS</a>
	<a class="dropdown-item " href="#">Dr. Afzal Hussain
Orthopedic Surgeon
MBBS, FCPS</a>
    <a class="dropdown-item" href="#">Dr. Abdullah Farooq
Orthopedic Surgeon
MBBS, MS, MRCS</a>
    <a class="dropdown-item" href="#">Faisal Qamar
Orthopedic Surgeon
MBBS, MRCS UK, FRC..</a>
	<a class="dropdown-item " href="#">Dr. Ali Raza Hashmi
Orthopedic Surgeon
MBBS - Orthpedic S..</a>
    <a class="dropdown-item" href="#">Dr. Rana Dilawaz Khan
Orthopedic Surgeon
MBBS - Orthpedic S..</a>
    <a class="dropdown-item" href="#">Dr. Dr. Faisal Mushtaq
Orthopedic Surgeon
FCPS (Orth) - Orth..</a>
	<a class="dropdown-item " href="#">"Dr. Atiq Uz Zaman
Orthopedic Surgeon
MBBS & FCPS (orth)..</a>
    <a class="dropdown-item" href="#">Prof. Amer Aziz
Orthopedic Surgeon
MBBS - FRCS - Dipl..</a>
    <a class="dropdown-item" href="#">Dr. Subhan Shahid
Orthopedic Surgeon
MBBS, FCPS, MCPS -..</a>
 <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="#">Comments Here</a>
    <div class="dropdown-divider" href="doctor_specility.php"></div>
    <a class="dropdown-item " href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
  </div>
    
	
  
	</div>
	
    <div class="col-sm">
     
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">OTHER</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr Fouzia Zaigham

MBBS</a>
	    <a class="dropdown-item " href="#">Dr. Imran Ahmed
Other
MBBS, MCPS, M.D</a>
	<a class="dropdown-item " href="#">Awais Amjad Malik

FCPS, Fellowship S..</a>
	<a class="dropdown-item " href="#">Atif Aslam
</a>
 <div class="dropdown-divider"></div>
	
    <a class="dropdown-item active" href="doctor_specility.php">Comments Here</a>
  
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
   </div>
    </div>
	
	
	
	
    <div class="col-sm">
    
	  
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">PAEDIATRIC SURGEON</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr. Rashid Zia
Paediatric Surgeon
MBBS, MRCP, FRCP, ..</a>
	    <a class="dropdown-item " href="#">Dr. Abid Quddus Qazi
Paediatric Surgeon
FRCS, FCPS (Paedia..</a>
	<a class="dropdown-item " href="#">Muhammad Ali Sheikh
Paediatric Surgeon
MBBS, FCPS (Paedia..</a>
	<a class="dropdown-item " href="#">Dr. Javed Iqbal
Paediatric Surgeon
MBBS, FRCS (Irelan..</a>
	<a class="dropdown-item " href="#">Syed Faisal Usman
Paediatric Surgeon
MBBS,FCPS</a>
	<a class="dropdown-item " href="#">Muhammad Javaid Iqbal K..
Paediatric Surgeon
M.B.B.S ; FCPS</a>
	<a class="dropdown-item " href="#">Malik Waqas
Paediatric Surgeon
MBBS, FCPS</a>
	<a class="dropdown-item " href="#">Mohammad Iqbal
Paediatric Surgeon
MBBS, DCH - Paedia..</a>
	<a class="dropdown-item " href="#">Dr. Mohammad Ali Khan
Paediatric Surgeon
MBBS, DCP, MRCP - ..</a>
	<a class="dropdown-item " href="#">Dr. Aja.Samdani
Paediatric Surgeon
MBBS, MD, DCH - Pa..</a>
	<a class="dropdown-item " href="#">Dr. Iqbal Ahmed Azhar
Paediatric Surgeon
MBBS, FCPS - Paedi.</a>
    <a class="dropdown-item" href="#">Dr. Tahira S. Izhar
Paediatric Surgeon
MBBS, DCH, MCPS - ..</a>
	<a class="dropdown-item " href="#">Dr. Maj Ghulam Abbas Ch
Paediatric Surgeon
MBBS(Pb).DCH.(Pb) ..</a>
    <a class="dropdown-item" href="#">Dr. Zia - Ul -Miraj
Paediatric Surgeon
MBBS, DCH, FRCS - ..</a>
	<a class="dropdown-item " href="#">Dr. Tariq Latif
Paediatric Surgeon
MBBS, FRCS - Paedi..</a>
    <a class="dropdown-item" href="#">Dr. Abdul Hameed
Paediatric Surgeon
MBBS, FRCS, FCPS, ..</a>
    <a class="dropdown-item" href="#">Dr. Mohammad Aslam Malik
Paediatric Surgeon
MBBS, DCH, MRCP - ..</a>
    <a class="dropdown-item" href="#">Dr. Mohammad Imran Mir
Paediatric Surgeon
MBBS, DCH, DCH - P..</a>
    <a class="dropdown-item" href="#">Dr. Haroon
Paediatric Surgeon
MBBS, FCPS - Paedi..</a>
    <a class="dropdown-item" href="#">Dr. Imran Yousaf
Paediatric Surgeon
MBBS, FRCS - Paedi..</a>
    <a class="dropdown-item" href="#">Dr. Fauzia Shaukat
Paediatric Surgeon
MBBS, MCPS, FCPS, ..</a>
    <a class="dropdown-item" href="#">Dr. Ali Atif Goheir
Paediatric Surgeon
MBBS, FRCS - Paedi..</a>
    <a class="dropdown-item" href="#">Dr. Muhammad Aslam Malik
Paediatric Surgeon
MBBS, DCH, MRCP - ..</a>
    <a class="dropdown-item" href="#">Dr. Muhammad Tariq Bhatti
Paediatric Surgeon
MBBS, MCPS, FCPS -..</a>
    <a class="dropdown-item" href="#">Dr. Muzammal Hussain Za..
Paediatric Surgeon
MBBS, FICP - Paedi..</a>
    <a class="dropdown-item" href="#">Dr. Muzammal Hussain Za..
Paediatric Surgeon
MBBS, FICP - Paedi..</a>
    <a class="dropdown-item" href="#">"Dr. Misbah Mubashar
Paediatric Surgeon
MBBS, DCH - Paedia..</a>
    <a class="dropdown-item" href="#">Dr. M. Islam Shahid
Paediatric Surgeon
MBBS, FCPS - Paedi..</a>
    <a class="dropdown-item" href="#">Dr. Parveen Zulfiqar
Paediatric Surgeon
MBBS, DCH - Paedia..</a>
    <a class="dropdown-item" href="#">Dr. Ghulam Sarwar
Paediatric Surgeon
MBBS, DCH - Paedia..</a>
<a class="dropdown-item " href="#">Dr. Zaheer Ul Haq Qureshi
Paediatric Surgeon
MBBS, DCH, MCPS - ..</a>
	<a class="dropdown-item " href="#">Dr. Ijaz Hussain Gilani
Paediatric Surgeon
MBBS, DCH -I - Pae..</a>
	<a class="dropdown-item " href="#">Dr. Khaliq Ahmed Qureshi
Paediatric Surgeon
MBBS, DCH - Paedia..</a>
	<a class="dropdown-item " href="#">Dr. Riffat - Ur - Rehman
Paediatric Surgeon
MBBS, FCPS - Paedi..</a>
	<a class="dropdown-item " href="#">Dr. Rao Muhammad Riaz U..
Paediatric Surgeon
MBBS, FCPS - Paedi..</a>
	<a class="dropdown-item " href="#">Dr. Mohammad Saeed Chau..
Paediatric Surgeon
MBBS, MCPS, MRCP -..</a>
	<a class="dropdown-item " href="#">Dr. Mohammad Shaukat
Paediatric Surgeon
MBBS, FRCS - Paedi..</a>
 <div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="doctor_specility.php">Comments Here</a>

    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
    </div>
	 </div>
  </div>
</div>

<br>
<br>
<br>

<div class="container">
  <div class="row">
 
    <div class="col-sm">
   
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">MAXILLOFACIAL SURGEON</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr Asad Aizaz Chatha
Maxillofacial Surgeon
BDS, FCPS, MDS, FF..</a>
	<a class="dropdown-item " href="#">Dr Gulraiz Zulfiqar
Maxillofacial Surgeon
BS,BDS,FCPS,FOCMF(..</a>
	<a class="dropdown-item " href="#">Dr. Ali Hassan Sajid
Maxillofacial Surgeon
B.D.S., F.C.P.S</a>
 <div class="dropdown-divider"></div>

    <a class="dropdown-item" href="doctor_specility.php">Comments Here</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item " href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
  </div>
    
	
  
	</div>
	
    <div class="col-sm">
     
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">LIVER SPECIALIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Hussam Ahmed
Liver Specialist
MBBS, MS (General ..</a>
 <a class="dropdown-item " href="#">Muhammad Zakria
Liver Specialist
MBBS, MRCS (UK), F..</a>
	<a class="dropdown-item " href="#">DR. ISRAR UL HAQ
Liver Specialist
MBBS, FCPS</a>
	<a class="dropdown-item " href="#">Dr. Muhammad Zahid Akba..
Liver Specialist
MBBS, FRCS (UK)</a>
 <div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="doctor_specility.php">Comments Here</a>

    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
   </div>
    </div>
	
	
	
	
    <div class="col-sm">
    
	  
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">WEIGHT LOSS SPECIALIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr Zafar Iqbal
Weight Loss Specialist
MD Alternative Med..</a>
	 <a class="dropdown-item " href="#">Dr. Zeeshan Tanweer
Weight Loss Specialist</a>
 <div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="doctor_specility.php">Comments Here</a>
  
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
    </div>
	 </div>
  </div>
</div>


<br>
<br>
<br>

<div class="container">
  <div class="row">
 
    <div class="col-sm">
   
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">UROLOGIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr. Fateh Khan Akhtar
Urologist
MBBS - Urologist</a>
	<a class="dropdown-item " href="#">Dr. Fawad Nasrullah
Urologist
MBBS, FCPS (Urolog..</a>
	<a class="dropdown-item " href="#">Athar Mehmood
Urologist
MBBS, FCPS</a>
	<a class="dropdown-item " href="#">Irfan Ahmed
Urologist
MBBS, FRCS, D.Urol</a>
	<a class="dropdown-item " href="#">Prof Zafar ul Ahsan
Urologist
MBBS, FRCS Surgery..</a>
	<a class="dropdown-item " href="#">"Khizer Hayat Gondal
Urologist
MBBS, FCPS, Traini..</a>
	<a class="dropdown-item " href="#">Hassan Raza Asghar
Urologist
MBBS, FCPS (Urology)</a>
	<a class="dropdown-item " href="#">Zahid Hussain
Urologist
MBBS, FCPS, F.A.C.S</a>
	<a class="dropdown-item " href="#">Muhammad Asif Baloch
Urologist
MBBS, FCPS (Urology)</a>
	<a class="dropdown-item " href="#">Dr. Asgharali Dogar
Urologist
MBBS - Urologist</a>
    <a class="dropdown-item" href="#">Dr. Mumtaz Ahmad
Urologist
MBBS - Urologist</a>
	<a class="dropdown-item " href="#">Dr. Kamran K. Cheema
Urologist
MBBS' FCPS</a>
	<a class="dropdown-item " href="#">Dr. Ahmad Salamanwaris
Urologist
MBBS - Urologist</a>
	<a class="dropdown-item " href="#">Prof. Khalid Javed Rabb..
Urologist
MBBS - Urologist</a>
	<a class="dropdown-item " href="#">Dr. Khalid Rabbani
Urologist
MBBS - Urologist</a>
	<a class="dropdown-item " href="#">Dr. Munir Amin Mughal
Urologist
MBBS - FRCS. DU</a>
	<a class="dropdown-item " href="#">Dr. Latif Qureshi
Urologist
MBBS - Urologist</a>
	<a class="dropdown-item " href="#">Dr. Manzoor Ahmad Malik
Urologist
MBBS - Urologist</a>
	<a class="dropdown-item " href="#">Dr. Rai Ijaz Ahmad Kharal
Urologist
MBBS - Urologist</a>
	<a class="dropdown-item " href="#">Dr. Zafar Ehsan
Urologist
MBBS - Urologist</a>
	<a class="dropdown-item " href="#">Dr. Mohammad I.Javaid
Urologist
MBBS - Urologist</a>
	<a class="dropdown-item " href="#">Dr. Sajjad Hussain
Urologist
MBBS - Urologis</a>
	<a class="dropdown-item " href="#">Dr. Dr. M. Sarfraz Ahmad
Urologist
MBBS - Urologist</a>
	<a class="dropdown-item " href="#">Dr. Zafar Ul Ahsan
Urologist
MBBS - Urologist</a>
	<a class="dropdown-item " href="#">Dr. Junaid Habib Khan
Urologist
MBBS - M.S (Urology)</a>
	<a class="dropdown-item " href="#">Brig Dr. Mohammad Ramza..
Urologist</a>
	<a class="dropdown-item " href="#">Dr. Asghar Ali Dogar
Urologist</a>
	<a class="dropdown-item " href="#">Dr. Muhammad Kaleem
Urologist</a>
	<a class="dropdown-item " href="#">Dr. Muhammad Khalid Butt
Urologist</a>
	<a class="dropdown-item " href="#">Dr. Shoukat Zubair
Urologist</a>
	<a class="dropdown-item " href="#">Dr. Zia Ul Miraj Ahmed
Urologist</a>
	<a class="dropdown-item " href="#">r. Ahmad Salaman Waris
Urologist</a>
	<a class="dropdown-item " href="#">Dr. Ehsan Ullah Khan
Urologist</a>
	<a class="dropdown-item " href="#">Dr. Mohammad I Javaid
Urologist</a>
	<a class="dropdown-item " href="#">Dr. Naveed Iqbal
Urologist</a>
 <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="doctor_specility.php">Comments Here</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item " href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
  </div>
    
	
  
	</div>
	
    <div class="col-sm">
     
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">TRAUMATOLOGIST </button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Syed Hasnain Raza Shirazi
Traumatologist
emergency medical ..</a>
     <div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="doctor_specility.php">Comments Here</a>
 
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
   </div>
    </div>
	
	
	
	
    <div class="col-sm">
    
	  
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">SPEECH THERAPIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Sana Asghar
Speech Therapist
BSc (hons) Speech .</a>
<a class="dropdown-item " href="#">Waqas Azeem
Speech Therapist
Ms-Speech and Lang..</a>
	<a class="dropdown-item " href="#">Mrs Mehak Murad
Speech Therapist
BS (hons) Speech a..</a>
	<a class="dropdown-item " href="#">Asia Nazir
Speech Therapist
M.Phil Speech lang..</a>
	<a class="dropdown-item " href="#">Hafsa Fiaz
Speech Therapist
MS Speech - Langua..</a>
	<a class="dropdown-item " href="#">Amna Ashraf
Speech Therapist
BSC.Hon,MS in Spee..</a>
	<a class="dropdown-item " href="#">Maria Awan
Speech Therapist
BS Speech and lang..</a>
	<a class="dropdown-item " href="#">Mrs. Uzma Rizwan
Speech Therapist
Masters in Special..</a>
	<a class="dropdown-item " href="#">Amna Ashraf
Speech Therapist
BSC Hons M.S Spee..</a>
	<a class="dropdown-item " href="#">Aqsa Waris
Speech Therapist
BS Speech Language..</a>
	<a class="dropdown-item " href="#">Iqra Naseer
Speech Therapist
Mphil Speech Langu..</a>
	<a class="dropdown-item " href="#">Saima Ashraf
Speech Therapist
Msc psychology, PG..</a>
	<a class="dropdown-item " href="#">Ms. Safa Pervaiz
Speech Therapist
Mphil Speech Langu..</a>
	<a class="dropdown-item " href="#">Ms.Rabia Azmat
Speech Therapist
BS (hons) speech a..</a>
	<a class="dropdown-item " href="#">Dr Fouzia Saleemi
Speech Therapist
MPhil speech langu..</a>
	<a class="dropdown-item " href="#">Anum Ashraf
Speech Therapist
BS-SLP (UHS), clin..</a>
	<a class="dropdown-item " href="#">Ghazal Awais
Speech Therapist
BS (Speech and lan..</a>
	<a class="dropdown-item " href="#">Sidra Ansar
Speech Therapist
MS in Speech and L..</a>
	<a class="dropdown-item " href="#">Razia Sultana

Speech Therapist</a>
	<a class="dropdown-item " href="#">Ms Samia Kanwal
Speech Therapist
BS(Speech and Lang..</a>
	<a class="dropdown-item " href="#">Iqra javaid
Speech Therapist
Bs speech and lang..</a>
	<a class="dropdown-item " href="#">Maria Ishtiaq
Speech Therapist
M.S Speech and lan..</a>
	<a class="dropdown-item " href="#">Rabia Naeem
Speech Therapist
Bs(hons) speech an..</a>
	<a class="dropdown-item " href="#">Nimra Nawaz
Speech Therapist
MS SLP (RIU) . BSc..</a>
 <div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="doctor_specility.php">Comments Here</a>

    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
    </div>
	 </div>
  </div>
</div>

<br>
<br>
<br>

<div class="container">
  <div class="row">
 
    <div class="col-sm">
   
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">SKIN SPECIALIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr Ahsan Kambob
Skin Specialist
M.b.b.s England Sp..</a>
	<a class="dropdown-item " href="#">Dr Tanveer Gillani
Skin Specialist</a>
	<a class="dropdown-item " href="#">Dr. Afshan K Siddiqui
Skin Specialist</a>
	<a class="dropdown-item " href="#">Dr. Abdussalam Cheema
Skin Specialist</a>
	<a class="dropdown-item " href="#">Dr. Sohail Asad
Skin Specialist</a>
	<a class="dropdown-item " href="#">Dr. Tariq Zaman
Skin Specialist</a>
	<a class="dropdown-item " href="#">Dr. A. Rafi Masood
Skin Specialist</a>
	<a class="dropdown-item " href="#">Dr. Naveed Shehzad Mrs
Skin Specialist</a>
	<a class="dropdown-item " href="#">Dr. Syed Ghulam Shabbir
Skin Specialist</a>
	<a class="dropdown-item " href="#">"Dr. Rizwantoor
Skin Specialist</a>
    <a class="dropdown-item" href="#">Dr. Mohammad Jamshaid B..
Skin Specialist</a>
	 <a class="dropdown-item" href="#">Dr. Omar H.Shaikh
Skin Specialist</a> 
	 
<a class="dropdown-item" href="#">Dr. Syed Atif Hasnain K..
Skin Specialist</a>
	 <a class="dropdown-item" href="#">Dr. Sabrina Sohail
Skin Specialist
	 </a> <a class="dropdown-item" href="#">Dr. Obaid-Ur-Rehman
Skin Specialist</a>
	 <a class="dropdown-item" href="#">Dr. Syed Ghulam Shabir
Skin Specialist
	 </a> <a class="dropdown-item" href="#">Dr. S. Atif Kazmi
Skin Specialist</a>
	 <a class="dropdown-item" href="#">Dr. Brig. (Retd) Syed M..
Skin Specialist</a> 
	 <a class="dropdown-item" href="#">Dr. Khawar Khursheed
Skin Specialist</a>
	 <a class="dropdown-item" href="#">Dr. Mohammad Idrees
Skin Specialist</a> 
	 <a class="dropdown-item" href="#">Dr. Haseeb Sajjad
Skin Specialist</a>
	 <a class="dropdown-item" href="#">Dr. Tahir Kamal
Skin Specialist</a> 
	 <a class="dropdown-item" href="#">Dr. Chaudhary Mohammad ..
Skin Specialist</a>
	 <a class="dropdown-item" href="#">Dr. H. A. Khawaja
Skin Specialist</a> 
	 <a class="dropdown-item" href="#">Dr. Mian Muhammad Muslim
Skin Specialist</a>
	 <a class="dropdown-item" href="#">Barig Naser Rasheed Dar
Skin Specialist
B.a</a> 
	 <a class="dropdown-item" href="#">Dr Tariq Niaz
Skin Specialist
MBBS,M,Derm (UK)</a>
	 <a class="dropdown-item" href="#">Dr Tariq Niaz
Skin Specialist
MBBS,MSc ,Derm (UK)</a> 
 <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="doctor_specility.php">Comments Here</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item " href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
  </div>
    
	
  
	</div>
	
    <div class="col-sm">
     
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">RHEUMATOLOGIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Tafazzul H. Mahmud MD
Rheumatologist
MB, MRCP (UK),FRCP..</a>
<a class="dropdown-item " href="#">Dr. Ruidong Zhang
Rheumatologist
Rheumatology Speci.</a>
	 <a class="dropdown-item " href="#">Dr Saba Saif
Rheumatologist
Mbbs fcps medicine..</a>
	 <a class="dropdown-item " href="#">Aamir Saeed
Rheumatologist
MRCP (Ire), MRCPS ..</a>
	 

   <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="doctor_specility.php">Comments Here</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
   </div>
    </div>
	
	
	
	
    <div class="col-sm">
    
	  
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">RADIOLOGIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr.Khalid Idrees
Radiologist
MBBS, FCPS (Radiol..</a>
	 <a class="dropdown-item " href="#">Tanveer Zubairi
Radiologist
MBBS, MCPS, Advanc..</a>
	 <a class="dropdown-item " href="#">Dr Rafia Asim
Radiologist
M.B.B.S. FCPS Radi..</a>
	 <a class="dropdown-item " href="#">Rashid Rasheed
Radiologist
MBBS, FCPS</a>
	 <a class="dropdown-item " href="#">Dr Khurrum Ejaz
Radiologist
MBBS,FCPS</a>
	 <a class="dropdown-item " href="#">"Dr. Shumaila Auqil
Radiologist
M.B.B.S, FCPS Radi..</a>
	 <a class="dropdown-item " href="#">Dr Farah Rashid
Radiologist
MBBS, FCPS</a>
	 <a class="dropdown-item " href="#">Dr Rafia Irum
Radiologist
Mbbs FCPS Radiology</a>
	 <a class="dropdown-item " href="#">Dr Muhammad Wasif Iqbal
Radiologist
MBBS,MCPS,FCPS</a>
	 <a class="dropdown-item " href="#">Shafiq Ahmad
Radiologist
MBBS, DMRD - Radio..</a>
	 <a class="dropdown-item " href="#">Dr. Robina Anwar
Radiologist
MBBS, FTIDU (Tokyo..</a>
	 <a class="dropdown-item " href="#">Dr. Asghar Saleem
Radiologist
MBBS, DMRD - Radio.</a>
	 <a class="dropdown-item " href="#">Dr. Mohamad Iqbal
Radiologist
MBBS, DMRD - Radio..</a>
	 <a class="dropdown-item " href="#">Dr. Najam Ud Din
Radiologist
MBBS, MCPS , DMRD,..
	 
	 <a class="dropdown-item " href="#">Dr. Mohammad Aslam Qure..
Radiologist
MBBS, DMRD - Radio..</a>
	 <a class="dropdown-item " href="#">Dr. Saqib Javed Ahmad
Radiologist
MBBS, MD, DMRD , M..</a>
	  <a class="dropdown-item " href="#">Dr. Irfan Masood
Radiologist
MBBS, DMRD - Radio..</a>
	 <a class="dropdown-item " href="#">Dr. Nila Rahim
Radiologist
MBBS, DMRD - Radio..</a>
	 <a class="dropdown-item " href="#">Dr. Aamer Rahim
Radiologist
MBBS, DMRD, FCPS, ..</a>
	 <a class="dropdown-item " href="#">Dr. Najam Bohkari
Radiologist
MBBS, MCPS(PAK).DM..</a>
	 <a class="dropdown-item " href="#">Dr. Mazhar Zaidi
Radiologist
MBBS, (pb) DMRD, M..</a>
	 <a class="dropdown-item " href="#">Dr. M.Rahim
Radiologist
MBBS, DMRD - Radio..</a>
	 <a class="dropdown-item " href="#">Dr. S.M. Nasir Qadri
Radiologist
MBBS, DMRD - Radio..</a> 
<a class="dropdown-item " href="#">Dr. Syed Imran Haidar
Radiologist
MBBS, DMRD - Radio..</a>
	 <a class="dropdown-item " href="#">Dr. Ghulam Mohammad
Radiologist
MBBS, DMRD - Radio..</a>
	 <a class="dropdown-item " href="#">Dr. Shazia Sultan
Radiologist
MBBS, DMRD - Radio..</a>
	 <a class="dropdown-item " href="#">Dr. Mohammad Inam Elahi
Radiologist
MBBS, MD(USA), DMR..</a>
	 <a class="dropdown-item " href="#">"Dr. Mohammad Zaheer Khan
Radiologist
MBBS, DMRD - Radio..</a>
	 <a class="dropdown-item " href="#">Dr. Khubaib Shahid
Radiologist
MBBS, MCPS, FCPS, ..</a>
	 <a class="dropdown-item " href="#">Dr. Sohail Naqvi
Radiologist
MBBS, DMRD - Radio..</a>
	 <a class="dropdown-item " href="#">Dr. Arif Qureshi
Radiologist
MD, FACA - Radiolo..</a>
	 <a class="dropdown-item " href="#">Dr. Nila L.Khan
Radiologist
MBBS, DMRD - Radio..</a>
	 <a class="dropdown-item " href="#">Dr. Sadaf Ali
Radiologist
MBBS, DMRD - Radio..</a>
	 <a class="dropdown-item " href="#">Dr. M Jamshaid Mohsin
Radiologist
MBBS, DMRD - Radio..</a>
 <a class="dropdown-item" href="#">Dr. Iqbal Hussain Dogar
Radiologist
MBBS, MAIUM , DMRD..</a>
	    <div class="dropdown-divider"></div>
		
    <a class="dropdown-item active" href="doctor_specility.php">Comments Here</a>
 
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
    </div>
	 </div>
  </div>
</div>

<br>
<br>
<br>

<div class="container">
  <div class="row">
 
    <div class="col-sm">
   
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">PHYSICAL THERAPIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Ayesha Rehman
Physical Therapist
DPT, M.S (Orthoped..</a>
	<a class="dropdown-item " href="#">Zeeshan Saeed
Physical Therapist
DPT</a>
	<a class="dropdown-item " href="#">Waseem Javaid
Physical Therapist
BSC (Physiotherapy..</a>
	<a class="dropdown-item " href="#">Shahid Imran
Physical Therapist
BS (Physiotherapy)..</a>
	<a class="dropdown-item " href="#">Mehwish Niaz
Physical Therapist
B.S.C (Physiothera..</a>
	<a class="dropdown-item " href="#">Naveed Anwar
Physical Therapist
Ph.D, DPT, MS OMPT</a>
	<a class="dropdown-item " href="#">Waseem Sarwar
Physical Therapist
DPT</a>
	<a class="dropdown-item " href="#">Hafiz zohaib
Physical Therapist
DPT, MS (Neurology)</a>
	<a class="dropdown-item " href="#">Dr Ali Raza
Physical Therapist
BSPT, MSPT Scholar</a>
	<a class="dropdown-item " href="#">Waqar Ahmad
Physical Therapist
DPT, MA (Special E..</a>
    <a class="dropdown-item" href="#">Marriam Zakria
Physical Therapist
DPT, MS OMPT</a>
<a class="dropdown-item " href="#">Waqar Ahmad
Physical Therapist
DPT, MA (Special E..</a>
	 <a class="dropdown-item " href="#">Marriam Zakria
Physical Therapist
DPT, MS OMPT</a>
	 <a class="dropdown-item " href="#">Tehmina Irfan
Physical Therapist
DPT, MS (Orthopedic)</a>
	 <a class="dropdown-item " href="#">Khalid Saeed Khan
Physical Therapist
BSC (Physiotherapy..</a>
	 <a class="dropdown-item " href="#">Salik Nadeem
Physical Therapist
BSPT, PPDPT</a>
	 <a class="dropdown-item " href="#">Ayesha Javed
Physical Therapist
DPT</a>
	 <a class="dropdown-item " href="#">Hira Idrees
Physical Therapist
DPT(Pak)</a>
	  <a class="dropdown-item " href="#">Waseem
Physical Therapist
MPhil. ppdpt. pgd ..</a>
	 <a class="dropdown-item " href="#">Dr Ata ur Rehman
Physical Therapist
BSPT, DMPT,MBA*</a>
	  <a class="dropdown-item " href="#">Dr Baria Rizwan
Physical Therapist
Doctor of Physioth..</a>
	 <a class="dropdown-item " href="#">Dr Muhammad Asrar Yousaf
Physical Therapist
B.S.P.T (UHS) DPT,..</a>
	  <a class="dropdown-item " href="#">Dr Saad Ali
Physical Therapist
DPT(SMC)</a>
	 <a class="dropdown-item " href="#">Ali Raza
Physical Therapist
Doctor of Physical..</a>
	 <a class="dropdown-item " href="#">Dr. Sang Maiin
Physical Therapist
DPT, MBBS, FCPS</a>
	  <a class="dropdown-item " href="#">Dr Saqlain Hayat
Physical Therapist</a>
	 <a class="dropdown-item " href="#">Dr. Sohaib Hassan
Physical Therapist
MBBS - Physical Th..</a>
	  <a class="dropdown-item " href="#">Dr. Sajid Qayyum
Physical Therapist
MBBS - Physical Th..</a>
	 <a class="dropdown-item " href="#">Dr. Hafiz Muhammad Mobeen
Physical Therapist
MBBS - Physical Th..</a>
	  <a class="dropdown-item " href="#">Dr. Tahira
Physical Therapist
MBBS - Physical Th..</a>
	  <a class="dropdown-item " href="#">Raheem Akram
Physical Therapist
DPT</a>
	 <a class="dropdown-item " href="#">Adnan Ikram
Physical Therapist
DPT</a>
	  <a class="dropdown-item " href="#">Najma Khan
Physical Therapist
BSPT ,MA(special E..</a>
	 <a class="dropdown-item " href="#">Adnan Afzal
Physical Therapist
RPT,DPT,CLT,</a>
	 <a class="dropdown-item " href="#">Omer Rashid
Physical Therapist
DPT, Certified Kin..</a>
<div class="dropdown-divider"></div>
    <a class="dropdown-item" href="doctor_specility.php">Comments Here</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item " href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
  </div>
    
	
  
	</div>
	
    <div class="col-sm">
     
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">PEDIATRICIAN</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr Moona Ahmad
Pediatrician
MBBS, FCPS, MRCPCH</a>
	 <a class="dropdown-item " href="#">Zeeshan Muneer
Pediatrician
MBBS, FCPS (Pediat..</a>
	 <a class="dropdown-item " href="#">Muhammad Asif Qureshi
Pediatrician
MBBS, FCPS</a>
	 <a class="dropdown-item " href="#">Prof Muhammad Akbar Malik
Pediatrician
MBBS,FCPS, DCH, MC..</a>
	 <a class="dropdown-item " href="#">Prof. Muhammad Rafique
Pediatrician
MBBS, MCPS, FCPS, ..</a>
	 <a class="dropdown-item " href="#">Naveed Akbar Hotiana
Pediatrician
MBBS, FCPS (Paeds)</a>
	 <a class="dropdown-item " href="#">Binish Ali
Pediatrician
MBBS, FCPS (Paedia..</a>
	 <a class="dropdown-item " href="#">Alia Ahmad
Pediatrician
MBBS, DCH, MRCPCH ..</a>
	 <a class="dropdown-item " href="#">Muhammad Sajid
Pediatrician
MBBS, FCPS (Paeds)..</a>
	 <a class="dropdown-item " href="#">Rizwan Asad Khan
Pediatrician
MBBS, MCPS, FCPS (..</a>
	 <a class="dropdown-item " href="#">Abid Rafiq Chaudhry
Pediatrician
MBBS, MRCPCH (UK),..</a>
	 <a class="dropdown-item " href="#">DR IMTIAZ ZULFIQAR
Pediatrician
MBBS, DCH</a>
	 <a class="dropdown-item " href="#">Prof. Tahira S. Izhar
Pediatrician
MBBS - Pediatrician</a>
	 <a class="dropdown-item " href="#">Dr. Muhammad Ali Shaikh
Pediatrician</a>
	 <a class="dropdown-item " href="#">Dr. Attia Shafiq
Pediatrician</a>
	 <a class="dropdown-item " href="#">Dr. S Tahira Izhar
Pediatrician</a>
	  <a class="dropdown-item " href="#">Dr. Tahira Izhar-A-Khan</a>
	  <a class="dropdown-item " href="#">Dr. Muhammad Nasir Rana</a>
	  <a class="dropdown-item " href="#">Dr. Nadeem Saquib</a>
	  <a class="dropdown-item " href="#">Dr. Humayun Iqbal Khan</a>
	  <a class="dropdown-item " href="#">Dr. Mohammad Zia-Ul-Mir..</a>
	  <a class="dropdown-item " href="#">Dr. Sajjad Rafique
Pediatrician</a>
	  <a class="dropdown-item " href="#">Dr. Rasheed Khawar</a>
	  <a class="dropdown-item " href="#">Dr. Syed Anwar Ahmed</a>
	   <a class="dropdown-item " href="#">Dr. Tariq Zafar</a>
	   <a class="dropdown-item " href="#">Dr. Muhammad Arif Chaud..</a>
	   <a class="dropdown-item " href="#">Dr. Muhammad Akram</a>
	   <a class="dropdown-item " href="#">Dr. M.Farooq</a>
	   <a class="dropdown-item " href="#">Dr. Waqas Hassan</a>
	   <a class="dropdown-item " href="#">Dr. Nusrat Yar Khan</a>
	   <a class="dropdown-item " href="#">Dr. Sheikh Mohammad Iqbal</a>
	   <a class="dropdown-item " href="#">Dr. Mohammad Afzal Hayat</a>
	   <a class="dropdown-item " href="#">Dr. Mohammad Arif</a>
	   <a class="dropdown-item " href="#">Dr. Qamar Zaman</a>
	   <a class="dropdown-item " href="#">Prof. Dr. Raza Baloch</a>
 <div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="doctor_specility.php">Comments Here</a>
  
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
   </div>
    </div>
	
	
	
	
    <div class="col-sm">
    
	  
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">OPHTHALMOLOGIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr. Zafar Iqbal Sheikh Ophthalmologist
Consultant Surgeon</a>
	  <a class="dropdown-item " href="#">Dr. Zia-Ul-Mazhry Ophthalmologist
FRCS, FCPS</a>
	  <a class="dropdown-item " href="#">Dr Muhammad Akram
Ophthalmologist
MBBS, MCPS, DOMS, ..</a>
	  <a class="dropdown-item " href="#">Dr. Mohammad Tariq Khan
Ophthalmologist</a>
	  <a class="dropdown-item " href="#">Dr. Amanh Tahir Noori
Ophthalmologist</a>
	  <a class="dropdown-item " href="#">Dr. Abrar Ilahi Malik
Ophthalmologist</a>
	  <a class="dropdown-item " href="#">Dr. A. Jalil Daula
Ophthalmologist</a>
	  <a class="dropdown-item " href="#">Dr. Irshad Ul Haq
Ophthalmologist</a>
	  <a class="dropdown-item " href="#">Dr. Shuja-Ud-Din Khan
Ophthalmologist</a>
	  <a class="dropdown-item " href="#">Dr. Nadeem Hafeez Butt
Ophthalmologist</a>
	  <a class="dropdown-item " href="#">Dr. Syed Raza Ali Shah
Ophthalmologist
MBBS, DOMS, CICOph..</a>
	  <a class="dropdown-item " href="#">Dr. Mohammad Ramzan
Ophthalmologist</a>
	  <a class="dropdown-item " href="#">Dr. A Jalil Daula
Ophthalmologist</a>
	  <a class="dropdown-item " href="#">Dr. Nasira Inayet
Ophthalmologist</a>
	   <a class="dropdown-item " href="#">Dr. Sohail Sarwar
Ophthalmologist</a>
	  <a class="dropdown-item " href="#">Dr. M Akhatar Shaheen
Ophthalmologist</a>
	  <a class="dropdown-item " href="#">
	  Dr. Khurram Mirza
Ophthalmologist</a>
	  <a class="dropdown-item " href="#">M. Sidique Maan
Ophthalmologist
MBBS, FICS, DORCS,..</a>
	  <a class="dropdown-item " href="#">Dr. Nazir Ahmed Aasi
Ophthalmologist
MBBS, DO, FRC - Op.</a>
	   <a class="dropdown-item " href="#">Dr. Tariq Saeed
Ophthalmologist
MBBS, DAB - Ophtha..</a>
	  <a class="dropdown-item " href="#">Dr. Ahmad Hussain
Ophthalmologist
MBBS, DOMS - Ophth..</a>
	  <a class="dropdown-item " href="#">Dr. Edgar Gulzar
Ophthalmologist
MBBS, DOMS, FICS -..</a>
	  <a class="dropdown-item " href="#">Dr. Khalid Mahmood
Ophthalmologist
MBBS, FCPS, IC, DO..</a>
<a class="dropdown-item " href="#">Dr. Wajahat Latif
Ophthalmologist
MBBS, FCPS - Ophth..</a>
	   <a class="dropdown-item " href="#">Dr. Mohammad Afzal Sheikh
Ophthalmologist
MBBS, DOMS - Ophth..</a>
	  <a class="dropdown-item " href="#">Dr. S.M. Tahir
Ophthalmologist
MBBS, FRCS - Ophth..</a>
	  <a class="dropdown-item " href="#">Dr. M. H. Ejaz Sandhu
Ophthalmologist
MBBS, DOMS - Ophth..</a>
	  <a class="dropdown-item " href="#">Dr. Zahid Kamal
Ophthalmologist
MBBS, FRCS - Ophth..</a>
	   <a class="dropdown-item " href="#">Dr. Akram Riaz
Ophthalmologist
MBBS, DO, MRCO - O..</a>
	  <a class="dropdown-item " href="#">Dr. M. Sidique Maan
Ophthalmologist
MBBS, FICS, DORCS,..</a>
	  <a class="dropdown-item " href="#">Dr. Mohammad Mateen Amir
Ophthalmologist
MBBS, DMS, FCPS - ..</a>
	  <a class="dropdown-item " href="#">Dr. Rizwan Ahmad Cheema
Ophthalmologist
MBBS, FRCS - Ophth..</a> 
<a class="dropdown-item " href="#">Dr. Zahid Chaudhry
Ophthalmologist
MBBS, MCPS, DOMS, ..</a>
	  <a class="dropdown-item " href="#">Dr. M. Salim Akhtar
Ophthalmologist
MBBS, FRCS, DO, FR..</a>
	  <a class="dropdown-item " href="#">Dr. Nadeem Riaz
Ophthalmologist
MBBS, FCPS - Ophth.</a>
	  <a class="dropdown-item " href="#">Dr. Iqbal Ahmad Chaudhry
Ophthalmologist
MBBS, DORCS, DORCP..</a>
	   <div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="doctor_specility.php">Comments Here</a>

    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
    </div>
	 </div>
  </div>
</div>

<br>
<br>
<br>

<div class="container">
  <div class="row">
 
    <div class="col-sm">
   
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">PATHOLOGIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr. Zahid Asgher
Pathologist
MBBS, MD, DAB, FCA..</a>
	<a class="dropdown-item " href="#">Dr. Mohammad Naseem You..
Pathologist
MBBS, DCPath - Pat..</a>
	<a class="dropdown-item " href="#">Dr. Ejaz Ahmad
Pathologist
MBBS, DAB. - Patho..</a>
	<a class="dropdown-item " href="#">Dr. Muhammad Tariq Mahm..
Pathologist
MBBS, DAB - Pathol..</a>
	<a class="dropdown-item " href="#">Dr. Qasim Ahmad
Pathologist
MBBS, DAB. - Patho..</a>
	<a class="dropdown-item " href="#">Dr. Rafay Azhar
Pathologist
MBBS, MRC.Path. - ..</a>
	<a class="dropdown-item " href="#">Dr. Samina Mansoor
Pathologist
MBBS, MSc, DAB. - ..</a>
	<a class="dropdown-item " href="#">Dr. Muhammad Sharif
Pathologist
MBBS, BSc, PhD. - ..</a>
	<a class="dropdown-item " href="#">Dr. Millat Sultan
Pathologist
mbbs, mphil - Path..</a>
	<a class="dropdown-item " href="#">Dr. A. Qadir Khan
Pathologist
MSc, PhD. - Pathol..</a>
    <a class="dropdown-item" href="#">Dr. S. Shah Jahan
Pathologist
MBBS, M.Phil. - Pa..</a>
	<a class="dropdown-item " href="#">Dr. Syed Shoaib Shah
Pathologist
MBBS, DMJ, M.Phil...</a>
	<a class="dropdown-item " href="#">Dr. Hafeez Ul Haq
Pathologist
MBBS, M.Phil. - Pa..</a>
	<a class="dropdown-item " href="#">Dr. Mohammad Ayub
Pathologist
MBBS, MRCP - Patho..</a>
	<a class="dropdown-item " href="#">Dr. Mateen Izhar
Pathologist
MBBS, PhD, MRC. - ..</a>
	<a class="dropdown-item " href="#">Dr. Nisar Ahmad
Pathologist
MBBS, FCPS. - Path..</a>
	<a class="dropdown-item " href="#">Dr. Shehzad Qureshi
Pathologist
MBBS, MSc, MRCPath..</a>
    <a class="dropdown-item" href="#">Dr. Khalid Masood Ahmed
Pathologist
MBBS, DPM - Pathol..</a>

<a class="dropdown-item " href="#">Dr. M. A. Farooqi
Pathologist
MBBS, MPH, DCS - P..</a>
<a class="dropdown-item " href="#">Dr. Saeed Akhtar
Pathologist
MBBS, M.Phil. - Pa..</a>
<a class="dropdown-item " href="#">Dr. I. A. Naveed
Pathologist
MBBS, M.Phil - Pat..</a>
<a class="dropdown-item " href="#">Dr. Nisar Hussain Khan
Pathologist
MBBS, DCH, DTM&H ,..</a>
<a class="dropdown-item " href="#">Dr. Shakoor Ahmad
Pathologist
MBBS, DP, MRCP , R..</a>
<a class="dropdown-item " href="#">Dr. Tariq Mehmood
Pathologist
MBBS, M.Phil, FCPS..</a>
<a class="dropdown-item " href="#">Dr. Abid Javed Minhas
Pathologist
BSPT, MPPS. - Path..</a>
<a class="dropdown-item " href="#">Dr. M. Latif
Pathologist
MBBS, MCPS - Patho..</a>
<a class="dropdown-item " href="#">Dr. Altaf Qadir
Pathologist
BSPT, MBBS - Patho..</a>
<a class="dropdown-item " href="#">Dr. Fakhar Ul Islam
Pathologist
MBBS, DCP - Pathol..</a>
<a class="dropdown-item " href="#">Dr. Imran Afzal
Pathologist
MBBS, DPM - Pathol..</a>
<a class="dropdown-item " href="#">Dr. Babar Chaudhry
Pathologist
MSc, BSPT - Pathol..</a>
<a class="dropdown-item " href="#">Dr. Mehboob Gilani
Pathologist
MBBS, MSc - Pathol..</a>
<a class="dropdown-item " href="#">Dr. Muhammad Farooq Alam
Pathologist
MBBS, MCPS - Patho..</a>
<a class="dropdown-item " href="#">Dr. Rizwan Akhtar
Pathologist
MBBS, PhD. - Patho..</a>
<a class="dropdown-item " href="#">Dr. Nadeem Mansoor
Pathologist
MBBS, DCP, M.Phil...</a>
<a class="dropdown-item " href="#">Dr. Sohail Chughtai
Pathologist
MD, DAB. - Patholo..</a>
<a class="dropdown-item " href="#">Dr. Zahid Asghar
Pathologist
MD, DAB. - Patholo.</a>
 <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="doctor_specility.php">Comments Here</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item " href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
  </div>
    
	
  
	</div>
	
    <div class="col-sm">
     
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">ADDICTION SPECIALIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr M Tarique Arain
Addiction Specialist
FCPS, ATS manageme..</a>
	<a class="dropdown-item " href="#">Dr. Talat Habib
Addiction Specialist
MBBS, ICAP</a>
	<a class="dropdown-item " href="#">Muhammad Asim
Addiction Specialist
mbbd</a>
	<a class="dropdown-item " href="#">Shahid Bangash
Addiction Specialist
MBBS.MD</a>
	<a class="dropdown-item " href="#">DR.LOHANO (Dr.Heeralal ..
Addiction Specialist
MBBS,EMBA,Masters ..</a>
	<a class="dropdown-item " href="#">Dr Sarfraz Cheema
Addiction Specialist
MBBS.MD.MPH.ICAP3</a>
	
	 <div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="doctor_specility.php">Comments Here</a>
    
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
   </div>
    </div>
	
	
	
	
    <div class="col-sm">
    
	  
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">ANAESTHETIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Syeda ZainabAli Nadeem
Anaesthetist
MBBS,FCPS Resident</a>
	<a class="dropdown-item " href="#">Dr Shahbaz Hussain Bhatti
Anaesthetist
Mbbs,fcps</a>
	<a class="dropdown-item " href="#">Dr. Mushtaq Ahmad
Anaesthetist
MBBS, FCPS - Anaes..</a>
	<a class="dropdown-item " href="#">Dr. Main M.Yaqub
Anaesthetist
MBBS, DA, FFARCS -..</a>
	<a class="dropdown-item " href="#">Dr. Moin Uddin Malhi
Anaesthetist
MBBS, , FACA, FACP..</a>
	<a class="dropdown-item " href="#">Dr. Jameel Sabir
Anaesthetist
MBBS, DIP - Anaest..</a>
	<a class="dropdown-item " href="#">Dr. Khalid Iftikhar
Anaesthetist
M.B.B.S , FCPS, - ..</a>
	<a class="dropdown-item " href="#">Dr. Masood -Ur- Rahman
Anaesthetist
MBBS, FCPS - Anaes..</a>
	<a class="dropdown-item " href="#">Dr. Sajid Usman Kaul
Anaesthetist
MBBS, FRCA (Eng) -..</a>
	<a class="dropdown-item " href="#">Dr. Hasan Masood Khan
Anaesthetist
MBBS, D.A - Anaest..</a>
	<a class="dropdown-item " href="#">Dr. Aziz Ul Haq
Anaesthetist
MBBS, FCPS - Anaes.</a>
	<a class="dropdown-item " href="#">Dr. Hammad Mehmood Butt
Anaesthetist
MBBS, DPH (pak) D...</a>
	<a class="dropdown-item " href="#">Dr. Naheed Kamal
Anaesthetist
MBBS, D.A (Lond) F..</a>
	<a class="dropdown-item " href="#">Dr. Sikandar Ghafoor
Anaesthetist
MBBS, MCPS - Anaes..</a>
	<a class="dropdown-item " href="#">Dr. Arshad Taqi
Anaesthetist
MBBS, MCPS , FCPS,..</a>
	<a class="dropdown-item " href="#">Dr. Khalid Bashir
Anaesthetist
MBBS, MCPS FCPS - ..</a>
	<a class="dropdown-item " href="#">Dr. Shahida Khawaja
Anaesthetist
MBBS, DA.(Lond) FC..</a>
	<a class="dropdown-item " href="#">Dr. Kamran Zafar Khan
Anaesthetist
MBBS, MCPS FCPS - ..</a>
	<a class="dropdown-item " href="#">Dr. Nasrullah Khan
Anaesthetist
MBBS FCPS - Anaes..</a>
	<a class="dropdown-item " href="#">Dr. Zafar-Ul-Haq
Anaesthetist
MBBS, DA - Anaesth.</a>
	<a class="dropdown-item " href="#">Dr. Attiya Sheikh
Anaesthetist
MBBS, DA - Anaesth..</a>
	<a class="dropdown-item " href="#">Dr. Khalid Javed Siddiqi
Anaesthetist
MBBS, FCPS, - Anae..</a>
	<a class="dropdown-item " href="#">Dr. Zia-Ur-Rahman Khalid
Anaesthetist
MBBS, DA - Anaesth..</a>
	<a class="dropdown-item " href="#">Dr. Abdul Jaleel
Anaesthetist
MBBS, DA , FACP - ..</a>
	<a class="dropdown-item " href="#">Dr. Ayesha Asad
Anaesthetist</a>
	<a class="dropdown-item " href="#">Dr. Baber Zaheer
Anaesthetist</a>
	<a class="dropdown-item " href="#">Dr. Imtiaz Ahmad
Anaesthetist</a>
	<a class="dropdown-item " href="#">Dr. Motsim Sheraz
Anaesthetist</a>
	<a class="dropdown-item " href="#">Dr. Muhammad Aslam Ahmeed</a>
	<a class="dropdown-item " href="#">Dr. Rehan Amir</a>
	<a class="dropdown-item " href="#">Dr Abdul Naeem Naushad
Anaesthetist
MBBS M.D ( USA )</a>
	<a class="dropdown-item " href="#">Dr.Salman Athar Qureshi
Anaesthetist
MBBS, FCPS</a>
	<a class="dropdown-item " href="#">Dr Sabir Khan
Anaesthetist
Mbbs.fcps</a>
	<div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="doctor_specility.php">Comments Here</a>
  
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
    </div>
	 </div>
  </div>
</div>

<br>
<br>
<br>

<div class="container">
  <div class="row">
 
    <div class="col-sm">
   
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">Acupuncturist</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Shumaila Malik
Audiologist
Bs.(Hon's) Audiolo..</a>
	<a class="dropdown-item " href="#">Hina Saeed Ch
Audiologist
BSC (HONS) Audiology</a>
	<a class="dropdown-item " href="#">Maha Afzaal Butt
Audiologist
MPhil. Audiology(I..</a>
	<a class="dropdown-item " href="#">Dr Wajeeha Zaib
Audiologist
Bs(audiology)MSSLH..</a>
	<a class="dropdown-item " href="#">Dr. Nadeem Mukhtar
Audiologist</a>
	<a class="dropdown-item " href="#">Dr Asim Khan
Audiologist
MSC Audiology</a>

	<div class="dropdown-divider"></div>
    <a class="dropdown-item" href="doctor_specility.php">Comments Here</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item " href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
  </div>
    
	
  
	</div>
	
    <div class="col-sm">
     
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">CANCER SPECIALIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr. Amjad S K Durrani
Cancer Specialist</a>
	  <a class="dropdown-item " href="#">Dr. Abubakar Shahid
Cancer Specialist</a>
	  <a class="dropdown-item " href="#">Dr. Lt. Col. (R) Ghulam..
Cancer Specialist</a>
	  <a class="dropdown-item " href="#">Dr. Misbah Masood
Cancer Specialist
DMRT; FCPS.</a>
	  <a class="dropdown-item " href="#">Dr. Shaheena Parveen
Cancer Specialist</a>
	  <a class="dropdown-item " href="#">Dr. Shaheena Parveen
Cancer Specialist</a>
	  <a class="dropdown-item " href="#">Dr. Muhammed Sleem
Cancer Specialist</a>
	  <a class="dropdown-item " href="#">Dr. Abu Bakar
Cancer Specialist</a>
	  <a class="dropdown-item " href="#">Dr. Afaq Ahmed Qureshi
Cancer Specialist</a>
	  <a class="dropdown-item " href="#">Dr. Numair
Cancer Specialist</a>
	  <a class="dropdown-item " href="#">Dr. Reena Sajjad
Cancer Specialist</a>
	  <a class="dropdown-item " href="#">Dr. Saeeda Asghar
Cancer Specialist</a>
	  <a class="dropdown-item " href="#">Dr. Mumtaz Ahmed
Cancer Specialist</a>
	  <a class="dropdown-item " href="#">Dr. Suhail Ahmed Anwar
Cancer Specialist</a>
	  <a class="dropdown-item " href="#">Dr. Imtiaz Ahmad Ranndh..
Cancer Specialist</a>
	  <a class="dropdown-item " href="#">Dr Arif Ch
Cancer Specialist
Diplomate American..</a>
	  <a class="dropdown-item " href="#">Dr. Nadeem Zia
Cancer Specialist
MBBS(KE)DMRT(UHS)G..</a>
	  <a class="dropdown-item " href="#">Mansoor Ahmed Mazari
Cancer Specialist
Fcps</a>
	  <a class="dropdown-item " href="#">Dr Tariq Mahmood
Cancer Specialist
mbbs, fcps</a>
	  <a class="dropdown-item " href="#">Dr Khalid Shabbir
Cancer Specialist
MBBS, DMRT, FCPS (..</a>
	 
	
	<div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="doctor_specility.php">Comments Here</a>
 
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
   </div>
    </div>
	
	
	
	
    <div class="col-sm">
    
	  
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">OBSTETRICIAN</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr Maria Saeed
Obstetrician
MBBS, MCPS</a>
	  <a class="dropdown-item " href="#">Dr Sadia Rashid
Obstetrician
MCPS, FCPS (Obstet..</a>
	  <a class="dropdown-item " href="#">Tasneem Akhtar
Obstetrician
MBBS</a>
	  <a class="dropdown-item " href="#">Dr Maria Saeed
Obstetrician
MBBS, MCPS</a>
	
	<div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="#">Comments Here</a>
   
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
    </div>
	 </div>
  </div>
</div>
<br>
<br>
<br>

<div class="container">
  <div class="row">
 
    <div class="col-sm">
   
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">NEUROLOGIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Muhammad Azeem Ashfaq
Neurologist
MBBS, FCPS, Fellow..</a>
	<a class="dropdown-item " href="#">Syed Arslan Haider
Neurologist
MBBS, FCPS (Neurol..</a>
	<a class="dropdown-item " href="#">Adnan Tariq
Neurologist
MBBS, FCPS (Neurol..</a>
	<a class="dropdown-item " href="#">Adnan Hameed Gill
Neurologist
MBBS, FCPS</a>
	<a class="dropdown-item " href="#">Farrukh Ali Chaudhry
Neurologist
MBBS (KEMC), MD (U..</a>
	<a class="dropdown-item " href="#">"Muhammad Zahid Ahmad
Neurologist
MBBS,FCPS</a>
	<a class="dropdown-item " href="#">Dr. Nasir Raza Awan
Neurologist
(FCPS)</a>
	<a class="dropdown-item " href="#">Dr. Sajjad Shahnshah
Neurologist</a>
	<a class="dropdown-item " href="#">Dr. Abdul Hameed
Neurologist
(FCPS)</a>
	<a class="dropdown-item " href="#">Dr. Naveed Ashraf
Neurologist
(MS)</a>
    <a class="dropdown-item" href="#">Dr. Azam Niaz
Neurologist</a>
<a class="dropdown-item " href="#">Dr. Bashir Ahmed Khan Z..
Neurologist</a>
<a class="dropdown-item " href="#">Dr. Hafiz Irfan Jarari
Neurologist</a>
<a class="dropdown-item " href="#">Dr. Fauzia
Neurologist</a>
<a class="dropdown-item " href="#">Dr. Hammad Malik
Neurologist</a>
<a class="dropdown-item " href="#">Dr. Asma Ghouri
Neurologist</a>
<a class="dropdown-item " href="#">Dr. Syed Salman Raza Ja..
Neurologist</a>
<a class="dropdown-item " href="#">Dr. Moquit Usman
Neurologist</a>
<a class="dropdown-item " href="#">Dr. Atiq Ur Rehman
Neurologist</a>
<a class="dropdown-item " href="#">Dr. Naeem Ul Hamid
Neurologist</a>
<a class="dropdown-item " href="#">Dr. Rafique A Basharat
Neurologist</a>
<a class="dropdown-item " href="#">Dr. Ahmad Fawad
Neurologist</a>
<a class="dropdown-item " href="#">Dr. Khalid Ch
Neurologist
(FCPS)</a>
<a class="dropdown-item " href="#">Dr. Brig. Khalid Mahmoo..
Neurologist
(FRCS)</a>
<a class="dropdown-item " href="#">Dr. Amir Ayub
Neurologist</a>
<a class="dropdown-item " href="#">Dr. Abdul Majid
Neurologist
(FCPS)</a>
<a class="dropdown-item " href="#">Dr. Anwar Chaudhry
Neurologist</a>
<a class="dropdown-item " href="#">Dr. Asif Shabbir
Neurologist</a>
<a class="dropdown-item " href="#">Dr. Abdul Ghani
Neurologist</a>
<a class="dropdown-item " href="#">Dr. Muhammad Zafar Iqbal
Neurologist
(FRCS)</a>
<a class="dropdown-item " href="#">Dr. Attique-Ur-Rehman
Neurologist</a>
<a class="dropdown-item " href="#">Dr. Abdullah Haroon
Neurologist
(FCPS)</a>
<a class="dropdown-item " href="#">Dr. Shahzad Shams
Neurologist
(FRCS)</a>
<a class="dropdown-item " href="#">Dr. Kamran Hussain
Neurologist
(FRCS)</a>
<a class="dropdown-item " href="#">Dr. Ashraf Iqbal Rana (..
Neurologist">Dr. Ashraf Iqbal Rana (..
Neurologist</a>
<a class="dropdown-item " href="#">"Dr. M. Naseem Puri
Neurologist
(FCPS)</a>
<div class="dropdown-divider"></div>
    <a class="dropdown-item" href="#">Comments Here</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item " href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
  </div>
    
	
  
	</div>
	
    <div class="col-sm">
     
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">NEPHROLOGIST </button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr Aurangzeb Afzal
Nephrologist
MBBS,MRCP Nephrolo..</a>
	    <a class="dropdown-item " href="#">Shafiq Cheema
Nephrologist
MD (USA),DABIM (US..</a>
	    <a class="dropdown-item " href="#">Muhammad Ahad Qayyum
Nephrologist
MBBS, MRCP(UK), MR..</a>
	    <a class="dropdown-item " href="#">Hameed Tajamal
Nephrologist
MBBS, MD, FRCPS, M..</a>
	    <a class="dropdown-item " href="#">Zahid Rafique
Nephrologist
MBBS, MCPS (Medici..</a>
	    <a class="dropdown-item " href="#">Umar Hayat
Nephrologist
MBBS, FCPS (Nephro.</a>
	    <a class="dropdown-item " href="#">Azeem Baig
Nephrologist
MBBS, FCPS (Nephro</a>
	    <a class="dropdown-item " href="#">DR Shafiq Cheema
Nephrologist
MD,DABIM,DABN,FASN..</a>
	    <a class="dropdown-item " href="#">Ahad Qayyum
Nephrologist
MBBS, MRCP (UK), M..</a>
	    <a class="dropdown-item " href="#">Dr. Hameed Tajammal Khan
Nephrologist
MBBS, MRCP(UK) FC..</a>
	    <a class="dropdown-item " href="#">Dr Zishan Nasir
Nephrologist
MBBS. FCPS</a>
	    <a class="dropdown-item " href="#">Dr Muhammad Tanzeel Abb..
Nephrologist
M.B;B.S, FCPS</a>
	    <a class="dropdown-item " href="#">Dr Haroon Ayub
Nephrologist
MBBS, MRCP (UK), F..</a>
	   
	
	<div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="#">Comments Here</a>

    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
   </div>
    </div>
	
	
	
	
    <div class="col-sm">
    
	  
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">MEDICAL SPECIALIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr MUHAMMAD TABISH RAZA
Medical Specialist
M.B.B.S, MD(USA), ..</a>
	  <a class="dropdown-item " href="#">Dr Aizhu Wang
Medical Specialist
MBBS</a>
	  <a class="dropdown-item " href="#">Anaya Ch
Medical Specialist
mbbs,fcps</a>
	  <a class="dropdown-item " href="#">Muhammad Ali
Medical Specialist
MBBS,MRCGP UK</a>
	  <a class="dropdown-item " href="#">Prof. Gulsena Masood Khan
Medical Specialist
MBBS - Medical Spe..</a>
	  <a class="dropdown-item " href="#">Prof. Mehmood Ali Malik
Medical Specialist
MBBS - Medical Spe..</a>
	  <a class="dropdown-item " href="#">Dr. Mudassar Riaz Warra..
Medical Specialist
M.B.B.S, R.M.P, G.P</a>
	  <a class="dropdown-item " href="#">Dr Kanwar Atiq
Medical Specialist
MBBS,FCPS (U.K)</a>
	
	      <div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="#">Comments Here</a>

    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
    </div>
	 </div>
  </div>
</div>
<br>
<br>
<br>

<div class="container">
  <div class="row">
 
    <div class="col-sm">
   
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">MATERNAL FETAL MEDICINE SPECIALIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Sohail Ahmad
Maternal Fetal Medicine Specialist
MBBS, FCPS</a>
	
    <a class="dropdown-item" href="#">Comments Here</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item " href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
  </div>
    
	
  
	</div>
	
    <div class="col-sm">
     
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">LAPAROSCOPIC SURGEON</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">LAPAROSCOPIC SURGEON IN HOSPITALS "><b>LAPAROSCOPIC SURGEON IN HOSPITALS </b></option>
	  "Dr. Abdul Majid
Laparoscopic Surgeon
MBBS, FRCS (UK)</a>
	  <a class="dropdown-item " href="#">"Dr Asif Rehman
Laparoscopic Surgeon
MBBS, FCPS (Genera..</a>
	  <a class="dropdown-item " href="#">Dr Mazher
Laparoscopic Surgeon</a>
	  <a class="dropdown-item " href="#">DR. ZAFAR IQBAL GONDAL
Laparoscopic Surgeon
MBBS, MRCS, MCPS, ..</a>
	  <a class="dropdown-item " href="#">Dr. Muhammad Asadullah ..
Laparoscopic Surgeon
MBBS,FCPS,MRCP</a>
	  <a class="dropdown-item " href="#">Dr. Majeed Chaudhry
Laparoscopic Surgeon
MBBS - Laparoscopi..</a>
	  <a class="dropdown-item " href="#">Dr. Zafar Ali Chaudhry
Laparoscopic Surgeon
MBBS - Laparoscopi..</a>
	  <a class="dropdown-item " href="#">Dr. Zahid Niaz
Laparoscopic Surgeon
FCPS, FRCS - Lapar..</a>
	    <a class="dropdown-item " href="#">Dr. Haroon Dar
Laparoscopic Surgeon
MBBS - Laparoscopi..</a>
	  <a class="dropdown-item " href="#">Dr. Jawad Ashraf
Laparoscopic Surgeon
MBBS - Laparoscopi..</a>
	  <a class="dropdown-item " href="#">Dr. Sadaqat Ali Khan
Laparoscopic Surgeon
MBBS - Laparoscopi..</a>
	  <a class="dropdown-item " href="#">Dr. Tahir Ahmad Shah
Laparoscopic Surgeon
MBBS - Laparoscopi..</a>
	  <a class="dropdown-item " href="#">Dr. M. H. Randhawa
Laparoscopic Surgeon
MBBS - Laparoscopi..</a>
	  <a class="dropdown-item " href="#">Dr. Zafar Aziz Khan
Laparoscopic Surgeon
MBBS - Laparoscopi..</a>
	    <div class="dropdown-divider">Dr. Zahid Akbar
Laparoscopic Surgeon
MBBS - Laparoscopi..</div>
		 <div class="dropdown-divider">Dr. Sadaqat Khan
Laparoscopic Surgeon
MBBS - Laparoscopi..</div>
		  <div class="dropdown-divider">Dr. M. Zahid Akbar
Laparoscopic Surgeon
MBBS - Laparoscopi..</div>
		  <div class="dropdown-divider">Dr Ahsan Nasim
Laparoscopic Surgeon
FCPS</div>
		  <div class="dropdown-divider">Dr Khalid Mahmood
Laparoscopic Surgeon
MBBS, FCPS</div>

    <div class="dropdown-divider"></div>
		
    <a class="dropdown-item active" href="#">Comments Here</a>

    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
   </div>
    </div>
	
	
	
	
    <div class="col-sm">
    
	  
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">INTENSIVIST </button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr. Shahzad Iqbal
Intensivist
MD - Intensivist</a>
	    <div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="#">Comments Here</a>
   
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
    </div>
	 </div>
  </div>
</div>

<br>
<br>
<br>

<div class="container">
  <div class="row">
 
    <div class="col-sm">
   
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">HOMEOPATHIC</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr. Aamir Mustafa
Homeopathic
D.H.M.S.</a>
	<a class="dropdown-item " href="#">Dr Shahzada Hamid Riaz ..
Homeopathic
DHMS /MD</a>
	<a class="dropdown-item " href="#">Salam Hamid
Homeopathic
D.H.M.S - Homeopat..</a>
	<a class="dropdown-item " href="#">Tahir Malik Awan
Homeopathic
D.H.M.S - Homeopat..</a>
	<a class="dropdown-item " href="#">Dr. Mohsin Mehmood Shaikh
Homeopathic
DHMS, MD(HOM), DSC..</a>
	<a class="dropdown-item " href="#">Mian Muhammad Atif
Homeopathic
bsc</a>
	<a class="dropdown-item " href="#">Dr Yasir Hamid
Homeopathic
F,Sc. DHMS, RHMP, ..</a>
	<a class="dropdown-item " href="#"> Aftab Ranjha
Homeopathic
DHMS</a>
	<a class="dropdown-item " href="#">Dr Zafar Iqbal Chaudhary
Homeopathic
DHMS, SCD, RHMP,MD</a>
	<a class="dropdown-item " href="#">Munir Hussain Sheikh
Homeopathic</a>
    <a class="dropdown-item" href="#">Prof Dr. Ghulam Mustafa
Homeopathic</a>
 <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="#">Comments Here</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item " href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
  </div>
    
	
  
	</div>
	
    <div class="col-sm">
     
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">HEPATOLOGIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">DR. PARA BUTT
Hepatologist
FCF</a>
	    <a class="dropdown-item " href="#">Prof,Dr Muhammad Shoaib..
Hepatologist
M.B.B.S,F.C.P.S,</a>
	    <a class="dropdown-item " href="#">Dr. Niaz Ahmed Qadri
Hepatologist
MBBS, MCPS, FCPS(M..</a>
	    <a class="dropdown-item " href="#">Dr. Omar Anis
Hepatologist
M.B.B.S M.C.P.S M...</a>
	    <a class="dropdown-item " href="#">Dr Prof Nasir Hassan Luck
Hepatologist
MBBS,FCPS med, FCP..</a>
	    <a class="dropdown-item " href="#">Dr. Syed M Raza
Hepatologist
(MBBS, FCPS,Viscer..</a>
	   
	
    <div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="#">Comments Here</a>

    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
   </div>
    </div>
	
	
	
	
    <div class="col-sm">
    
	  
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">HEART SPECIALIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr. M. Rafique Chaudhry
Heart Specialist</a>
	    <a class="dropdown-item " href="#">Dr. Abdul Hafeez Khan
Heart Specialist</a>
	    <a class="dropdown-item " href="#">Dr. Dawood Shaukat
Heart Specialist</a>
	    <a class="dropdown-item " href="#">Dr. Irfan Bakhsi
Heart Specialist</a>
	    <a class="dropdown-item " href="#">Dr. Masood Ahmed
Heart Specialist</a>
	    <a class="dropdown-item " href="#">Dr. Shaharyar Ahmad Sha..
Heart Specialist</a>
	    <a class="dropdown-item " href="#">Dr. Najam Hyder
Heart Specialist</a>
	    <a class="dropdown-item " href="#">Dr. Najam Ayyub Minhas
Heart Specialist</a>
	    <a class="dropdown-item " href="#">Dr. M Rashid Ch
Heart Specialist</a>
		<a class="dropdown-item " href="#">Dr. Ashfaque Ahmed Khan
Heart Specialist</a>
	    <a class="dropdown-item " href="#">Dr. Ismat Khalid
Heart Specialist</a>
	    <a class="dropdown-item " href="#">Dr. Prof. A. Hafiz Khan
Heart Specialist</a>
	    <a class="dropdown-item " href="#">Dr. A Jmal Hassan Naqvi
Heart Specialist</a>
		<a class="dropdown-item " href="#">Dr. Farooq Taufeeq Sultan
Heart Specialist</a>
	    <a class="dropdown-item " href="#">Dr. Faiz Ur Rehman
Heart Specialist</a>
	    <a class="dropdown-item " href="#">Dr. M Aahfaq
Heart Specialist</a>
	    <a class="dropdown-item " href="#">Dr. M Abrar Ch
Heart Specialist</a>
	    <a class="dropdown-item " href="#">Dr.Haroon Babar
Heart Specialist</a>
	    <a class="dropdown-item " href="#">Dr. Azimuddin Zahid
Heart Specialist</a>
		 <a class="dropdown-item " href="#">Dr. Tariq Mahmood Malik
Heart Specialist</a>
	    <a class="dropdown-item " href="#">Dr. Prof Saeed
Heart Specialist</a>
	    <a class="dropdown-item " href="#">Dr. Afaq Ahmed
Heart Specialist</a>
	    <a class="dropdown-item " href="#">Dr. Irfan Bakhashi
Heart Specialist</a>
	    <a class="dropdown-item " href="#">Dr Tahmina Sardar
Gynecologist
MBBS, FCPS (Obs & ..</a>
	    <a class="dropdown-item " href="#">Sara Ejaz
Gynecologist
MBBS, FCPS, Diplom..</a>

	<a class="dropdown-item " href="#">Nazli Hameed
Gynecologist
MBBS, FCPS, FRCOG(..</a>
	<a class="dropdown-item " href="#">Maria Imran
Gynecologist
MBBS, FCPS (Obs & ..</a>
	<a class="dropdown-item " href="#">Rehana Amir
Gynecologist
MBBS, FCPS (Obstet..</a>
	
	<a class="dropdown-item " href="#">Rabia Wajid
Gynecologist
MBBS, FCPS</a>
	<a class="dropdown-item " href="#">Jamshid Feroze
Gynecologist
MBBS, FCPS (Obs & ..</a>
	<a class="dropdown-item " href="#">Humaira Zulfiqar Saifee
Gynecologist
MBBS, FCPS (Obs & ..</a>
	<a class="dropdown-item " href="#">Syeda Riffat Iqbal
Gynecologist
MBBS, FCPS</a>
	<a class="dropdown-item " href="#">Uzma Hussain
Gynecologist
MBBS, FCPS, MME (G..</a>
	<a class="dropdown-item " href="#">Misbah Malik
Gynecologist
MBBS, MCPS, FCPS</a>
	<a class="dropdown-item " href="#">Shabnam Muhammad Ali
Gynecologist
MBBS,FCPS</a>
	<a class="dropdown-item " href="#">Shysta Shaukat
Gynecologist
MBBS, FCPS (Gyn & ..</a>
	<a class="dropdown-item " href="#">Saima Zaki
Gynecologist
MBBS, MCPS,FCPS (O..</a>
	<a class="dropdown-item " href="#">Umtal Batool
Gynecologist
MBBS, FCPS (Obs & ..</a>
	<a class="dropdown-item " href="#">Nagina Bibi
Gynecologist
MBBS, MCPS, FCPS, ..</a>
	<a class="dropdown-item " href="#">Tasneem Zia
Gynecologist
MBBS, DGO</a>
	<a class="dropdown-item " href="#">Dr Samina Aman Sindhu
Gynecologist
M.B.B.S, R.M.P, DG..</a>
	<a class="dropdown-item " href="#">Dr Mudassara Rafi
Gynecologist
MBBS, MCPS (Gyne /..</a>
	<a class="dropdown-item " href="#">Dr Faiqa Saleem Baig
Gynecologist
MBBS. MCPS. MRCOG</a>
<a class="dropdown-item " href="#">Dr Amber Qureshi
Gynecologist
MBBS. MCPS</a>
	<a class="dropdown-item " href="#">Prof. Alia Bashir
Gynecologist
MBBS; DGO; MCPS; F..</a>
	<a class="dropdown-item " href="#">Dr. Arshad Chohan
Gynecologist
MBBS, FCPS, MRCOG,..</a>
	<a class="dropdown-item " href="#">Dr. Balqees Fatima
Gynecologist
MBBS, FCPS, FRCOG ..</a>
	<a class="dropdown-item " href="#">Dr. Bushra Shahida
Gynecologist
MBBS, DGO - Gyneco..</a>
	<a class="dropdown-item " href="#">Dr. Fakhara Mehmood
Gynecologist
MBBS, DGO - Gyneco..</a>
	<a class="dropdown-item " href="#">Dr. Fozia Munnoo Khan
Gynecologist
MBBS, MRCOG. - Gyn..</a>
	<a class="dropdown-item " href="#">Dr. Hajira Hanif
Gynecologist
MBBS, FRCOG - Gyne..</a>
	<a class="dropdown-item " href="#">Dr. Iffat Saleem
Gynecologist
MBBS, MRCOG, DRCOG..</a>
	<a class="dropdown-item " href="#">"Dr. Iqbal Rasheed Mian
Gynecologist
MBBS, FRCOG - Gyne..</a>
	<a class="dropdown-item " href="#">Dr. Munawar Zaheen
Gynecologist
MBBS, MRCOG, FRCOG..</a>
	<a class="dropdown-item " href="#">Dr. N. A. Seyal
Gynecologist
MBBS, FRCS, FRCOG...</a>
	<a class="dropdown-item " href="#">Dr. Naheed Akhtar
Gynecologist
MBBS, MRCOG. - Gyn..</a>
	<a class="dropdown-item " href="#">Dr. Naseem Niaz
Gynecologist
MBBS, MRCOG. - Gyn..</a>
	<a class="dropdown-item " href="#">Mahham Janjua
Gynecologist
MBBS, FCPS (Obstet..</a>
	<a class="dropdown-item " href="#">Dr. Farhat Rashid
Gynecologist
MBBS, FCPS (Obs & ..</a>

	<div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="#">Comments Here</a>

    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
    </div>
	 </div>
  </div>
</div>

<br>
<br>
<br>

<div class="container">
  <div class="row">
 
    <div class="col-sm">
   
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">GENERAL SURGEON</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr. Afsar Ali Bhatti
General Surgeon
M.B.B.S, F.C.P.S.(..</a>
	<a class="dropdown-item " href="#">Dr. Mahmood Mazhar
General Surgeon
MBBS(KE), FRCS(Ed)</a>
	<a class="dropdown-item " href="#">Muhammad Nasir
General Surgeon
MBBS, FCPS</a>
	<a class="dropdown-item " href="#">Aamir Jameel
General Surgeon
MBBS, FCPS</a>
	<a class="dropdown-item " href="#">Hassan Shaukat
General Surgeon
MBBS, FCPS (Surgery)</a>
	<a class="dropdown-item " href="#">Sadaqat Ali Khan
General Surgeon
MBBS, MCPS(Gen sur..</a>
	<a class="dropdown-item " href="#">Andleeb Khanam
General Surgeon
MBBS, FCPS (Surgery</a>
	<a class="dropdown-item " href="#">Shahzad Alam Shah
General Surgeon
MBBS,FCPS</a>
	<a class="dropdown-item " href="#">Prof Mohsin Gillani
General Surgeon
MBBS,FCPS, Fellows..</a>
	<a class="dropdown-item " href="#">Rizwan Khalid
General Surgeon
MBBS, FCPS ( Surge..</a>
    <a class="dropdown-item" href="#">Zahid Mahmood
General Surgeon
MBBS, FCPS</a>
	<a class="dropdown-item " href="#">Maaz Ul Hassan
General Surgeon
MBBS, FCPS, FLS, B..</a>
	<a class="dropdown-item " href="#">Dr.S.Umer Khan
General Surgeon
M.B.B.S,F.C.P.S</a>
    <a class="dropdown-item" href="#">Dr Ambreen Khalid Rana
General Surgeon
MBBS</a>
	<a class="dropdown-item " href="#">Sadaf Ishaque
General Surgeon
MBBS,FCPS</a>
	<a class="dropdown-item " href="#">Prof Zahid Mahmood
General Surgeon
MBBS. FCPS</a>
    <a class="dropdown-item" href="#">Dr Ch Mohammad Kamran
General Surgeon
MBBS FCPS</a>
    <a class="dropdown-item" href="#">Dr. Mohammed Farooq Afzal
General Surgeon
MBBS, FCPS</a>
    <a class="dropdown-item" href="#">Dr Kamran Ali
General Surgeon
MBBS, FCPS</a>
	<a class="dropdown-item" href="#">Dr. Riaz Ahmed Warraich
General Surgeon
MBBS, MDS, MCPS, F..</a>
    <a class="dropdown-item" href="#">Dr. Haroon Dar
General Surgeon
MBBS, FCPS - Gener..</a>
    <a class="dropdown-item" href="#">Dr. Jawad Ashraf
General Surgeon
MBBS, FRCS - Gener..</a>
    <a class="dropdown-item" href="#">Dr. Rashid Saeed
General Surgeon
MBBS, FCPS, FRCS -..</a>
    <a class="dropdown-item" href="#">Dr. Moeed Iqbal Qureshi
General Surgeon
MBBS, FCPS, FRCS -..</a>
    <a class="dropdown-item" href="#">Dr. Tahir Mehboob Bajwa
General Surgeon
MBBS, FCPS - Gener..</a>
    <a class="dropdown-item" href="#">Dr. Ashraf Khan Niazi
General Surgeon
MBBS, FRCS - Gener..</a>
    <a class="dropdown-item" href="#">Dr. Sajjida Javed
General Surgeon
MBBS, FCPS - Gener..</a>
    <a class="dropdown-item" href="#">Dr. Salman Zahid
General Surgeon
MBBS, FRCS - Gener..</a>
	 <a class="dropdown-item" href="#">Dr. Javaid Iqbal Malik
General Surgeon
MBBS, FCPS, - Gene..
	 </a> <a class="dropdown-item" href="#">Dr. Khalida Usmani
General Surgeon
MBBS, MD, , FRCS -..</a>
	 <a class="dropdown-item" href="#">Shahzad Naveed Jawaid
General Surgeon
MBBS, MS (General ..</a> 
	 <a class="dropdown-item" href="#">Amna Umar Gill
General Surgeon
MBBS, MRCS, FCPS (..</a>
	 <a class="dropdown-item" href="#">Kamran Ali
General Surgeon
MBBS, FCPS</a>
	 <a class="dropdown-item" href="#">Zafar Iqbal Gondal
General Surgeon
MBBS, MRCS, MCPS, ..</a>
	 <a class="dropdown-item" href="#">Dr Ahmad Uzair Qureshi
General Surgeon
MBBS, MCPS, MRCS, ..</a> 
	 <a class="dropdown-item" href="#">Dr Syed Imran Hussain A..
General Surgeon
MBBS,FCPS (Pak),FR..</a>
	    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="#">Comments Here</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item " href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
  </div>
    
	
  
	</div>
	
    <div class="col-sm">
     
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">GASTROENTEROLOGIST </button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Waqas Shabbir
Gastroenterologist
MBBS, FCPS (Gastro..</a>
	    <a class="dropdown-item " href="#">Muhammad Awais Abid
Gastroenterologist
MBBS, FCPS (Medici..</a>
	    <a class="dropdown-item " href="#">Muhammad Bilal Nasir
Gastroenterologist
MBBS, FCPS( Medici..</a>
	    <a class="dropdown-item " href="#">Zafar Iqbal Chaudhary
Gastroenterologist
MBBS, FCPS</a>
	    <a class="dropdown-item " href="#">Asif Mehmood
Gastroenterologist
MBBS, FCPS, MCPS, ..</a>
	    <a class="dropdown-item " href="#">Mehreen Zaman Niazi
Gastroenterologist
MBBS, FCPS</a>
	    <a class="dropdown-item " href="#">Imran Khan Farooka
Gastroenterologist
MBBS, FCPS (Medici..</a>
	    <a class="dropdown-item " href="#">Muhammad Adeel Qamar
Gastroenterologist
MBBS(KE), MD(USA),..</a>
	    <a class="dropdown-item " href="#">ahid Hussain Shah
Gastroenterologist
MBBS, FCPS, MD (Ga..</a>
	    <a class="dropdown-item " href="#">Hassan Suleman Malik
Gastroenterologist
MBBS, FCPS(PEDIATR..</a>
		 <a class="dropdown-item " href="#">Fahad Aman Khan
Gastroenterologist
MBBS,FCPS</a>
		 <a class="dropdown-item " href="#">Salman Javed
Gastroenterologist
MBBS (Pb), MD (USA..</a>
		 <a class="dropdown-item " href="#">Amtiaz Ahmad
Gastroenterologist
MBBS, MRCP, FCPS (.</a>
		 <a class="dropdown-item " href="#">Ahmad Farooq
Gastroenterologist
MBBS, FCPS, MRCP</a>
		 <a class="dropdown-item " href="#">Attique Abou Bakr
Gastroenterologist
MBBS, FCPS, MRCP (..</a>
		 <a class="dropdown-item " href="#">Mahmood Ahmad Cheema
Gastroenterologist
MBBS, FCPS (Gastro..</a>
		 <a class="dropdown-item " href="#">Dr. Mian Sajid Nisar
Gastroenterologist
MBBS, MRCP - Gasro.</a>
		 <a class="dropdown-item " href="#">Dr Mujtaba Jaffary
Gastroenterologist
MBBS.MRCP(UK).</a>
		 <a class="dropdown-item " href="#">Dr. Khalid Mahmud Khan
Gastroenterologist
MRCP, FCPS</a>
		 <a class="dropdown-item " href="#">Dr Moeez Kaiser Butt
Gastroenterologist
M.B.B.S FCPS</a>
		 <a class="dropdown-item " href="#">Dr Hareem Shahzad Khan
Gastroenterologist
MBBS, MD</a>
		 <a class="dropdown-item " href="#">Dr. Nusrat Ullah Ch.
Gastroenterologist</a>
		 <a class="dropdown-item " href="#">Dr. Arif Mahmood Siddiqui
Gastroenterologist</a>
		 <a class="dropdown-item " href="#">Dr. S. Asif Raza Shah
Gastroenterologist
MBBS, MCPS(Medicin..</a>
		 <a class="dropdown-item " href="#">Dr. Adeel Qamar
Gastroenterologist
MBBS (K,E), MD (US..</a>
		 <a class="dropdown-item " href="#">Dr. Aftab Haider Alvi
Gastroenterologist
M.B.B.S. FCPS medi..</a>
		 <a class="dropdown-item " href="#">Dr.Shahzad Latif
Gastroenterologist
MBBS..MD Gastroent..</a>
		 <a class="dropdown-item " href="#">Dr Attiya Taeed
Gastroenterologist</a>
		 <a class="dropdown-item " href="#">Dr. Anwar A. Khan
Gastroenterologist
MD, FACP, FACG, DA..</a>
		 <a class="dropdown-item " href="#">Dr. Zaheer Babar
Gastroenterologist
MD, FACP, FACG, DA..</a>
		 <a class="dropdown-item " href="#">Dr. Hamad Raza
Gastroenterologist
MBBS, MD - Gasro-E..</a>
		 <a class="dropdown-item " href="#">Dr. Javed Aslam Bhinder
Gastroenterologist
MBBS - Gasro-Enter..</a>
		 <a class="dropdown-item " href="#">Dr. Shahid Raza Khan
Gastroenterologist
MBBS - Gasro-Enter..</a>
		 <a class="dropdown-item " href="#">Dr. M. Joher Amin Khan
Gastroenterologist
MBBS, FCPS (Gastro..</a>
		 <a class="dropdown-item " href="#">Dr. Altaf Alam
Gastroenterologist
MBBS,MRCP</a>
		 <a class="dropdown-item " href="#">Mujahid Israr
Gastroenterologist
MBBS, FCPS (Gastro..</a>
	 <div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="#">Comments Here</a>
   
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
   </div>
    </div>
	
	
	
	
    <div class="col-sm">
    
	  
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">FAMILY PHYSICIAN</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr. Najam Ul Sehr Butt
Family Physician</a>
	<a class="dropdown-item " href="#">Dr. Ali Mohammad Mir Col
Family Physician</a>
	<a class="dropdown-item " href="#">Dr. Naseem Ahmed Qureshi
Family Physician</a>
	<a class="dropdown-item " href="#">Dr. Nasir Manzoor
Family Physician</a>
	<a class="dropdown-item " href="#">Dr. Abdus Sattar Chaudhry
Family Physician</a>
	<a class="dropdown-item " href="#">Dr. Kashif Hafeez
Family Physician</a>
	<a class="dropdown-item " href="#">Dr. Shahid Ikram
Family Physician</a>
	<a class="dropdown-item " href="#">Dr. Javed Khalil
Family Physician</a>
	<a class="dropdown-item " href="#">Dr. Talat Naheed
Family Physician</a>
	<a class="dropdown-item " href="#">Dr. Shaheen M. Mufti
Family Physician</a>
	<a class="dropdown-item " href="#">Dr. M. Shafiq
Family Physician</a>
	<a class="dropdown-item " href="#">Dr. Sadaqat Ali
Family Physician</a>
	<a class="dropdown-item " href="#">Dr. Imtiaz Hassan
Family Physician</a>
	<a class="dropdown-item " href="#">Dr. Mohammad Rashid Khan
Family Physician</a>
	<a class="dropdown-item " href="#">Shagufta Feroz Ata-Ul -..
Family Physician</a>
	<a class="dropdown-item " href="#">Dr. M Tariq Azeez
Family Physician</a>
	<a class="dropdown-item " href="#">Dr. Muhammad Amjad Chau..
Family Physician</a>
	<a class="dropdown-item " href="#">Dr. Tauseef Riiaz
Family Physician</a>
	<a class="dropdown-item " href="#">Dr. Hamayon Farooq
Family Physician</a>
	<a class="dropdown-item " href="#">Dr. Mohammad Tahir Azam
Family Physician</a>
	<a class="dropdown-item " href="#">Dr. Capt. Amjed Hussain
Family Physician</a>
	<a class="dropdown-item " href="#">Dr. Muhammad Ibrahim
Family Physician</a>
	<a class="dropdown-item " href="#">Dr. Muhammad Akbar Chau..
Family Physician</a>
	<a class="dropdown-item " href="#">"Dr. Munawar Ahmad
Family Physician</a>
	<a class="dropdown-item " href="#">Dr. Ahmad Ijaz Shah
Family Physician</a>
	<a class="dropdown-item " href="#">Dr. M. Shahbaz Najam Sh..
Family Physician</a>
	<a class="dropdown-item " href="#">Dr. Kamran K. Chima
Family Physician</a>
	<a class="dropdown-item " href="#">Dr. Farooq Rasool
Family Physician</a>
	<a class="dropdown-item " href="#">Dr. Aamer Ghafoor Mufti
Family Physician</a>
	<a class="dropdown-item " href="#">Dr. Nasir Mehmood Malik
Family Physician</a>
	<a class="dropdown-item " href="#">Dr. Khawaja Sadiq Hussain
Family Physician</a>
	<a class="dropdown-item " href="#">Dr. Abdul Rauf
Family Physician</a>
	<a class="dropdown-item " href="#">Dr. Idris Ahmad Bhatti
Family Physician</a>
	<a class="dropdown-item " href="#">Dr. Qamar Mahmood
Family Physician</a>
	<a class="dropdown-item " href="#">Dr. Fakhar Abbass
Family Physician</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="#">Comments Here</a>

    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
    </div>
	 </div>
  </div>
</div>

<br>
<br>
<br>

<div class="container">
  <div class="row">
 
    <div class="col-sm">
   
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">EYE SPECIALIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr. Usman Imtiaz
Eye Specialist
MBBS, FCPS, MRCS (..</a>
	<a class="dropdown-item " href="#">Farukh Jameel
Eye Specialist
MBBS,FCPS</a>
	<a class="dropdown-item " href="#">Dr KHAWAJA KHALID SHOAIB
Eye Specialist
FCPS, FRCS</a>
	<a class="dropdown-item " href="#">Dr.Muhammad Akram
Eye Specialist
M.B.B.S,D.O.M.S,M...</a>
	<a class="dropdown-item " href="#">Dr. Ishrat Ali
Eye Specialist
MBBS - Eye Special..</a>
	<a class="dropdown-item " href="#">Dr Shamim Ahmed Abbasi
Eye Specialist
MBBS - Eye Special..">Dr Shamim Ahmed Abbasi
Eye Specialist
MBBS - Eye Special..</a>
	<a class="dropdown-item " href="#">Dr. Asim Iqbal Khan
Eye Specialist
MBBS - Eye Special..</a>
	<a class="dropdown-item " href="#">Dr. Mehmood Ul Hassan J..
Eye Specialist
MBBS - Eye Special..</a>
	<a class="dropdown-item " href="#">Dr. Badar - Uz - Zaman
Eye Specialist
MBBS - Eye Special..</a>
	<a class="dropdown-item " href="#">Dr. Muhammad Arshad Mah..
Eye Specialist
MBBS - FCPS Eye Sp..</a>
    <a class="dropdown-item" href="#">Prof Dr. Samina Jehangir
Eye Specialist
MBBS (gold med)- F..</a>
	<a class="dropdown-item " href="#">Dr. Muhammad Zubair
Eye Specialist
MBBS - Eye Special..</a>
	<a class="dropdown-item " href="#">Dr. Maqbool Ashraf
Eye Specialist
MBBS - Eye Special..</a>
	<a class="dropdown-item " href="#">Dr. Abul Hamid Awan
Eye Specialist
MBBS - Eye Special..</a>
    <a class="dropdown-item" href="#">Dr. Saqib Sadiq
Eye Specialist
MBBS - Eye Special..</a>
    <a class="dropdown-item" href="#">Dr. Muhammad Ramzan
Eye Specialist</a>
    <a class="dropdown-item" href="#">Dr. Syed Ali Haider
Eye Specialist</a>
	<a class="dropdown-item " href="#">Dr. Muhammad Munir Khokar
Eye Specialist</a>
	<a class="dropdown-item " href="#">Dr. Asif Mehmood
Eye Specialist</a>
	<a class="dropdown-item " href="#">Dr. A. Khawaja
Eye Specialist</a>
    <a class="dropdown-item" href="#">Dr. Nadeem Hafeez Butt
Eye Specialist</a>
    <a class="dropdown-item" href="#">Dr. Muhammad Tariq Khan
Eye Specialist
MBBS, FCPS RETINA ..</a>
    <a class="dropdown-item" href="#">Dr. Zaheer - Ud - Din A..
Eye Specialist</a>
    <a class="dropdown-item" href="#">Dr. Irshad Ul Haq
Eye Specialist</a>
    <a class="dropdown-item" href="#">Dr. Muhammad Aslam Noon
Eye Specialist</a>
    <a class="dropdown-item" href="#">Dr. Amanh Tahir Noori
Eye Specialist</a>
    <a class="dropdown-item" href="#">Dr. Syed Raza Ali Shah
Eye Specialist</a>
    <a class="dropdown-item" href="#">Dr. Faiz Rasool Ch
Eye Specialist</a>
    <a class="dropdown-item" href="#">Dr. FARHAN JAVEED
Eye Specialist
MBBS. FCPS, FRCS</a>
    <a class="dropdown-item" href="#">Prof. Mohammad Arshad M..
Eye Specialist
FCPS. DOMS</a>
    <a class="dropdown-item" href="#">Muhammad Naeem Awan
Eye Specialist
MBBS , FCPS , FRCS..</a>
    <a class="dropdown-item" href="#">Muhammad Sohail Shehzad
Eye Specialist
fCpS, MCPS, FICO, ..</a>
    <a class="dropdown-item" href="#">Dr. Waqar Ahmad
Eye Specialist
M.B.B.S FCPS Resid..</a>
    <a class="dropdown-item" href="#">Brigadier(r) Abdul Rafe
Eye Specialist
MBBS, DO, MCPS, FC..</a>
    <a class="dropdown-item" href="#">Shaukat Yusuf Khan
Eye Specialist
MBBS - Eye Special..</a>
    <a class="dropdown-item" href="#">Dr. Nazir Ahmed Aasi
Eye Specialist
MBBS - Eye Special..</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="#">Comments Here</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item " href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
  </div>
    
	
  
	</div>
	
    <div class="col-sm">
     
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">ENT SPECIALIST </button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr. Sami Mumtaz
ENT Specialist
MBBS, FRCS (ENT) UK</a>
	    <a class="dropdown-item " href="#">Babar Hussain Khan
ENT Specialist
MBBS,FCPS,MCPS</a>
	    <a class="dropdown-item " href="#">Prof. Brig Zubair Ahmed
ENT Specialist
MBBS,FCPS,FICS</a>
	    <a class="dropdown-item " href="#">BRIG (R) Z M RAAHAT
ENT Specialist
MBBS DLO(AFPGMI)FCPS</a>
	    <a class="dropdown-item " href="#">Dr. Khursheed Anwar Mian
ENT Specialist
MBBS, DLO, FICS. -..</a>
	    <a class="dropdown-item " href="#">Dr. M. Naeem
ENT Specialist
MBBS, DLO - ENT Sp..</a>
	    <a class="dropdown-item " href="#">Professor.Dr. Khalid Ch..
ENT Specialist
MBBS, DLO, FCPS - ..</a>
	    <a class="dropdown-item " href="#">Dr. Sayyad Ahmas Shakeel
ENT Specialist
MBBS, MCPS, M.S. -..</a>
	    <a class="dropdown-item " href="#">Dr. Muhammad Ameer
ENT Specialist
MBBS, FRCS., DLO -..</a>
	    <a class="dropdown-item " href="#">Dr. Khalid Mehmood
ENT Specialist
MBBS, MCPS - ENT S..</a>
	    <a class="dropdown-item " href="#">Dr. Mohammad Mujeeb
ENT Specialist
MBBS, FRCS, FCPS -..</a>
	    <a class="dropdown-item " href="#">Dr. Naveed Aslam
ENT Specialist
MBBS, FRCS - ENT S..</a>
	    <a class="dropdown-item " href="#">Dr. Muhammad Saleem
ENT Specialist
MBBS, DLO, MCPS, F..</a>
	    <a class="dropdown-item " href="#">Dr. Mian Mohammad Naeem
ENT Specialist
MBBS, FCPS, - ENT ..</a>
 <a class="dropdown-item " href="#">Dr. Muhammad Tariq
ENT Specialist
FRCS, DLO - ENT Sp..</a>
	    <a class="dropdown-item " href="#">Dr. Javed Iqbal
ENT Specialist
MBBS, FCPS, DLO - ..</a>
	    <a class="dropdown-item " href="#">Dr. Ihsan Ali
ENT Specialist
MBBS, FCPS - ENT S..</a>
	    <a class="dropdown-item " href="#">Dr. Shahid Imran
ENT Specialist
MBBS, FCPS - ENT S..</a>
	    <a class="dropdown-item " href="#">Dr. M. B. Pal
ENT Specialist
MBBS, FRCS. - ENT ..</a>
	    <a class="dropdown-item " href="#">Dr. Brig.Amanullah Khan
ENT Specialist
MBBS - ENT Special..</a>
	    <a class="dropdown-item " href="#">Dr Moazzam Ali
ENT Specialist
MBBS</a>
	    <a class="dropdown-item " href="#">Dr Bakht Aziz
ENT Specialist
MBBS, FCPS (ENT), ..</a>
	    <a class="dropdown-item " href="#">Prof Dr. Manzoor Ahmad
ENT Specialist
FCPS</a>
		<a class="dropdown-item " href="#">Dr. Nauman Bashir
ENT Specialist
MBBS, FCPS</a>
	    <a class="dropdown-item " href="#">Dr. Naseem Abbas
ENT Specialist
MBBS, FCPS - ENT S..</a>
	    <a class="dropdown-item " href="#">Dr. Khalid Shafqat Cheema
ENT Specialist
B.Sc, MBBS, DLO, F..</a>
	    <a class="dropdown-item " href="#">Dr. Farrukh Mehmood
ENT Specialist
FCPS.FACS(USA) - E..</a>
		<a class="dropdown-item " href="#">Dr. Kashif Iqbal Malik
ENT Specialist
MBBS, MCPS, FCPS -..</a>
	    <a class="dropdown-item " href="#">Dr. Asad Ullah Lone
ENT Specialist
MBBS, MS, FCPS, DL..</a>
	    <a class="dropdown-item " href="#">Dr. Muhammad Yasoob Ali
ENT Specialist
MBBS - ENT Special..</a>
	    <a class="dropdown-item " href="#">Dr. Najam Ul Hasnain
ENT Specialist
MBBS, FCPS - ENT S..</a>
		 <a class="dropdown-item " href="#">Dr. Jawaid N. Butt
ENT Specialist
MBBS, DLO, FICS - ..</a>
		 <a class="dropdown-item " href="#">Dr. M. Iqbal Butt
ENT Specialist
FRCS (Canada) - EN.</a>
		 <a class="dropdown-item " href="#">Prof. Muhammad Iqbal Butt
ENT Specialist
MBBS - ENT Special.</a>
		 <a class="dropdown-item " href="#">Dr. Ahmad Shakeel Rizvi
ENT Specialist
MBBS, M.S. - ENT S..</a>
		 <a class="dropdown-item " href="#">Dr. M. Latif Malik
ENT Specialist
MBBS, MS, FCPS, DL..</a>
		  
		  <div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="#">Comments Here</a>

    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
   </div>
    </div>
	
	
	
	
    <div class="col-sm">
    
	  
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">DIETITIAN</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Sana Qamar
Dietitian
BS (hons), PGD in ..</a>
	 <a class="dropdown-item " href="#">Rizwan Ahmed
Dietitian
Bachelor ( Arts&Sc..</a>
		 <a class="dropdown-item " href="#">Dr Irfan Suleheria
Dietitian
B.Sc, B.Pharm, Pha..</a>
		 <a class="dropdown-item " href="#">Nimra Mahmood
Dietitian
BS (hons) Food and..</a>
		 <a class="dropdown-item " href="#">Shehla Javed
Dietitian
MBBS, DTM, H(UK), ..</a>
		 <a class="dropdown-item " href="#">Qurat-ul-ain Aleem
Dietitian
M.Phil (Public Hea..</a>
		 <a class="dropdown-item " href="#">Yumna Chattha
Dietitian
BS. (Hons.) Food, </a>
		 <a class="dropdown-item " href="#">Sabahat Zubair
Dietitian
BSc (Food & Nutrit..</a>
		 <a class="dropdown-item " href="#">Mishaal Perwaiz Khan
Dietitian
BSC, MPHILL (Food ..</a>
		 <a class="dropdown-item " href="#">Amna Sarfraz
Dietitian
Bs(honors) food sc..</a>
		 <a class="dropdown-item " href="#">Mahnaz Nasir Khan
Dietitian</a>
		 <a class="dropdown-item " href="#">Shahid Mahmood
Dietitian</a>
		 <a class="dropdown-item " href="#">Sadia Khan
Dietitian
MSc Food and Nutri..</a>
		 <a class="dropdown-item " href="#">Ayesha Nasir
Dietitian
M.Sc. Food & Nutri..</a>
		 <a class="dropdown-item " href="#">Sidra Imtiaz
Dietitian
Mphil (Nutrition),..</a>
		 <a class="dropdown-item " href="#">Faseeha Aman
Dietitian
BSc(Hons), MS (Hum..</a>
		 <a class="dropdown-item " href="#">Komal Saif
Dietitian
BS (Nutrionist & D..</a>
		  <a class="dropdown-item " href="#">Qurat-ul-Ain Anis
Dietitian
B.S (Hons.) Food a..</a>
		  <a class="dropdown-item " href="#">Samia Khalid
Dietitian
BS(Clinical Nutrit..</a>
		  <a class="dropdown-item " href="#">Moeena Baig
Dietitian
BSc (Hons), M.phil..</a>
		
		    <div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="#">Comments Here</a>
    
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
    </div>
	 </div>
  </div>
</div>
<br>
<br>
<br>

<div class="container">
  <div class="row">
 
    <div class="col-sm">
   
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">DIABETIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr. Javeid Iqbal
Diabetist
MBBS,FCPS, Fellow ..</a>
	<a class="dropdown-item " href="#">Dr. Asif M Kadri
Diabetist
MBBS, MCPS, DDM - ..</a>
	    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="#">Comments Here</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item " href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
  </div>
    
	
  
	</div>
	
    <div class="col-sm">
     
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">DENTIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Ali Murtaza Dawood
Dentist
DDS, Diploma (Impl..</a>
	  <a class="dropdown-item " href="#">Dr Zuhaib Farooq
Dentist
BDS, M.Phil, PhD (..</a>
	  <a class="dropdown-item " href="#">Dr Bilal Habib
Dentist
BDS, RDS, C-Implan.</a>
	  <a class="dropdown-item " href="#">Dr Omer Farooq Ahmad
Dentist
BDS, F.I.C.D (USA)..</a>
	  <a class="dropdown-item " href="#">Dr Muhammad Behzad Sala..
Dentist
BDS, MSc (London),..</a>
	  <a class="dropdown-item " href="#">Dr. Imran Zia
Dentist
B.D.S (pb), R.D.S,..</a>
	  <a class="dropdown-item " href="#">Dr Asifa Iqbal
Dentist
BDS,M.Phil Oral Pa..</a>
	  <a class="dropdown-item " href="#">Dr Muhammad Moazzam
Dentist
BDS, FCPS (Operati..</a>
	  <a class="dropdown-item " href="#">Dr Shoaib Hanif
Dentist
BDS, C.Implants, C..</a>
	  <a class="dropdown-item " href="#">M. ShahRukh Lodhi
Dentist
BDS, C-implant, D-..</a>
	  <a class="dropdown-item " href="#">Prof Asif Ali Shah
Dentist
BDS(Pb), MSc(Lon)</a>
	  <a class="dropdown-item " href="#">Dr Zahra Masood
Dentist
BDS, C-Implant</a>
	  <a class="dropdown-item " href="#">Umber Ikram
Dentist
BDS, C-Ortho (Phil..</a>
	  <a class="dropdown-item " href="#">Ehsan Bhatti
Dentist
MBBS, FCPS, MCPS(T..</a>
	  	  <a class="dropdown-item " href="#">Hafiz Umais Ahmed
Dentist
BDS, RDS, C-Ortho,..</a>
	  <a class="dropdown-item " href="#">Prof Asma Shafique
Dentist
BDS, FCPS</a>	  
	  <a class="dropdown-item " href="#">"Waqas Ahmed
Dentist
BDS , RDS , C-Mic..</a>
	  <a class="dropdown-item " href="#">Dr. Aqib Sohail
Dentist</a>	  
	  <a class="dropdown-item " href="#">Dr. Geti Fatima
Dentist
BDS, FRSH, RDS. - ..</a>
	  <a class="dropdown-item " href="#">Dr Al Madani Salwa Moha..
Dentist
B.D.S.</a>
	  <a class="dropdown-item " href="#">Dr Junaid Siddique
Dentist
B.D.S.</a>
	  <a class="dropdown-item " href="#">Dr Khurram Nadeem
Dentist
BDS, MCPS, PGDPH, ..</a>
	  <a class="dropdown-item " href="#">Dr Edrees Anwar
Dentist
B.D.S</a>
	  <a class="dropdown-item " href="#">Dr Ehsan Rathore
Dentist
B.D.S. M.C.P.S F...</a>
	  <a class="dropdown-item " href="#">Dr Ali Waqar Hasan
Dentist
B.D.S , Bsc , FCPS..</a>
	  <a class="dropdown-item " href="#">Dr Kausar Mahmood
Dentist
BDS MCPS ( OPERATI..</a>
	  <a class="dropdown-item " href="#">Dr Zahra Shafi
Dentist
B.D.S.</a>
	  <a class="dropdown-item " href="#">Dr Zaid Naveed
Dentist
B.D.S.</a>
	  <a class="dropdown-item " href="#">Dr Zain Jawed
Dentist
B.D.S.</a>
	  <a class="dropdown-item " href="#">Dr Zainab Abdul Rakeeb ..
Dentist
B.D.S.</a>
	  <a class="dropdown-item " href="#">Dr Zainab Dawood
Dentist
B.D.S.</a>
	  <a class="dropdown-item " href="#">Zeeshan Haider
Dentist
BDS</a>
	  <a class="dropdown-item " href="#">Adeel Rana
Dentist
BDS, C-Implant, MPH</a>
	  <a class="dropdown-item " href="#">hehla Saeed
Dentist
BDS</a>
	 
	   <div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="#">Comments Here</a>
    
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
   </div>
    </div>
	
	
	
	
    <div class="col-sm">
    
	  
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">COSMETIC SURGEON</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Muhammad Sheraz Raza
Cosmetic Surgeon
MBBS, MRCS (EdinBu..</a>
	    <a class="dropdown-item " href="#">Dr. Farid Ahmad Khan
Cosmetic Surgeon
FRCS (Ed.), FCPS (..</a>
	    <a class="dropdown-item " href="#">Nauman Ahmad Gill
Cosmetic Surgeon
M.B.B.S,M.R.C.S(UK..</a>
	    <a class="dropdown-item " href="#">Dr Sohail
Cosmetic Surgeon
MBBS.DSA. (austria..</a>
	  
	   <div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="#">Comments Here</a>
    
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
    </div>
	 </div>
  </div>
</div>

<br>
<br>


<div class="container">
  <div class="row">
 
    <div class="col-sm">
   
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">CHEST SPECIALIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr. Mansur Javaid
Chest Specialist
MBBS - Chest Speci..</a>
	<a class="dropdown-item " href="#">Dr. Anees Arshad
Chest Specialist
MBBS - Chest Speci..</a>
	<a class="dropdown-item " href="#">Dr. Saleem Uz Zaman Adh..
Chest Specialist
MBBS, MRCP - Chest.</a>
	<a class="dropdown-item " href="#">Dr. Muhammad Ameen
Chest Specialist
MBBS - Chest Speci..</a>
	<a class="dropdown-item " href="#">Dr. Rana Mustafa
Chest Specialist
MBBS - Chest Speci..</a>
	<a class="dropdown-item " href="#">Dr. Muhammad Razaq
Chest Specialist
MBBS - Chest Speci..</a>
	<a class="dropdown-item " href="#">Dr. Muhammad Toseef Razaq
Chest Specialist
MBBS - Chest Speci..</a>
	<a class="dropdown-item " href="#">Dr. Saulat Ullah Khan
Chest Specialist
MBBS - Chest Speci..</a>
	<a class="dropdown-item " href="#">Dr. Ayub Latif Khawaja
Chest Specialist
MBBS - Chest Speci..</a>
	<a class="dropdown-item " href="#">Dr. Muhammad Ihsan Khan
Chest Specialist
MBBS, TDD, FCCP. -..</a>
    <a class="dropdown-item" href="#">Prof. Shabir Haider
Chest Specialist
MBBS - Chest Speci..</a>
	<a class="dropdown-item " href="#">Dr. Imtiaz Randhawa
Chest Specialist
MBBS - Chest Speci.."</a>
	<a class="dropdown-item " href="#">Dr. Mohammad Javaid Sha..
Chest Specialist
MBBS, DGO, MCPS, M..</a>
	<a class="dropdown-item " href="#">Dr. Rana Sohail
Chest Specialist
MBBS - Chest Speci..</a>
	<a class="dropdown-item " href="#">Dr. Tanveer Ul Islam
Chest Specialist
MBBS - Chest Speci..</a>
	<a class="dropdown-item " href="#">Dr. Rana Sohail Ahmed
Chest Specialist
MBBS - Chest Speci..</a>
    <a class="dropdown-item" href="#">Dr. Saeed Kaleem
Chest Specialist</a>
	<a class="dropdown-item " href="#">Dr. Mohammad Tauseef Ra..
Chest Specialist</a>
	<a class="dropdown-item " href="#">Dr. Muhammad Abdul Razzaq
Chest Specialist</a>
	<a class="dropdown-item " href="#">Dr. Amir Nazir
Chest Specialist</a>
	<a class="dropdown-item " href="#">Dr. Mohammad Sohail Gill
Chest Specialist</a>
	<a class="dropdown-item " href="#">Prof Dr. Syed Nazim Hus..
Chest Specialist</a>
	<a class="dropdown-item " href="#">Dr. Qamar Uz Zaman
Chest Specialist</a>
	<a class="dropdown-item " href="#">Dr. Mohammad Akram
Chest Specialist
MBBS DTCD</a>
	<a class="dropdown-item " href="#">Dr. Muhammad Zulfikar K..
Chest Specialist</a>
	<a class="dropdown-item " href="#">Dr. Iftikhar Ali Mirza
Chest Specialist</a>
	<a class="dropdown-item " href="#">Dr. Tahir Saeed
Chest Specialist</a>
	<a class="dropdown-item " href="#">Dr. Rashid Naeem Siddiqui
Chest Specialist</a>
	<a class="dropdown-item " href="#">Dr. Saleem-Uz-Zaman Adh..
Chest Specialist</a>
	<a class="dropdown-item " href="#">Dr. Ghazanfar Raza
Chest Specialist</a>
	<a class="dropdown-item " href="#">Dr Afzaalullah Khan
Chest Specialist
MBBS,DTCD</a>
    <a class="dropdown-item" href="#">Comments Here</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item " href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
  </div>
    
	
  
	</div>
	
    <div class="col-sm">
     
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">CARDIOLOGIST </button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr. Muhammad Zarrar Ari..
Cardiologist
MBBS, FCPS (Cardio.</a>
	<a class="dropdown-item " href="#">Nauman Zahoor Ahmed
Cardiologist
MBBS, Diplomate Ca..</a>
	<a class="dropdown-item " href="#">Mudassar Qayyum
Cardiologist
MBBS, FCPS (Cardio..</a>
	<a class="dropdown-item " href="#">Muhammad Suleman Khan
Cardiologist
MBBS, FCPS (Cardio..</a>
	<a class="dropdown-item " href="#">Junaid Zaffar
Cardiologist
MBBS, FCPS, MCPS, ..</a>
	<a class="dropdown-item " href="#">Shahnawaz Ahmad
Cardiologist
MBBS</a>
	<a class="dropdown-item " href="#">Ammar Hameed Khan
Cardiologist
MBBS, FRCS, Fellow..</a>
	<a class="dropdown-item " href="#">Gohar Saeed
Cardiologist
MD, FACC, FSCAI</a>
	<a class="dropdown-item " href="#">Tayyab Mohyuddin
Cardiologist
MBBS, MD, FACC, FS..</a>
	<a class="dropdown-item " href="#">Dr. Aftab Hussain
Cardiologist
MBBS, FCPS (Cardio..</a>
	<a class="dropdown-item " href="#">Dr Zameer ul asar
Cardiologist
MBBS,FCPS Cardiology</a>
	<a class="dropdown-item " href="#">Dr MUHAMMAD RAFEEQ SHAH
Cardiologist
m.b.b.s F.C.P.S ..</a>
	<a class="dropdown-item " href="#">Dr Arsalan Masoud
Cardiologist
MBBS</a>
	<a class="dropdown-item " href="#">Dr Sikander Hayat Raza
Cardiologist
MBBS, MRCP (UK), M..</a>
	<a class="dropdown-item " href="#">Ali Mustansir
Cardiologist
F.C.P.S.</a>
	<a class="dropdown-item " href="#">Dr. Amanullah
Cardiologist
MBBS, DipCard, MAS..</a>
	<a class="dropdown-item " href="#">Dr. Liaqat Ali
Cardiologist
MBBS, FCPS, FACP -..</a>
 <a class="dropdown-item " href="#">Dr. Shahryar Ahmad Sheikh
Cardiologist
MBBS, MD , FACC - ..</a>
 <a class="dropdown-item " href="#">Dr. Sheharyar Hassan Khan
Cardiologist
MBBS, FCPS, MRCP</a>
 <a class="dropdown-item " href="#">Dr. Ghulam Abbass
Cardiologist</a>
 <a class="dropdown-item " href="#">Dr. Amir Khan
Cardiologist</a>
 <a class="dropdown-item " href="#">Mohiuddin
Cardiologist
MBBS,FRCP</a>
 <a class="dropdown-item " href="#">Dr Noor Dastgir
Cardiologist
MBBS, FCPS</a>
 <a class="dropdown-item " href="#">Dr Omar Aziz Rana
Cardiologist
MBBS, DM, MRCP (UK..</a>

	<div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="#">Comments Here</a>
   
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
   </div>
    </div>
	
	
	
	
    <div class="col-sm">
    
	  
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">VASCULAR SURGEON </button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr Rashid Usman
Vascular Surgeon
MBBS (KEMU), MRCS ..</a>
	 <a class="dropdown-item " href="#">Ilyas Sadiq
Vascular Surgeon
MBBS, FCPS-I, FRCS..</a>
 <a class="dropdown-item " href="#">Dr. Aasim Malik
Vascular Surgeon</a>
 <a class="dropdown-item " href="#">Prof. Ilyas Sadiq
Vascular Surgeon</a>
  <div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="#">Comments Here</a>
    
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
    </div>
	 </div>
  </div>
</div>

<br>
<br>


<div class="container">
  <div class="row">
 
    <div class="col-sm">
   
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">UROLOGIC ONCOLOGIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Awais Amjad Malik
Urologic Oncologist
MBBS, FCPS (Genera..</a>

    <a class="dropdown-item" href="#">Comments Here</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item " href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
  </div>
    
	
  
	</div>
	
    <div class="col-sm">
     
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">THORACIC SURGEON</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr. Muhammad Shoaib Nabi
Thoracic Surgeon
MBBS - Thoracic Su..</a>
	
    <a class="dropdown-item " href="#">Dr Syed Muhammad Raza
Thoracic Surgeon
MBBS, MS Thoracic ..</a>
     <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="#">Comments Here</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
   </div>
    </div>
	
	
	
	
    <div class="col-sm">
    
	  
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">SONOLOGIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Robina Anwar
Sonologist
MBBS - Sonologist</a>
	     <div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="#">Comments Here</a>

    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
    </div>
	 </div>
  </div>
</div>
<br>
<br>


<div class="container">
  <div class="row">
 
    <div class="col-sm">
   
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">SEXOLOGIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr Muhammad Haris Burki
Sexologist
MBBS, FECSM, PHD, ..</a>
	<a class="dropdown-item " href="#">Dr.Ashfaq Hamza
Sexologist
MBBS, FCPS,</a>
	<a class="dropdown-item " href="#">Dr. Akram Khan
Sexologist</a>
	<a class="dropdown-item " href="#">Dr. M. Aslam Naveed
Sexologist</a>
	<a class="dropdown-item " href="#">Prof Dr. Ijaz Haider
Sexologist</a>
	<a class="dropdown-item " href="#">Dr. Kamran
Sexologist
MBBS</a>
	<a class="dropdown-item " href="#">Dr. Imran T Hashmi
Sexologist</a>
	<a class="dropdown-item " href="#">Dr. Usman Amin Hotiana
Sexologist</a>
	<a class="dropdown-item " href="#">Dr. Bushra Jabeen
Sexologist</a>
	<a class="dropdown-item " href="#">Dr. Zubair Bhatti
Sexologist</a>
    <a class="dropdown-item" href="#">Khaliq Ul Rehman
Sexologist</a>
	 <a class="dropdown-item" href="#">Dr. Shahida Malik
Sexologist</a> 
	 <a class="dropdown-item" href="#">Muhammad Haris Burki
Sexologist
MBBS,PhD,FECSM sex..</a>
    <a class="dropdown-item" href="#">Comments Here</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item " href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
  </div>
    
	
  
	</div>
	
    <div class="col-sm">
     
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">REHABILITATION MEDICINE</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr. Arbab Afzal
Rehabilitation Medicine
MBBS, MD (Medicine)</a>
<div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="#">Comments Here</a>
   
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
   </div>
    </div>
	
	
	
	
    <div class="col-sm">
    
	  
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">PULMONOLOGIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Muhammad Hussain
Pulmonologist
MBBS, FCPS, MACP</a>
	   <a class="dropdown-item " href="#">Prof Shamshad Rasul Awan
Pulmonologist
MBBS, MCPS, FCPS, ..</a>   
<a class="dropdown-item " href="#">Khawar Abbas
Pulmonologist
MBBS, MD,MRCP(Uk),..</a>   
<a class="dropdown-item " href="#">Kamran Hameed
Pulmonologist
MBBS, MRCP (UK), F..</a>
	   <a class="dropdown-item " href="#">Atif Mahmood
Pulmonologist
MBBS, FMGMS, USA, ..</a>   
<a class="dropdown-item " href="#">DR. KHAWAR ABBAS
Pulmonologist
MBBS, MD,MRCP(Uk),..</a>  
 <a class="dropdown-item " href="#">PROF. DR. SHAMSHAD RASU..
Pulmonologist
MBBS, MCPS, FCPS, ..</a>
	   <a class="dropdown-item " href="#">DR. KAMRAN HAMEED
Pulmonologist
MBBS, MCPS, FCPS, ..</a>  
 <a class="dropdown-item " href="#">PROF. DR. SHOAIB ALAM
Pulmonologist
MBBS, MCPS, FCPS, ..</a>   
<a class="dropdown-item " href="#">Nazim Bukhari
Pulmonologist
M.D, FCCP - Pulmon..</a>
  <a class="dropdown-item " href="#">Mohammad Ihsan Khan
Pulmonologist
MBBS, TDD, FCCP - ..</a>
	<a class="dropdown-item " href="#">Dr. Mansur Javaid
Pulmonologist
MBBS, FCCP, DABIM ..</a>
	<a class="dropdown-item " href="#">Dr. Mohammad Ameen
Pulmonologist
MBBS, DTCD - Pulmo..</a>
	<a class="dropdown-item " href="#">Dr. Anees Arshad
Pulmonologist
MBBS, MD, DAB - Pu..</a>
	<a class="dropdown-item " href="#">Dr. Muhammad Toseef Razaq
Pulmonologist
MBBS, MD, FACA, FC..</a>
	<a class="dropdown-item " href="#">Dr. Saulat Ullah Khan
Pulmonologist
MBBS, DTCD, MCPS, ..</a>
	<a class="dropdown-item " href="#">Dr. Shamshad Rasool Awan
Pulmonologist
MBBS, MCPS, FCPS, .</a>
	<a class="dropdown-item " href="#">Dr. Nazim Bukhari
Pulmonologist
M.D, FCCP - Pulmon..</a>
	<a class="dropdown-item " href="#">Dr. Humanyyun Ihsan
Pulmonologist
MBBS, MCPS, DTCD -..</a>
	<a class="dropdown-item " href="#">Dr. Mohammad Ihsan Khan
Pulmonologist
MBBS, TDD, FCCP - ..</a>
	<a class="dropdown-item " href="#">Dr. Rana Sohail
Pulmonologist
MBBS, DTCD, MACCP ..</a>
	<a class="dropdown-item " href="#">Dr. Rana Sohail Ahmed
Pulmonologist
MBBS, DTCD, MACCP ..</a>
	<a class="dropdown-item " href="#">Dr. Tanveer Ul Islam
Pulmonologist
MBBS, MACP, DABIM ..</a>
	<a class="dropdown-item " href="#">Dr. M Irfan Malik
Pulmonologist
M.B.B.S, F.C.P.S(P..</a>
	<a class="dropdown-item " href="#">Dr. Talha Mahmud
Pulmonologist
FCPS (Medicine), M..</a>
	<a class="dropdown-item " href="#">Dr. Kamran Chima
Pulmonologist</a>
	<a class="dropdown-item " href="#">Dr.Haroon Ihsan
Pulmonologist</a>


 <div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="#">Comments Here</a>

    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
    </div>
	 </div>
  </div>
</div>
<br>
<br>


<div class="container">
  <div class="row">
 
    <div class="col-sm">
   
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">PSYCHIATRIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Ayesha Naveed
Psychiatrist
MBBS, MRCP (Psych)..</a>
	<a class="dropdown-item " href="#">Qambar Murtaza Bokhari
Psychiatrist
MBBS, FCPS (Psych)..</a>
	<a class="dropdown-item " href="#">Naeem Aftab
Psychiatrist
MBBS, DIPLOMAT Ame..</a>
	<a class="dropdown-item " href="#">Muhammad Mujtaba
Psychiatrist
MBBS, FCPS,MCPS</a>
	<a class="dropdown-item " href="#">Ismail Tariq
Psychiatrist
MBBS, DPM, MCPS, F..</a>
	<a class="dropdown-item " href="#">yed Kamran Haider Bukh..
Psychiatrist</a>
	<a class="dropdown-item " href="#">Aysha Butt
Psychiatrist
MBBS, FCPS (Psychi..</a>
	<a class="dropdown-item " href="#">Naseem Chaudhry
Psychiatrist
MBBS, American Dip.</a>
	<a class="dropdown-item " href="#">Usman Amin Hotiana
Psychiatrist
MBBS, FCPS (Psych)</a>
	<a class="dropdown-item " href="#">Dr Munir Ahmad Khan
Psychiatrist
MBBS, DPM</a>
    <a class="dropdown-item" href="#">Muhammad Haris Khan
Psychiatrist
WPA-CME, PhDHe has..</a>
	<a class="dropdown-item " href="#">Mian Niaz Ahmed
Psychiatrist
Medical</a>
    <a class="dropdown-item" href="#">Dr. Arslan Butt
Psychiatrist
MBBS - Psychiatrist</a>
    <a class="dropdown-item" href="#">Dr. Muhammad Nasir Saee..
Psychiatrist
MBBS - Physiatrist</a>
    <a class="dropdown-item" href="#">Dr. Muhammad Waseem
Psychiatrist
M.B.B.S(K.E),DPM</a>
    <a class="dropdown-item" href="#">Dr Muhammad Ismail Tariq
Psychiatrist
MBBS,DPM,MCPS,FCPS..</a>
    <a class="dropdown-item" href="#">Dr. Capt. Liaqat Ali
Psychiatrist</a>
    <a class="dropdown-item" href="#">"Dr. Imran Hashmi
Psychiatrist</a>
    <a class="dropdown-item" href="#">Dr. Aftab Asif
Psychiatrist</a>
    <a class="dropdown-item" href="#">Dr. Mohsin Saqib
Psychiatrist
MRCP (Psych)</a>
    <a class="dropdown-item" href="#">Dr RANA QASIM HASSAN
Psychiatrist
MBBS, DPP.(UK),MAA..</a>
	<a class="dropdown-item" href="#">Dr Muhammad Imran Afzal
Psychiatrist
M.b.b.s D.P.M.</a>
    <a class="dropdown-item" href="#">Dr. Col. Masood Ahmad
Psychiatrist
MBBS, DIP-Psych, M..</a>
    <a class="dropdown-item" href="#">Dr Shahbaz Noor
Psychiatrist
MBBS, MRCPsych (UK)</a>

    <a class="dropdown-item" href="#">Comments Here</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item " href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
  </div>
    
	
  
	</div>
	
    <div class="col-sm">
     
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">PHYSICIAN</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr Muhammad Awais Abid
Physician
Fcps(medicine ), F..</a>
	    <a class="dropdown-item" href="#">Dr Malik Shamoon Hussain
Physician
M.D Pharmacist</a>
    <a class="dropdown-item" href="#">Dr Zar Khan
Physician
MBBS</a>
    <a class="dropdown-item" href="#">Sleem uz zaman Adhmi
Physician
MBBS, MRCP - Physi..</a>
    <a class="dropdown-item" href="#">Rohi Nadeem
Physician
MBBS, MIDC - Physi..</a>
    <a class="dropdown-item" href="#">Dr. Farrukh Iqbal
Physician
MBBS, MRCP, FRCP -..</a>
    <a class="dropdown-item" href="#">Dr. Haroon Khan Babar
Physician
MBBS, DTM, MRCP, M..</a>
	 <a class="dropdown-item" href="#">Dr. Sajid Abdullah
Physician
MBBS, FCPS - Physi..</a>
    <a class="dropdown-item" href="#">Dr. Maria Arora
Physician
MBBS, DTCD, MCPS, ..</a>
    <a class="dropdown-item" href="#">Dr. Imtiaz Ali
Physician
BS.c, MBBS(Pb) RMP..</a>
    <a class="dropdown-item" href="#">Dr. Asma Nazir
Physician
MBBS, FCPS - Physi..</a>
    <a class="dropdown-item" href="#">Dr. Nusrum Iqbal
Physician
MBBS (PB), MD (USA..</a>
	<a class="dropdown-item" href="#">Dr. Sohail Malik
Physician
MBBS (Pb), PMDC, (..</a>
    <a class="dropdown-item" href="#">Dr. Samee Ullah Sheikh
Physician
MBBS, DPH, FCGP. -..</a>
    <a class="dropdown-item" href="#">Dr. Moeen Ul Haq
Physician
MBBS MRCP - Physic..</a>
    <a class="dropdown-item" href="#">Dr. Faisal Sultan
Physician
MBBS, DABIM. - Phy..</a>
    <a class="dropdown-item" href="#">Dr. Rashid Ahmed
Physician
MBBS, MD - Physician</a>
    <a class="dropdown-item" href="#">Dr. Najma Pervaiz
Physician
MBBS - Physician</a>
	<a class="dropdown-item" href="#">Dr. Mohammad Akhtar Khan
Physician
MBBS, FCPS, FRCP -..</a>
    <a class="dropdown-item" href="#">Dr. Muhammad Haroon Yusuf
Physician
MBBS, FCPS - Physi..</a>
    <a class="dropdown-item" href="#">Dr. Rashid Abbas
Physician
MBBS - Physician</a>
    <a class="dropdown-item" href="#">Dr. Sleem Uz Zaman Adhmi
Physician
MBBS, MRCP - Physi..</a>
	 <a class="dropdown-item" href="#">Dr. Naveed Ilyas Awan
Physician
MD - Physician</a>
    <a class="dropdown-item" href="#">Dr. Mustab Ahmed
Physician
MBBS, MD, MRCP - P..</a>
    <a class="dropdown-item" href="#">Dr. Shamail Zafar
Physician
MBBS FCPS - Physic..</a>
    <a class="dropdown-item" href="#">Dr. Fawad Shafiq
Physician
MBBS, MACP, MRCP -..</a>
    <a class="dropdown-item" href="#">Dr. Sheikh Muhammad Meh..
Physician
MBBS, MRCP - Physi..</a>
    <a class="dropdown-item" href="#">Dr. M.Aslam Shahid
Physician
MBBS, FCPS - Physi..</a>
    <a class="dropdown-item" href="#">Dr. Tanveer Ahmed Bhatti
Physician
MBBS, MD, FCPS - P..</a>
    <a class="dropdown-item" href="#">Dr. Muhammad Ahmed Saeed
Physician
MBBS - Physician</a>
    <a class="dropdown-item" href="#">Dr. Muhammad Yousaf
Physician
MBBS, MRCP, MRCS, ..</a>
    <a class="dropdown-item" href="#">Dr. Sajid Mehmood Rana
Physician
MBBS, FCPS - Physi..</a>
	 <a class="dropdown-item" href="#">Dr. Wasim Amir
Physician
MBBS, FCPS - Physi..</a>
    <a class="dropdown-item" href="#">Dr. Salim Chaudhry
Physician
MBBS, MRCP, FRCP -..</a>
    <a class="dropdown-item" href="#">Dr. Inayat Ullah Niazi
Physician
MBBS, MRCP, FRCP, ..</a>
    <a class="dropdown-item" href="#">Dr. Irshad Ahmed Qureshi
Physician
MBBS, FCPS, MD - P..</a>
  

	  <div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="#">Comments Here</a>
    
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
   </div>
    </div>
	
	
	
	
    <div class="col-sm">
    
	  
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">PHYSIATRIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Junaid Rasool
Physiatrist
MBBS, FCPS (Psychi..</a>
	  <a class="dropdown-item " href="#">Prof. Dr. I.A.K Tareen
Physiatrist</a>
<div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="#">Comments Here</a>
    
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
    </div>
	 </div>
  </div>
</div>
<br>
<br>


<div class="container">
  <div class="row">
 
    <div class="col-sm">
   
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">PEDIATRIC ORTHOPEDIC SURGEON</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr Shaila Ali
Pediatric Orthopedic Surgeon
MBBS, FCPS</a>
 <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="#">Comments Here</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item " href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
  </div>
    
	
  
	</div>
	
    <div class="col-sm">
     
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">PAIN MANAGEMENT SPECIALIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr Muhammad Jawad Alam
Pain Management Specialist
BSPT (KEMU) TDPT/M..</a>
		<a class="dropdown-item " href="#">Waqas A. Chaudhary,M.D.
Pain Management Specialist
MBBS, MD, Dip.Pain..</a>
	<a class="dropdown-item " href="#">Dr Waqas A Chaudhary
Pain Management Specialist
MB, MD, MSc Pain M..</a>
	<a class="dropdown-item " href="#">Muhammad Akbar Zahid
Pain Management Specialist
M.D.. DC..D.A.AP.M..</a>
	<a class="dropdown-item " href="#">Syed Mehmood Ali
Pain Management Specialist
MBBS, FCPS, M.Sc (..</a>
	<a class="dropdown-item " href="#">Muhammad Azhar
Pain Management Specialist
MBBS (KEMU), MCPS ..</a>
	<a class="dropdown-item " href="#">Muhammad Jamil Sabit
Pain Management Specialist
MBBS, MSC (Pain Me..</a>
	<a class="dropdown-item " href="#">Dr Ateeq Ur Rehman Ghaf..
Pain Management Specialist
MBBS, MRCS, FCAI, ..</a>
	<a class="dropdown-item " href="#">Dr Muhammad Zafar Khan
Pain Management Specialist
MBBS; FCARCSI</a>
	<a class="dropdown-item " href="#">Dr. Jawed Akhtar
Pain Management Specialist
MBBS, FRCS (Irela..</a>
    <a class="dropdown-item" href="#">Prof. Dr. Waseem Ismat ..
Pain Management Specialist
MBBS, FCPS, Diplom..</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="#">Comments Here</a>
    
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
   </div>
    </div>
	
	
	
	
    <div class="col-sm">
    
	  
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">PAEDIATRIC RADIOLOGIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Mahfooz ur Rehman Khan
Paediatric Radiologist
MBBS, DRMD</a>
	    <a class="dropdown-item " href="#">Dr Shahzad Karim Bhatti
Paediatric Radiologist
MBBS, MCPS, FCPS</a>
	 
<div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="#">Comments Here</a>
    
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
    </div>
	 </div>
  </div>
</div>

<br>
<br>

<div class="container">
  <div class="row">
 
    <div class="col-sm">
   
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">ORTHOPEDIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr. Muhammad Ashraf Niz..
Orthopedist
MD, FRCOS, Ph.D. -..</a>
    <a class="dropdown-item " href="#">Dr. Shafique Ahmad Shafaq
Orthopedist
MBBS, FCPS - Ortho..</a>
    <a class="dropdown-item " href="#">Dr. Abdul Latif Samee
Orthopedist
MBBS, FRCS - Ortho..</a>
	  <a class="dropdown-item " href="#">Dr. Ghulam Murtaza Cheema
Orthopedist
MBBS, FRCS, FCPS -..</a>
	  <a class="dropdown-item " href="#">Dr. Asif Chaudhry
Orthopedist
MBBS, FRCS - Ortho..</a>
	  <a class="dropdown-item " href="#">Dr. Mohammad Naeed
Orthopedist
MBBS, FCPS, MS - O..</a>
	  <a class="dropdown-item " href="#">Dr. Mohammad Saleem
Orthopedist
MBBS, FRCS, FRCS, ..</a>
	  <a class="dropdown-item " href="#">Dr. Ashraf Awais
Orthopedist
MBBS, FRCS - Ortho..</a>
	  <a class="dropdown-item " href="#">Dr. Javed Iqbal Khan
Orthopedist
MBBS, FCPS - Ortho..</a>
	  <a class="dropdown-item " href="#">"Dr. Syed Basharat Ali
Orthopedist
MBBS, FCPS - Ortho..</a>
	  <a class="dropdown-item " href="#">Dr. Khalid Tanveer Ahmed
Orthopedist
MBBS, MS - Orthope..</a>
	  <a class="dropdown-item " href="#">Dr. Javed Iqbal
Orthopedist
MBBS, FRCS - Ortho..</a>
	  <a class="dropdown-item " href="#">Dr. Munir Hussain Col.(R)
Orthopedist
MBBS, FRCS, FICS -.</a>
	  <a class="dropdown-item " href="#">Dr. Aftab Ahmed
Orthopedist
MBBS, FRCS - Ortho..</a>
	  <a class="dropdown-item " href="#">Dr. Hasan Aftab Ahmed
Orthopedist
MBBS, FRCS - Ortho..</a>
	    <a class="dropdown-item " href="#">Dr. Naseer Akhtar
Orthopedist
MBBS, FRCS - Ortho..</a>
	  <a class="dropdown-item " href="#">Dr. Rizwan Naseer
Orthopedist
MBBS, MS, FAOI, FI..</a>
	    <a class="dropdown-item " href="#">Dr. Ijaz Goraya
Orthopedist
MBBS - Orthopedist</a>
	  <a class="dropdown-item " href="#">Dr. Mohammad Ashraf Owais
Orthopedist
MBBS, FRCS - Ortho..</a>
	  <a class="dropdown-item " href="#">Dr. M. Arif Hassan Khan
Orthopedist
MBBS, FRCS, MCH. -..</a>
	  <a class="dropdown-item " href="#">Dr. Naseer Mehmood
Orthopedist
MBBS, FRCS - Ortho..</a>
	  <a class="dropdown-item " href="#">Dr. Rana Ikmal Khan
Orthopedist
MBBS, MD, FRCS - O..</a>
	  <a class="dropdown-item " href="#">Dr. Pervaiz Iqbal
Orthopedist
MBBS, FCPS - Ortho..</a>
	  <a class="dropdown-item " href="#">Dr. Afzal Hussain
Orthopedist
MBBS, FCPS - Ortho..</a>
	  <a class="dropdown-item " href="#">Dr. Muneer Hussain
Orthopedist
MBBS, MS, FRCS, FR..</a>
	  <a class="dropdown-item " href="#">Dr. Javed Iqbal
Orthopedist
MBBS, FRCS - Ortho..</a>
	  <a class="dropdown-item " href="#">Dr. Dilawaize Nadeem
Orthopedist
MBBS, FRCS, MCH, F..</a>
	  	  <a class="dropdown-item " href="#">Dr. Khurram Saadat
Orthopedist
MBBS, FRCS - Ortho..</a>
	  <a class="dropdown-item " href="#">Dr. S.M. Hussain Andarabi
Orthopedist
MBBS, MCPS, FCPS, ..</a>
	  	  <a class="dropdown-item " href="#">Dr. Samiullah Bajwa
Orthopedist
FRCS Edin-U.K, M.S..</a>
	  <a class="dropdown-item " href="#">Dr. Iqbal Bhutta
Orthopedist
MBBS, MS - Orthope..</a>
	  <a class="dropdown-item " href="#">Dr. Ahsan Shamim
Orthopedist
MBBS, FRCS - Ortho..</a>
	  <a class="dropdown-item " href="#">Dr. Ghazanfar Ali Shah
Orthopedist
MD, FRCS, FACS, FI..</a>
	  <a class="dropdown-item " href="#">Dr. Dr Saba
Orthopedist
MBBS - Orthopedist</a>
	  <a class="dropdown-item " href="#">Dr. Mohammad Masood Ehsan
Orthopedist
MBBS, FRCS - Ortho..</a>
	

<div class="dropdown-divider"></div>
    <a class="dropdown-item" href="#">Comments Here</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item " href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
  </div>
 
  
	</div>
	
    <div class="col-sm">
     
	  <div class="btn-group">
  <button type="button" class="btn btn-lg btn-danger">ORTHODONTIST</button>
  <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item " href="#">Dr Ammar Pasha Siddiqui
Orthodontist
FCPS</a> 
	<a class="dropdown-item " href="#">Waqar Jeelani
Orthodontist
BDS, FCPS</a>
    <a class="dropdown-item " href="#">Dr Awais Afridi
Orthodontist
BDS (RDS)</a> 
	<a class="dropdown-item " href="#">Waheed Ullah Khan
Orthodontist
FCPS</a>
  
	  <div class="dropdown-divider"></div>
    <a class="dropdown-item active" href="#">Comments Here</a>
    
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="areawise_hos.php">AREA WISE DOCTORS OF LAHORE</a>
  </div>
   </div>
    </div>
    
	 </div>
  </div>

<div class="container" style="width:700px;">  
   <br>
   <br /> 
 <br>
   <br /> 
 <br>
   <br />    
   <div class="table-responsive" >
    
    <div id="comments_table">
     <table class="table table-bordered">
      <tr>
       <th width="70%">User Name</th>  
       <th width="30%">View</th>
      </tr>
      <?php
	
      while($row = mysqli_fetch_array($result))
      {
      ?>
      <tr>
       <td><?php echo $row["Enter_Name"]; ?></td>
       <td><input type="button" name="view" value="view" id="<?php echo $row["id"]; ?>" class="btn btn-info btn-xs view_data" /></td>
      </tr>
      <?php
      }
      ?>
     </table>
    </div>
   </div>  
  </div>


<script>
$('.dropdown-toggle').dropdown()
$('#myDropdown').on('show.bs.dropdown', function () {
  // do something…
})
</script>




</body>
</html>
<!-- comments section-->

<section id="comments">

<h2>Comments</h2>
<div class="media">
<img src="https://placehold.it/64*64" alt="Media object image">
<div class="media-body">
<p> <a href="mailto:example@domain.com">Author Name</a> (Posted on: <time datetime="2019-02-24T6:31">Feb 24,2019 at 6:31 AM</time>)</p>
</div>
</div>
<hr>

<div class="media">
<img src="https://placehold.it/64*64" alt="Media object image">
<div class="media-body">
<p> <a href="mailto:example@domain.com">Author Name</a> (Posted on: <time datetime="2019-02-24T6:31">Feb 24,2019 at 6:31 AM</time>)</p>
</div>
</div>
<hr>
<div class="media">
<img src="https://placehold.it/64*64" alt="Media object image">
<div class="media-body">
<p> <a href="mailto:example@domain.com">Author Name</a> (Posted on: <time datetime="2019-02-24T6:31">Feb 24,2019 at 6:31 AM</time>)</p>
</div>
</div>
<hr>
<div class="media">
<img src="https://placehold.it/64*64" alt="Media object image">
<div class="media-body">
<p> <a href="mailto:example@domain.com">Author Name</a> (Posted on: <time datetime="2019-02-24T6:31">Feb 24,2019 at 6:31 AM</time>)</p>
</div>
</div>
</div>
</div>
<hr>



<form method="post" id="insert_form">
<div class="form-group">

<label for="name">Name:</label>
<input type="text" class="form-control" placeholder="Name" id="name" required>

</div>

<div class="form-group">

<label for="email">Email:</label>
<input type="text" class="form-control" placeholder="Email" id="email" required>

</div>

<div class="form-group">

<label for="comment">Your Comment:</label>
<textarea  class="form-control"  id="comment" name="comment" rows="5" placeholder="write your comment here: Maximum 500 characters." required></textarea>

</div>

<!--
 <div class="modal-body" id="doctor_specility_detail">
    
   </div>
  -->

<button type="submit" name="insert" id="insert" value="Insert" class="btn btn-primary">Submit</button>
<button type="reset" class="btn btn-danger">Reset  </button>

</form>

</section>







<script>  
$(document).ready(function(){
 $('#insert_form').on("submit", function(event){  
  event.preventDefault(); 
if($('#Enter_Name').val() == "")  
  {  
   alert("Name is required");  
  }  
 else  if($('#Enter_Email').val() == "")  
  {  
   alert("Email Address is required");  
  }  
  else if($('#Enter_Message').val() == '')  
  {  
   alert("Message is required");  
  }  
  
   
  else  
  {  
   $.ajax({  
    url:"insert_doctor_specility.php",  
    method:"POST",  
    data:$('#insert_form').serialize(),  
    beforeSend:function(){  
     $('#insert').val("Inserting");  
    },  
    success:function(data){  
     $('#insert_form')[0].reset();  
     $('#add_data_Modal').modal('hide');  
     $('#comments_table').html(data);  
    }  
   });  
  }  
 });




 $(document).on('click', '.view_data', function(){
  //$('#dataModal').modal();
  var user_id = $(this).attr("id");
  $.ajax({
   url:"select_doctor_specility.php",
   method:"POST",
   data:{user_id:user_id},
   success:function(data){
    $('#doctor_specility_detail').html(data);
    $('#dataModal').modal('show');
   }
  });
 });
});  
 </script>

